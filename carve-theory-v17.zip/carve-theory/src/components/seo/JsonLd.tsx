/**
 * JsonLd — Server Component
 *
 * JSON-LDをSSRで<script type="application/ld+json">に注入する。
 * クライアント処理不要。全ページで使える汎用コンポーネント。
 *
 * 使い方:
 *   import { JsonLd } from "@/components/seo/JsonLd";
 *   <JsonLd schema={buildArticleSchema({ article })} />
 *
 * または複数まとめて:
 *   <JsonLd schema={buildSchemaGraph([schema1, schema2, schema3])} />
 */

interface JsonLdProps {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  schema: Record<string, any> | Record<string, any>[];
  /** id属性（同一ページに複数置く場合に区別する） */
  id?: string;
}

export function JsonLd({ schema, id }: JsonLdProps) {
  const json = JSON.stringify(schema, null, process.env.NODE_ENV === "development" ? 2 : 0);

  return (
    <script
      id={id}
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: json }}
    />
  );
}

/**
 * MultiJsonLd — 複数スキーマを個別の<script>タグで注入する
 * @graph を使わずに分割したい場合に使う
 */
export function MultiJsonLd({
  schemas,
}: {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  schemas: { id: string; schema: Record<string, any> }[];
}) {
  return (
    <>
      {schemas.map(({ id, schema }) => (
        <JsonLd key={id} id={id} schema={schema} />
      ))}
    </>
  );
}
