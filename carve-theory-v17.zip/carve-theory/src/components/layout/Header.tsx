"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Menu, X, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { NAV_ITEMS, NAV_GROUPS } from "@/lib/constants";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const pathname = usePathname();
  const searchRef = useRef<HTMLInputElement>(null);
  const megaTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setSearchOpen(false);
    setMegaOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (searchOpen) setTimeout(() => searchRef.current?.focus(), 100);
  }, [searchOpen]);

  const openMega = () => {
    if (megaTimer.current) clearTimeout(megaTimer.current);
    setMegaOpen(true);
  };
  const closeMega = () => {
    megaTimer.current = setTimeout(() => setMegaOpen(false), 120);
  };

  return (
    <>
      <header className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-500",
        scrolled ? "bg-[#050505]/97 backdrop-blur-xl border-b border-white/5" : "bg-transparent"
      )}>
        <div className="max-w-8xl mx-auto px-5 md:px-10 h-[60px] flex items-center justify-between">

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 group flex-shrink-0">
            <div className="w-6 h-6 relative">
              <svg viewBox="0 0 28 28" fill="none" className="w-full h-full">
                <path d="M14 2 L26 24 L2 24 Z" stroke="white" strokeWidth="1.5"
                  className="transition-opacity group-hover:opacity-60" />
                <path d="M14 8 L21 20 L7 20 Z" fill="white" fillOpacity="0.15"
                  className="transition-opacity group-hover:fill-opacity-30" />
              </svg>
            </div>
            <div className="flex flex-col leading-none">
              <span className="font-display font-black text-white text-[15px] tracking-wider">CARVE</span>
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-[7px] text-white/25 tracking-[0.25em] uppercase">Theory</span>
                <span className="font-mono text-[7px] text-cyan-400/60 tracking-widest border border-cyan-500/25 px-1 py-px">2026</span>
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            {NAV_ITEMS.map((item) => (
              <Link key={item.href} href={item.href}
                className={cn(
                  "text-[11px] font-medium tracking-[0.1em] uppercase transition-colors duration-200",
                  pathname === item.href ? "text-white" : "text-white/35 hover:text-white/75"
                )}>
                {item.label}
              </Link>
            ))}

            {/* Mega menu trigger */}
            <div
              className="relative"
              onMouseEnter={openMega}
              onMouseLeave={closeMega}
            >
              <button className="flex items-center gap-1 text-[11px] font-medium tracking-[0.1em] uppercase text-white/35 hover:text-white/75 transition-colors">
                カテゴリ
                <ChevronDown size={11} className={cn("transition-transform duration-200", megaOpen && "rotate-180")} />
              </button>

              <AnimatePresence>
                {megaOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 8 }}
                    transition={{ duration: 0.15 }}
                    onMouseEnter={openMega}
                    onMouseLeave={closeMega}
                    className="absolute top-full right-0 mt-3 w-[680px] bg-[#080808] border border-white/8 shadow-2xl overflow-hidden"
                  >
                    <div className="grid grid-cols-3 gap-px bg-white/5 p-px">
                      {NAV_GROUPS.map((group) => (
                        <div key={group.label} className="bg-[#080808] p-4">
                          <div className="font-mono text-[8px] text-white/20 tracking-[0.2em] uppercase mb-3 flex items-center gap-2">
                            <div className="w-3 h-px bg-white/15" />
                            {group.labelEn}
                          </div>
                          <ul className="space-y-1">
                            {group.items.map((item) => (
                              <li key={item.href}>
                                <Link href={item.href}
                                  className="group flex items-start gap-2 px-2 py-1.5 hover:bg-white/4 transition-colors rounded-sm">
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-1.5">
                                      <span className="text-xs text-white/60 group-hover:text-white/90 transition-colors">
                                        {item.label}
                                      </span>
                                      {item.badge && (
                                        <span className={cn(
                                          "font-mono text-[7px] px-1 py-px border tracking-wider",
                                          item.badge === "NEW" ? "border-cyan-500/30 text-cyan-400/60" :
                                          item.badge === "HOT" ? "border-red-500/30 text-red-400/60" :
                                          "border-white/15 text-white/35"
                                        )}>
                                          {item.badge}
                                        </span>
                                      )}
                                    </div>
                                    {item.description && (
                                      <p className="text-[10px] text-white/25 mt-0.5 leading-snug">
                                        {item.description}
                                      </p>
                                    )}
                                  </div>
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </nav>

          {/* Right actions */}
          <div className="flex items-center gap-2">
            <button onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 text-white/35 hover:text-white/75 transition-colors" aria-label="検索">
              <Search size={16} />
            </button>
            <button onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-2 text-white/35 hover:text-white/75 transition-colors" aria-label="メニュー">
              {mobileOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>

        {/* Search */}
        <AnimatePresence>
          {searchOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="border-t border-white/5 bg-[#050505] overflow-hidden"
            >
              <div className="max-w-8xl mx-auto px-5 md:px-10 py-3">
                <form onSubmit={(e) => {
                  e.preventDefault();
                  if (searchQuery.trim()) window.location.href = `/search?q=${encodeURIComponent(searchQuery)}`;
                }} className="flex items-center gap-3">
                  <Search size={14} className="text-white/25 flex-shrink-0" />
                  <input
                    ref={searchRef}
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="圧の流れ、早期切り替え、コブ吸収…"
                    className="flex-1 bg-transparent text-white placeholder:text-white/20 text-sm outline-none"
                  />
                  <span className="font-mono text-[9px] text-white/15 tracking-widest hidden md:block">ENTER</span>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, x: "100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "100%" }}
            transition={{ duration: 0.28, ease: [0.32, 0.72, 0, 1] }}
            className="fixed inset-0 z-40 bg-[#050505] pt-[60px] pb-8 overflow-y-auto"
          >
            <div className="px-6 pt-6">
              {NAV_GROUPS.map((group, gi) => (
                <div key={group.label} className="mb-6">
                  <div className="font-mono text-[8px] text-white/20 tracking-[0.2em] uppercase mb-3">
                    {group.labelEn}
                  </div>
                  {group.items.map((item, ii) => (
                    <motion.div
                      key={item.href}
                      initial={{ opacity: 0, x: 16 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: gi * 0.05 + ii * 0.03 }}
                    >
                      <Link href={item.href}
                        className="flex items-center gap-2 py-3 border-b border-white/4 group">
                        <span className="font-display font-bold text-xl text-white/60 group-hover:text-white transition-colors">
                          {item.label}
                        </span>
                        {item.badge && (
                          <span className="font-mono text-[7px] px-1.5 py-0.5 border border-cyan-500/30 text-cyan-400/60">
                            {item.badge}
                          </span>
                        )}
                      </Link>
                    </motion.div>
                  ))}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
