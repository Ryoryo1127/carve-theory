import Link from "next/link";
import { SITE_NAME, CATEGORIES, NAV_ITEMS } from "@/lib/constants";

export function Footer() {
  return (
    <footer className="bg-[#060606] border-t border-white/5 pt-16 pb-8">
      <div className="max-w-8xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="inline-flex items-center gap-3 mb-5">
              <svg viewBox="0 0 28 28" fill="none" className="w-6 h-6">
                <path d="M14 2 L26 24 L2 24 Z" stroke="white" strokeWidth="1.5" />
                <path d="M14 8 L21 20 L7 20 Z" fill="white" fillOpacity="0.15" />
              </svg>
              <span className="font-display font-bold text-white text-base tracking-wide">
                {SITE_NAME}
              </span>
            </Link>
            <p className="text-white/35 text-sm leading-relaxed max-w-56">
              スキー・スノーボード技術の理論と実践。感覚論から脱却し、なぜ滑れるのかを理解するメディア。
            </p>
            <div className="mt-6">
              <span className="font-mono-custom text-[10px] text-white/20 tracking-[0.2em]">
                © 2025 CARVE THEORY
              </span>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="font-mono-custom text-[10px] text-white/30 tracking-[0.2em] uppercase mb-5">
              Navigation
            </h3>
            <ul className="space-y-3">
              {NAV_ITEMS.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-white/40 hover:text-white/80 transition-colors"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-mono-custom text-[10px] text-white/30 tracking-[0.2em] uppercase mb-5">
              Categories
            </h3>
            <ul className="space-y-3">
              {CATEGORIES.slice(0, 7).map((cat) => (
                <li key={cat.slug}>
                  <Link
                    href={`/categories/${cat.slug}`}
                    className="text-sm text-white/40 hover:text-white/80 transition-colors"
                  >
                    {cat.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Routes */}
          <div>
            <h3 className="font-mono-custom text-[10px] text-white/30 tracking-[0.2em] uppercase mb-5">
              Routes
            </h3>
            <ul className="space-y-3">
              {[
                { label: "初心者ルート", href: "/routes/beginner" },
                { label: "中級者ルート", href: "/routes/intermediate" },
                { label: "技術選ルート", href: "/routes/technical" },
                { label: "アルペンルート", href: "/routes/alpine" },
                { label: "スノボルート", href: "/routes/snowboard" },
              ].map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-white/40 hover:text-white/80 transition-colors"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <p className="font-mono-custom text-[10px] text-white/20 tracking-[0.15em]">
            感覚論だけで滑るのをやめる。なぜ板が曲がるのかを、理解する。
          </p>
          <div className="flex gap-6">
            <Link href="/for-schools" className="text-xs text-cyan-400/40 hover:text-cyan-400/70 transition-colors">
              スクール・団体の方へ
            </Link>
            <Link href="/privacy" className="text-xs text-white/25 hover:text-white/50 transition-colors">
              プライバシー
            </Link>
            <Link href="/about" className="text-xs text-white/25 hover:text-white/50 transition-colors">
              このサイトについて
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
