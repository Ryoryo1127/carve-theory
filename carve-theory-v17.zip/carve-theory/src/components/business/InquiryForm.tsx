"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, Send } from "lucide-react";
import { cn } from "@/lib/utils";

const INQUIRY_TYPES = [
  "技術教材のライセンス利用について",
  "指導者研修プログラムについて",
  "コンテンツ監修・記事制作について",
  "その他",
] as const;

export function InquiryForm() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [inquiryType, setInquiryType] = useState<string>(INQUIRY_TYPES[0]);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    // 実運用では API Route や フォームサービス（Formspree等）に送信する
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 600);
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="border border-cyan-500/20 bg-cyan-950/10 px-6 py-10 text-center"
      >
        <div className="w-10 h-10 rounded-full border border-cyan-500/30 flex items-center justify-center mx-auto mb-4">
          <Check size={16} className="text-cyan-400/80" />
        </div>
        <p className="font-display font-bold text-white/85 text-base mb-2">
          送信しました
        </p>
        <p className="text-white/40 text-xs leading-relaxed max-w-sm mx-auto">
          内容を確認のうえ、メールにてご連絡します。通常2〜5営業日以内に返信いたします。
          対応は全てテキスト・メールベースで行っており、対面での打ち合わせは必須としていません。
        </p>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* お問い合わせ種別 */}
      <div>
        <label className="font-mono text-[9px] text-white/30 tracking-widest uppercase block mb-2">
          お問い合わせ内容 <span className="text-cyan-400/50">*</span>
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {INQUIRY_TYPES.map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => setInquiryType(type)}
              className={cn(
                "text-left px-4 py-3 text-xs border transition-all",
                inquiryType === type
                  ? "border-cyan-500/40 bg-cyan-950/20 text-white/85"
                  : "border-white/8 text-white/40 hover:border-white/20"
              )}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* 組織名 */}
      <div>
        <label className="font-mono text-[9px] text-white/30 tracking-widest uppercase block mb-2">
          スクール・団体名 <span className="text-cyan-400/50">*</span>
        </label>
        <input
          required
          type="text"
          placeholder="例：〇〇スキースクール"
          className="w-full bg-[#0a0a0a] border border-white/10 px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/40 transition-colors"
        />
      </div>

      {/* メールアドレス */}
      <div>
        <label className="font-mono text-[9px] text-white/30 tracking-widest uppercase block mb-2">
          メールアドレス <span className="text-cyan-400/50">*</span>
        </label>
        <input
          required
          type="email"
          placeholder="contact@example.com"
          className="w-full bg-[#0a0a0a] border border-white/10 px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/40 transition-colors"
        />
      </div>

      {/* 詳細 */}
      <div>
        <label className="font-mono text-[9px] text-white/30 tracking-widest uppercase block mb-2">
          ご相談内容
        </label>
        <textarea
          rows={4}
          placeholder="現在の課題、検討している規模感、ご希望の進め方などをご記入ください。"
          className="w-full bg-[#0a0a0a] border border-white/10 px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/40 transition-colors resize-none"
        />
      </div>

      {/* 注記 */}
      <p className="font-mono text-[8px] text-white/20 leading-relaxed">
        ※ ご連絡はメールでのやり取りを基本としています。お打ち合わせが必要な場合も、音声通話・テキストでの対応を基本とさせていただいております。
      </p>

      {/* 送信ボタン */}
      <button
        type="submit"
        disabled={loading}
        className={cn(
          "w-full flex items-center justify-center gap-2 py-3.5 text-sm font-bold tracking-wider transition-all",
          loading
            ? "bg-white/10 text-white/30"
            : "bg-white text-black hover:bg-white/90"
        )}
      >
        {loading ? "送信中..." : (
          <>
            <Send size={14} />
            送信する
          </>
        )}
      </button>
    </form>
  );
}
