"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

/* ── 現代技術キーワードタイプライター ── */
const MODERN_CONCEPTS = [
  "早期切り替え",
  "圧の流れ",
  "低重心",
  "たわみ利用",
  "斜め前運動",
  "自然な連鎖",
];

function TypewriterCycle() {
  const [idx, setIdx] = useState(0);
  const [shown, setShown] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setShown(false);
      setTimeout(() => {
        setIdx((i) => (i + 1) % MODERN_CONCEPTS.length);
        setShown(true);
      }, 300);
    }, 2200);
    return () => clearInterval(interval);
  }, []);

  return (
    <span
      className="inline-block font-mono text-cyan-400/80 tracking-widest transition-opacity duration-300"
      style={{ opacity: shown ? 1 : 0, minWidth: "8ch" }}
    >
      {MODERN_CONCEPTS[idx]}
    </span>
  );
}

/* ── 雪面軌道SVG（アニメーション付き） ── */
function SkiTrackSVG() {
  const [draw, setDraw] = useState(false);
  useEffect(() => { setTimeout(() => setDraw(true), 500); }, []);

  return (
    <svg viewBox="0 0 320 640" fill="none" className="w-full h-full" aria-hidden="true">
      {/* 斜面ライン */}
      {[0, 1, 2, 3, 4].map(i => (
        <line key={i} x1={0} y1={120 + i * 90} x2={320} y2={130 + i * 90}
          stroke="white" strokeOpacity="0.04" strokeWidth="1" />
      ))}

      {/* メイントラック */}
      <path
        d="M160 30 Q230 90 200 180 Q170 270 260 330 Q310 360 275 440 Q240 510 160 540 Q90 570 130 620"
        stroke="white" strokeWidth="1.2" fill="none"
        style={{
          strokeDasharray: 900,
          strokeDashoffset: draw ? 0 : 900,
          transition: "stroke-dashoffset 3.5s cubic-bezier(0.4,0,0.2,1)",
        }}
      />
      {/* シャドウトラック */}
      <path
        d="M148 30 Q218 90 188 180 Q158 270 248 330 Q298 360 263 440 Q228 510 148 540"
        stroke="white" strokeWidth="0.6" fill="none" strokeOpacity="0.25"
        style={{
          strokeDasharray: 900,
          strokeDashoffset: draw ? 0 : 900,
          transition: "stroke-dashoffset 3.5s cubic-bezier(0.4,0,0.2,1) 0.2s",
        }}
      />

      {/* 早期切り替えポイントマーカー */}
      {draw && [
        { x: 200, y: 180, label: "早期切り替え" },
        { x: 260, y: 330, label: "圧のピーク" },
        { x: 130, y: 540, label: "たわみ解放" },
      ].map((pt, i) => (
        <g key={i} style={{ opacity: 0, animation: `fadeIn 0.5s ${1.5 + i * 0.5}s forwards` }}>
          <circle cx={pt.x} cy={pt.y} r="3.5" fill="none" stroke="#22d3ee" strokeWidth="1" strokeOpacity="0.6" />
          <circle cx={pt.x} cy={pt.y} r="1.5" fill="#22d3ee" fillOpacity="0.5" />
        </g>
      ))}

      <style>{`@keyframes fadeIn { to { opacity: 1; } }`}</style>
    </svg>
  );
}

const ROUTES = [
  { label: "初心者", sub: "入門・初級", color: "#4ade80", href: "/routes/beginner" },
  { label: "中級者", sub: "壁を超える", color: "#facc15", href: "/routes/intermediate" },
  { label: "技術選", sub: "2026年採点対応", color: "#f87171", href: "/routes/technical", badge: "NEW" },
  { label: "アルペン", sub: "競技技術", color: "#60a5fa", href: "/routes/alpine" },
  { label: "コブ・地形", sub: "雪面処理", color: "#f87171", href: "/routes/mogul", badge: "NEW" },
];

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex flex-col justify-center overflow-hidden bg-[#050505]">
      {/* グリッド */}
      <div className="absolute inset-0" style={{
        backgroundImage: "linear-gradient(rgba(255,255,255,0.02) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.02) 1px,transparent 1px)",
        backgroundSize: "56px 56px",
      }} />
      {/* ラジアルフェード */}
      <div className="absolute inset-0" style={{
        background: "radial-gradient(ellipse 90% 65% at 40% 50%,transparent 20%,#050505 100%)"
      }} />
      {/* シアンのアクセントグロー（左下） */}
      <div className="absolute bottom-0 left-0 w-64 h-64 pointer-events-none" style={{
        background: "radial-gradient(ellipse at 0% 100%, rgba(34,211,238,0.06) 0%, transparent 70%)"
      }} />

      {/* トラックSVG */}
      <div className="absolute right-0 top-0 bottom-0 w-[44%] opacity-[0.18] hidden lg:block pointer-events-none">
        <SkiTrackSVG />
      </div>

      {/* メインコンテンツ */}
      <div className="relative z-10 max-w-8xl mx-auto px-6 md:px-10 pt-28 pb-20">
        <div className="max-w-3xl">
          {/* 年号バッジ */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="flex items-center gap-3 mb-8"
          >
            <div className="w-8 h-px bg-white/15" />
            <span className="font-mono text-[9px] text-white/30 tracking-[0.25em] uppercase">
              Ski &amp; Snowboard Technical Media
            </span>
            <span className="font-mono text-[8px] text-cyan-400/60 border border-cyan-500/25 px-2 py-0.5 tracking-widest">
              2026
            </span>
          </motion.div>

          {/* ヘッドライン */}
          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="font-display font-black leading-[1.04] mb-8"
            style={{ fontSize: "clamp(42px, 7vw, 96px)" }}
          >
            <span className="text-white/85">なぜ板が</span>
            <br />
            <span style={{
              background: "linear-gradient(135deg,#fff 0%,#555 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>曲がるのか</span>
            <br />
            <span className="text-white/85">を理解する。</span>
          </motion.h1>

          {/* サブコピー + タイプライター */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.38 }}
            className="mb-10"
          >
            <p className="text-white/38 text-base md:text-lg leading-relaxed mb-3">
              感覚論から脱却し、2026年基準の現代技術論で滑りを分解する。
            </p>
            <p className="flex items-center gap-2 text-sm text-white/30">
              <span className="font-mono text-[10px] text-white/20 tracking-widest">FOCUS</span>
              <TypewriterCycle />
            </p>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.52 }}
            className="flex flex-col sm:flex-row gap-3 mb-16"
          >
            <Link href="#start"
              className="inline-flex items-center gap-2 bg-white text-black px-7 py-3.5 text-sm font-bold tracking-wider hover:bg-white/88 transition-colors">
              あなたのレベルから始める <ArrowRight size={14} />
            </Link>
            <Link href="/categories/modern-technique"
              className="inline-flex items-center gap-2 border border-cyan-500/30 text-cyan-400/70 px-7 py-3.5 text-sm font-medium tracking-wider hover:border-cyan-400/50 hover:text-cyan-300/90 transition-all">
              2022年以降の技術変化を見る
            </Link>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.72 }}
            className="flex gap-10 flex-wrap"
          >
            {[
              ["150+", "技術記事"],
              ["16", "カテゴリ"],
              ["4", "新カテゴリ"],
              ["2026", "年基準"],
            ].map(([num, label]) => (
              <div key={label}>
                <div className="font-display font-black text-white/80 text-2xl md:text-3xl">{num}</div>
                <div className="font-mono text-[9px] text-white/20 tracking-widest mt-1">{label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* スクロールインジケーター */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="font-mono text-[8px] text-white/15 tracking-[0.3em]">SCROLL</span>
        <div className="w-px h-10 bg-gradient-to-b from-white/15 to-transparent" />
      </motion.div>
    </section>
  );
}

export function LevelSelector() {
  return (
    <section id="start" className="bg-[#050505] border-t border-white/4 py-16">
      <div className="max-w-8xl mx-auto px-6 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-8"
        >
          <p className="font-mono text-[9px] text-white/20 tracking-[0.2em] uppercase mb-3">Find Your Route</p>
          <h2 className="font-display font-bold text-white text-3xl md:text-4xl">どこから始めますか？</h2>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-px bg-white/4">
          {ROUTES.map((route, i) => (
            <motion.div
              key={route.label}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
            >
              <Link href={route.href}
                className="group relative flex flex-col p-6 bg-[#070707] hover:bg-[#0c0c0c] transition-all duration-250 h-full min-h-[160px]">
                {/* アクセントライン */}
                <div className="absolute top-0 left-0 right-0 h-[2px] transition-opacity duration-300 opacity-30 group-hover:opacity-80"
                  style={{ background: route.color }} />
                <div className="font-display font-black text-xl mb-1 transition-colors duration-200 text-white/65 group-hover:text-white/90"
                  style={{ color: undefined }}>
                  {route.label}
                </div>
                <div className="font-mono text-[9px] text-white/25 tracking-widest mb-3">{route.sub}</div>
                {route.badge && (
                  <span className="self-start font-mono text-[7px] px-1.5 py-0.5 border border-cyan-500/30 text-cyan-400/60 mb-2">
                    {route.badge}
                  </span>
                )}
                <div className="mt-auto font-mono text-[9px] text-white/20 group-hover:text-white/50 transition-colors flex items-center gap-1">
                  開始 <ArrowRight size={10} className="group-hover:translate-x-0.5 transition-transform" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
