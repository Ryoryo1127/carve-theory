"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { TECH_PRINCIPLES } from "@/lib/constants";
import { ArrowRight } from "lucide-react";

export function TechPrinciples() {
  return (
    <section className="bg-[#080808] border-t border-white/5 py-20">
      <div className="max-w-8xl mx-auto px-6 md:px-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-12"
        >
          <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-3">
            Core Principles
          </p>
          <h2 className="font-display font-bold text-white text-3xl md:text-4xl mb-4">
            すべての記事が扱う<br className="sm:hidden" />
            技術の核心
          </h2>
          <p className="text-white/35 text-sm max-w-lg leading-relaxed">
            この6つの要素が理解できると、あらゆる雪面・斜度・速度への対応が変わる。
            記事を読む前に、まずここを把握しておく。
          </p>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5">
          {TECH_PRINCIPLES.map((principle, i) => (
            <PrincipleCard key={principle.id} principle={principle} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function PrincipleCard({
  principle,
  index,
}: {
  principle: (typeof TECH_PRINCIPLES)[0];
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.07 }}
      className="group bg-[#0a0a0a] hover:bg-[#0e0e0e] transition-colors duration-300 p-7 relative overflow-hidden"
    >
      {/* Large number watermark */}
      <div className="absolute top-3 right-4 font-display font-black text-[80px] text-white/[0.025] leading-none select-none">
        {String(index + 1).padStart(2, "0")}
      </div>

      <div className="relative z-10">
        <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-3">
          {principle.titleEn}
        </p>
        <h3 className="font-display font-bold text-white/80 group-hover:text-white text-2xl mb-4 transition-colors">
          {principle.title}
        </h3>
        <p className="text-white/40 text-sm leading-relaxed mb-6">
          {principle.description}
        </p>

        {principle.articleSlugs.length > 0 && (
          <Link
            href={`/articles/${principle.articleSlugs[0]}`}
            className="flex items-center gap-1.5 text-white/30 hover:text-white/70 text-xs tracking-wider transition-colors group/link"
          >
            関連記事を読む
            <ArrowRight
              size={11}
              className="group-hover/link:translate-x-0.5 transition-transform"
            />
          </Link>
        )}
      </div>
    </motion.div>
  );
}
