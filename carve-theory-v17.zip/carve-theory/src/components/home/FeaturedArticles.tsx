"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Clock } from "lucide-react";
import { ArticleCard } from "@/components/article/ArticleCard";
import { LevelBadge, RouteBadge } from "@/components/ui/Badge";
import { getCategoryBySlug, truncate } from "@/lib/utils";
import type { ArticleMeta } from "@/types";

interface FeaturedArticlesProps {
  articles: ArticleMeta[];
}

export function FeaturedArticles({ articles }: FeaturedArticlesProps) {
  const [hero, ...rest] = articles;
  if (!hero) return null;

  const heroCategory = getCategoryBySlug(hero.category);

  return (
    <section className="bg-[#060606] border-t border-white/5 py-20">
      <div className="max-w-8xl mx-auto px-6 md:px-10">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex items-end justify-between mb-10"
        >
          <div>
            <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-3">
              Featured Articles
            </p>
            <h2 className="font-display font-bold text-white text-3xl md:text-4xl">
              注目の技術解説
            </h2>
          </div>
          <Link
            href="/articles"
            className="hidden md:flex items-center gap-2 text-white/35 hover:text-white/70 text-xs tracking-wider transition-colors group"
          >
            すべて見る
            <ArrowRight
              size={12}
              className="group-hover:translate-x-0.5 transition-transform"
            />
          </Link>
        </motion.div>

        {/* Main grid */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-px bg-white/5">
          {/* Hero article */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-3"
          >
            <Link
              href={`/articles/${hero.slug}`}
              className="group relative flex flex-col justify-end p-8 md:p-10 bg-[#0a0a0a] hover:bg-[#0d0d0d] transition-all duration-300 h-full min-h-[400px] overflow-hidden"
            >
              {/* Background decoration */}
              <div className="absolute inset-0 opacity-[0.04]">
                <svg width="100%" height="100%">
                  <defs>
                    <pattern id="hero-grid" width="48" height="48" patternUnits="userSpaceOnUse">
                      <path d="M 48 0 L 0 0 0 48" fill="none" stroke="white" strokeWidth="0.5" />
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#hero-grid)" />
                </svg>
              </div>

              {/* Animated ski path */}
              <div className="absolute top-0 right-0 bottom-0 w-1/2 opacity-[0.06] pointer-events-none">
                <svg viewBox="0 0 200 400" className="w-full h-full">
                  <path
                    d="M 100 20 Q 160 80 130 160 Q 100 240 170 300 Q 200 330 170 380"
                    stroke="white"
                    strokeWidth="1.5"
                    fill="none"
                    className="ski-track"
                  />
                </svg>
              </div>

              {/* Accent bar */}
              <div
                className="absolute top-0 left-0 right-0 h-[2px]"
                style={{
                  background: heroCategory?.color ?? "white",
                  opacity: 0.7,
                }}
              />

              {/* Category top-right */}
              <div className="absolute top-6 right-8">
                <span className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase">
                  {heroCategory?.labelEn ?? "Article"}
                </span>
              </div>

              {/* Content */}
              <div className="relative z-10">
                <div className="flex flex-wrap gap-2 mb-5">
                  <LevelBadge level={hero.level} />
                  <RouteBadge route={hero.route} />
                  <span className="font-mono-custom text-[9px] text-white/15 tracking-widest uppercase border border-white/8 px-2 py-0.5">
                    CORE
                  </span>
                </div>

                <h2 className="font-display font-black text-white text-2xl md:text-4xl leading-tight mb-3 group-hover:text-white/90 transition-colors">
                  {hero.title}
                </h2>
                <p className="text-white/40 text-sm mb-4">{hero.subtitle}</p>
                <p className="text-white/30 text-sm leading-relaxed mb-8 max-w-lg">
                  {truncate(hero.excerpt, 100)}
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-white/25">
                    <Clock size={12} />
                    <span className="font-mono-custom text-[10px]">
                      {hero.readTime}分
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-white/50 group-hover:text-white text-sm font-medium transition-colors">
                    読む
                    <ArrowRight
                      size={14}
                      className="group-hover:translate-x-1 transition-transform"
                    />
                  </div>
                </div>
              </div>
            </Link>
          </motion.div>

          {/* Sub articles */}
          <div className="lg:col-span-2 flex flex-col gap-px">
            {rest.slice(0, 3).map((article, i) => (
              <ArticleCard
                key={article.slug}
                article={article}
                variant="featured"
                index={i}
                className="flex-1"
              />
            ))}
          </div>
        </div>

        {/* Mobile: show all button */}
        <div className="mt-8 md:hidden">
          <Link
            href="/articles"
            className="flex items-center justify-center gap-2 border border-white/10 text-white/50 py-3 text-sm hover:border-white/20 hover:text-white/70 transition-all"
          >
            すべての記事を見る
            <ArrowRight size={12} />
          </Link>
        </div>
      </div>
    </section>
  );
}
