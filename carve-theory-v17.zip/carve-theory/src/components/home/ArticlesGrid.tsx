"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { ArticleCard } from "@/components/article/ArticleCard";
import { cn } from "@/lib/utils";
import { CATEGORIES } from "@/lib/constants";
import type { ArticleMeta, LevelType, RouteType } from "@/types";

const LEVELS: LevelType[] = ["初級", "中級", "上級", "競技"];
const ROUTES: RouteType[] = ["スキー", "技術選", "アルペン", "スノーボード"];

interface ArticlesGridProps {
  articles: ArticleMeta[];
  showFilters?: boolean;
  title?: string;
}

export function ArticlesGrid({
  articles,
  showFilters = true,
  title = "技術記事データベース",
}: ArticlesGridProps) {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedLevel, setSelectedLevel] = useState<string>("all");
  const [selectedRoute, setSelectedRoute] = useState<string>("all");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const filtered = useMemo(() => {
    return articles.filter((a) => {
      if (selectedCategory !== "all" && a.category !== selectedCategory) return false;
      if (selectedLevel !== "all" && a.level !== selectedLevel) return false;
      if (selectedRoute !== "all" && a.route !== selectedRoute) return false;
      if (query) {
        const q = query.toLowerCase();
        return (
          a.title.toLowerCase().includes(q) ||
          a.excerpt.toLowerCase().includes(q) ||
          a.tags.some((t) => t.toLowerCase().includes(q)) ||
          a.subtitle.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [articles, query, selectedCategory, selectedLevel, selectedRoute]);

  const hasActiveFilters =
    selectedCategory !== "all" ||
    selectedLevel !== "all" ||
    selectedRoute !== "all" ||
    query;

  function clearFilters() {
    setQuery("");
    setSelectedCategory("all");
    setSelectedLevel("all");
    setSelectedRoute("all");
  }

  return (
    <section className="bg-[#060606] border-t border-white/5 py-20">
      <div className="max-w-8xl mx-auto px-6 md:px-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-10"
        >
          <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-3">
            All Articles
          </p>
          <h2 className="font-display font-bold text-white text-3xl md:text-4xl mb-2">
            {title}
          </h2>
        </motion.div>

        {showFilters && (
          <div className="mb-8 space-y-4">
            {/* Search + filter toggle */}
            <div className="flex gap-3">
              <div className="flex-1 relative">
                <Search
                  size={14}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-white/25"
                />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="キーワード検索：カービング、後傾、エッジング…"
                  className="w-full bg-[#0d0d0d] border border-white/8 text-white/80 placeholder:text-white/20 text-sm pl-10 pr-4 py-3 outline-none focus:border-white/20 transition-colors font-body"
                />
              </div>
              <button
                onClick={() => setFiltersOpen(!filtersOpen)}
                className={cn(
                  "flex items-center gap-2 px-4 py-3 border text-xs font-mono-custom tracking-widest uppercase transition-all",
                  filtersOpen || hasActiveFilters
                    ? "border-white/30 text-white/70 bg-white/5"
                    : "border-white/8 text-white/30 hover:border-white/20 hover:text-white/50"
                )}
              >
                <SlidersHorizontal size={13} />
                <span className="hidden sm:inline">フィルター</span>
              </button>
              {hasActiveFilters && (
                <button
                  onClick={clearFilters}
                  className="flex items-center gap-1.5 px-4 py-3 border border-white/8 text-white/30 hover:text-white/60 text-xs font-mono-custom tracking-widest transition-colors"
                >
                  <X size={12} />
                  <span className="hidden sm:inline">クリア</span>
                </button>
              )}
            </div>

            {/* Expandable filters */}
            <AnimatePresence>
              {filtersOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="bg-[#0a0a0a] border border-white/5 p-5 space-y-4">
                    {/* Category */}
                    <FilterRow
                      label="カテゴリ"
                      value={selectedCategory}
                      onChange={setSelectedCategory}
                      options={[
                        { value: "all", label: "すべて" },
                        ...CATEGORIES.map((c) => ({
                          value: c.slug,
                          label: c.label,
                        })),
                      ]}
                    />
                    {/* Level */}
                    <FilterRow
                      label="レベル"
                      value={selectedLevel}
                      onChange={setSelectedLevel}
                      options={[
                        { value: "all", label: "すべて" },
                        ...LEVELS.map((l) => ({ value: l, label: l })),
                      ]}
                    />
                    {/* Route */}
                    <FilterRow
                      label="種別"
                      value={selectedRoute}
                      onChange={setSelectedRoute}
                      options={[
                        { value: "all", label: "すべて" },
                        ...ROUTES.map((r) => ({ value: r, label: r })),
                      ]}
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* Count */}
        <div className="flex items-center gap-3 mb-6">
          <span className="font-mono-custom text-[10px] text-white/25 tracking-widest">
            {filtered.length} 記事
          </span>
          {hasActiveFilters && (
            <span className="font-mono-custom text-[9px] text-white/20 border border-white/8 px-2 py-0.5">
              フィルター適用中
            </span>
          )}
        </div>

        {/* Articles grid */}
        <AnimatePresence mode="popLayout">
          {filtered.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-px bg-white/5">
              {filtered.map((article, i) => (
                <ArticleCard
                  key={article.slug}
                  article={article}
                  variant="default"
                  index={i}
                />
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="py-20 text-center"
            >
              <p className="font-mono-custom text-[10px] text-white/20 tracking-widest mb-3">
                NO RESULTS
              </p>
              <p className="text-white/35 text-sm">
                条件に合う記事が見つかりませんでした。
              </p>
              <button
                onClick={clearFilters}
                className="mt-4 text-xs text-white/30 hover:text-white/60 underline underline-offset-4 transition-colors"
              >
                フィルターをリセット
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}

function FilterRow({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div className="flex items-start gap-4">
      <span className="font-mono-custom text-[9px] text-white/25 tracking-widest uppercase w-16 flex-shrink-0 pt-1.5">
        {label}
      </span>
      <div className="flex flex-wrap gap-2">
        {options.map((opt) => (
          <button
            key={opt.value}
            onClick={() => onChange(opt.value)}
            className={cn(
              "px-3 py-1 text-[10px] font-mono-custom tracking-wider border transition-all duration-150",
              value === opt.value
                ? "bg-white text-black border-white"
                : "bg-transparent border-white/10 text-white/35 hover:border-white/25 hover:text-white/60"
            )}
          >
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  );
}
