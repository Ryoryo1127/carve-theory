"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { SNOW_CONDITIONS } from "@/lib/constants";

export function SnowConditions() {
  return (
    <section className="bg-[#060606] border-t border-white/5 py-20">
      <div className="max-w-8xl mx-auto px-6 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-10"
        >
          <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-3">
            Snow Conditions
          </p>
          <h2 className="font-display font-bold text-white text-3xl md:text-4xl mb-3">
            雪質別技術ガイド
          </h2>
          <p className="text-white/35 text-sm max-w-lg leading-relaxed">
            同じ技術が通用しなくなる最大の変数は雪質だ。
            今日の雪面に合わせた滑り方を確認する。
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-px bg-white/5">
          {SNOW_CONDITIONS.map((condition, i) => (
            <ConditionCard key={condition.slug} condition={condition} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ConditionCard({
  condition,
  index,
}: {
  condition: (typeof SNOW_CONDITIONS)[0];
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.06 }}
    >
      <Link
        href={`/snow-conditions/${condition.slug}`}
        className="group flex flex-col p-6 bg-[#0a0a0a] hover:bg-[#0e0e0e] transition-colors duration-300 h-full"
      >
        {/* Difficulty dots */}
        <div className="flex gap-1 mb-5">
          {Array.from({ length: 5 }).map((_, i) => (
            <div
              key={i}
              className={`w-1.5 h-1.5 rounded-full transition-colors duration-200 ${
                i < condition.difficulty
                  ? "bg-white/50 group-hover:bg-white/70"
                  : "bg-white/8"
              }`}
            />
          ))}
        </div>

        <h3 className="font-display font-bold text-white/80 group-hover:text-white text-xl mb-2 transition-colors">
          {condition.label}
        </h3>
        <p className="text-white/30 text-xs mb-4 leading-relaxed">
          {condition.description}
        </p>

        {/* Tips */}
        <ul className="space-y-2 mb-5">
          {condition.tips.slice(0, 2).map((tip) => (
            <li key={tip} className="flex items-start gap-2 text-xs text-white/30">
              <span className="text-white/15 font-mono-custom mt-0.5 flex-shrink-0">─</span>
              <span className="leading-relaxed">{tip}</span>
            </li>
          ))}
        </ul>

        <div className="mt-auto flex items-center gap-1.5 text-white/20 group-hover:text-white/50 text-xs transition-colors">
          詳しく見る
          <ArrowRight
            size={11}
            className="group-hover:translate-x-0.5 transition-transform"
          />
        </div>
      </Link>
    </motion.div>
  );
}
