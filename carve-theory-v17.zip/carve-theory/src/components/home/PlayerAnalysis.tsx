"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { PLAYERS } from "@/lib/constants";
import type { Player } from "@/types";

export function PlayerAnalysis() {
  const [selected, setSelected] = useState(0);
  const player = PLAYERS[selected];

  return (
    <section
      id="players"
      className="bg-[#080808] border-t border-white/5 py-20"
    >
      <div className="max-w-8xl mx-auto px-6 md:px-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-10"
        >
          <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-3">
            Player Analysis
          </p>
          <h2 className="font-display font-bold text-white text-3xl md:text-4xl mb-3">
            選手分析
          </h2>
          <p className="text-white/35 text-sm max-w-lg leading-relaxed">
            名前を出して終わりにしない。どこが違うのか、なぜ安定して見えるのか——
            滑りを構成する要素ごとに分解する。
          </p>
        </motion.div>

        {/* Selector tabs */}
        <div className="flex gap-px mb-px bg-white/5 overflow-x-auto">
          {PLAYERS.map((p, i) => (
            <button
              key={p.id}
              onClick={() => setSelected(i)}
              className={`
                relative flex-1 min-w-[140px] py-4 px-5 text-left transition-all duration-200
                ${selected === i ? "bg-[#0e0e0e]" : "bg-[#0a0a0a] hover:bg-[#0c0c0c]"}
              `}
            >
              {/* Active indicator */}
              <div
                className="absolute top-0 left-0 right-0 h-[2px] transition-opacity duration-200"
                style={{
                  background: p.color,
                  opacity: selected === i ? 1 : 0,
                }}
              />
              <div
                className={`font-display font-bold text-base transition-colors duration-200 ${
                  selected === i ? "text-white" : "text-white/40"
                }`}
              >
                {p.name}
              </div>
              <div className="font-mono-custom text-[9px] text-white/25 tracking-wider mt-0.5">
                {p.discipline}
              </div>
            </button>
          ))}
        </div>

        {/* Detail panel */}
        <AnimatePresence mode="wait">
          <motion.div
            key={selected}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25 }}
          >
            <PlayerDetail player={player} />
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}

function PlayerDetail({ player }: { player: Player }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-px bg-white/5">
      {/* Traits panel */}
      <div className="lg:col-span-3 bg-[#0a0a0a] p-8">
        <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-7">
          Technical Profile
        </p>

        <div className="space-y-7">
          {player.traits.map((trait, i) => (
            <TraitBar key={trait.label} trait={trait} color={player.color} index={i} />
          ))}
        </div>

        {/* Edge timing diagram */}
        <div className="mt-10 pt-8 border-t border-white/5">
          <p className="font-mono-custom text-[9px] text-white/20 tracking-widest uppercase mb-5">
            Edge Timing Comparison
          </p>
          <EdgeTimingDiagram player={player} />
        </div>
      </div>

      {/* Signature / quote panel */}
      <div className="lg:col-span-2 bg-[#0c0c0c] p-8 flex flex-col">
        {/* Badge */}
        <div
          className="inline-flex items-center gap-2 mb-6 px-3 py-1.5 self-start border"
          style={{ borderColor: `${player.color}33`, color: player.color }}
        >
          <span className="font-mono-custom text-[9px] tracking-widest uppercase">
            {player.route}
          </span>
          <span className="text-current opacity-50">·</span>
          <span className="font-mono-custom text-[9px] tracking-widest">
            {player.nationality}
          </span>
        </div>

        {/* Name large */}
        <div className="mb-6">
          <h3 className="font-display font-black text-white text-3xl mb-1">
            {player.name}
          </h3>
          <p className="font-mono-custom text-[10px] text-white/25 tracking-wider">
            {player.nameEn}
          </p>
          <p className="text-white/35 text-xs mt-1">{player.discipline}</p>
        </div>

        {/* Signature quote */}
        <blockquote
          className="flex-1 text-white/60 text-sm leading-[1.9] border-l-2 pl-5 mb-8"
          style={{ borderColor: player.color }}
        >
          {player.signature}
        </blockquote>

        {/* Related articles */}
        <div>
          <p className="font-mono-custom text-[9px] text-white/20 tracking-widest uppercase mb-4">
            Related Articles
          </p>
          <div className="space-y-2">
            {player.articles.slice(0, 2).map((slug) => (
              <Link
                key={slug}
                href={`/articles/${slug}`}
                className="flex items-center gap-2 text-white/35 hover:text-white/70 text-xs transition-colors group"
              >
                <ArrowRight
                  size={11}
                  className="flex-shrink-0 group-hover:translate-x-0.5 transition-transform"
                />
                <span className="line-clamp-1">{slug.replace(/-/g, " ")}</span>
              </Link>
            ))}
          </div>

          <Link
            href="/players"
            className="flex items-center gap-2 mt-6 text-white/25 hover:text-white/60 text-xs font-mono-custom tracking-wider uppercase transition-colors group"
          >
            全選手分析を見る
            <ArrowRight
              size={11}
              className="group-hover:translate-x-0.5 transition-transform"
            />
          </Link>
        </div>
      </div>
    </div>
  );
}

function TraitBar({
  trait,
  color,
  index,
}: {
  trait: Player["traits"][0];
  color: string;
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -12 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.07 }}
    >
      <div className="flex justify-between items-center mb-2">
        <span className="text-white/70 text-sm font-medium">{trait.label}</span>
        <span
          className="font-mono-custom text-sm font-bold"
          style={{ color }}
        >
          {trait.value}
        </span>
      </div>
      <div className="h-px bg-white/8 mb-2 relative overflow-hidden">
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: index * 0.1, ease: "easeOut" }}
          className="absolute inset-y-0 left-0 origin-left"
          style={{
            width: `${trait.value}%`,
            background: `linear-gradient(90deg, ${color}66, ${color})`,
            height: "1px",
            top: 0,
          }}
        />
      </div>
      <p className="text-white/30 text-xs leading-relaxed">{trait.description}</p>
    </motion.div>
  );
}

function EdgeTimingDiagram({ player }: { player: Player }) {
  return (
    <svg viewBox="0 0 400 120" className="w-full" aria-label="エッジングタイミング比較図">
      {/* Grid */}
      {[0, 1, 2, 3].map((i) => (
        <line
          key={i}
          x1={40 + i * 90}
          y1="10"
          x2={40 + i * 90}
          y2="90"
          stroke="white"
          strokeWidth="0.3"
          strokeOpacity="0.08"
        />
      ))}
      {[30, 60, 90].map((y) => (
        <line
          key={y}
          x1="30"
          y1={y}
          x2="370"
          y2={y}
          stroke="white"
          strokeWidth="0.3"
          strokeOpacity="0.06"
        />
      ))}

      {/* Labels */}
      <text x="40" y="108" fill="rgba(255,255,255,0.2)" fontSize="8" fontFamily="monospace">
        TURN START
      </text>
      <text x="160" y="108" fill="rgba(255,255,255,0.2)" fontSize="8" fontFamily="monospace">
        FALL LINE
      </text>
      <text x="280" y="108" fill="rgba(255,255,255,0.2)" fontSize="8" fontFamily="monospace">
        FINISH
      </text>

      {/* General skier line */}
      <path
        d="M 40 85 Q 90 80 150 60 Q 200 42 250 35 Q 300 30 360 32"
        stroke="white"
        strokeWidth="1"
        fill="none"
        strokeOpacity="0.15"
        strokeDasharray="4 3"
      />

      {/* Player line */}
      <path
        d="M 40 85 Q 75 65 110 42 Q 150 22 200 18 Q 260 15 360 18"
        stroke={player.color}
        strokeWidth="1.5"
        fill="none"
        strokeOpacity="0.8"
      />

      {/* Legends */}
      <circle cx="30" cy="18" r="2" fill={player.color} fillOpacity="0.8" />
      <text x="35" y="22" fill={player.color} fontSize="7.5" fontFamily="monospace" fillOpacity="0.8">
        {player.name}
      </text>

      <line x1="27" y1="35" x2="33" y2="35" stroke="white" strokeWidth="0.8" strokeOpacity="0.2" strokeDasharray="3 2" />
      <text x="35" y="39" fill="rgba(255,255,255,0.2)" fontSize="7.5" fontFamily="monospace">
        一般スキーヤー
      </text>

      {/* Y-axis label */}
      <text
        x="8"
        y="55"
        fill="rgba(255,255,255,0.15)"
        fontSize="7"
        fontFamily="monospace"
        transform="rotate(-90, 8, 55)"
        textAnchor="middle"
      >
        EDGE ANGLE
      </text>
    </svg>
  );
}
