"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import type { MogulLineAnalysis } from "@/types";
import { MOGUL_PHASES } from "@/lib/constants";

interface MogulAnalysisUIProps {
  phases?: MogulLineAnalysis[];
  className?: string;
}

const PRESSURE_CONFIG = {
  loading: { label: "荷重中", color: "#60a5fa", intensity: 0.85 },
  neutral: { label: "中立", color: "rgba(255,255,255,0.4)", intensity: 0.3 },
  releasing: { label: "解放", color: "#34d399", intensity: 0.6 },
};

const PHASE_POSITION: Record<MogulLineAnalysis["phase"], number> = {
  approach: 0,
  absorption: 1,
  contact: 2,
  extension: 3,
  exit: 4,
};

export function MogulAnalysisUI({
  phases = MOGUL_PHASES,
  className,
}: MogulAnalysisUIProps) {
  const [active, setActive] = useState<number>(0);
  const activePhase = phases[active]!;
  const pressureCfg = PRESSURE_CONFIG[activePhase.pressureState];

  return (
    <div className={cn("my-12", className)}>
      {/* ヘッダー */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-5 h-px bg-white/20" />
        <span className="font-mono text-[9px] text-white/30 tracking-[0.2em] uppercase">
          Mogul Processing
        </span>
        <div className="flex-1 h-px bg-white/5" />
        <span className="font-mono text-[8px] text-red-400/60 tracking-widest">
          TERRAIN ANALYSIS
        </span>
      </div>

      <h4 className="font-display font-bold text-xl text-white/80 mb-6">
        コブ雪面処理の5フェーズ
      </h4>

      <div className="border border-white/8 bg-[#080808] overflow-hidden">
        {/* コブの断面図 */}
        <div className="relative h-24 border-b border-white/5 overflow-hidden">
          <MogulSectionSVG activePhase={active} />
        </div>

        {/* フェーズタブ */}
        <div className="flex border-b border-white/5">
          {phases.map((phase, i) => {
            const pc = PRESSURE_CONFIG[phase.pressureState];
            const isActive = active === i;
            return (
              <button
                key={phase.phase}
                onClick={() => setActive(i)}
                className={cn(
                  "flex-1 py-3 px-2 text-center transition-all duration-150 border-b-2 relative",
                  isActive
                    ? "bg-white/[0.05] border-current"
                    : "border-transparent hover:bg-white/[0.02]"
                )}
                style={isActive ? { borderBottomColor: pc.color } : {}}
              >
                <div
                  className="font-mono text-[8px] tracking-widest uppercase"
                  style={{ color: isActive ? pc.color : "rgba(255,255,255,0.2)" }}
                >
                  {String(i + 1).padStart(2, "0")}
                </div>
                <div
                  className="font-display font-bold text-xs mt-0.5 hidden sm:block"
                  style={{ color: isActive ? "rgba(255,255,255,0.8)" : "rgba(255,255,255,0.3)" }}
                >
                  {phase.label}
                </div>
              </button>
            );
          })}
        </div>

        {/* アクティブフェーズの詳細 */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="p-5 grid sm:grid-cols-[1fr_200px] gap-6"
          >
            {/* テキスト部分 */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <span
                  className="font-mono text-[9px] tracking-widest uppercase"
                  style={{ color: pressureCfg.color }}
                >
                  PHASE {active + 1} — {activePhase.label}
                </span>
              </div>
              <p className="text-sm text-white/65 leading-[1.85] mb-4">
                {activePhase.description}
              </p>

              <div className="space-y-2">
                <div>
                  <span className="font-mono text-[8px] text-white/20 tracking-widest uppercase">
                    注目部位
                  </span>
                  <p className="text-xs text-white/50 mt-1">{activePhase.bodyFocus}</p>
                </div>
              </div>
            </div>

            {/* 圧力インジケーター */}
            <div className="flex flex-col items-center justify-center gap-4">
              <div className="relative w-24 h-24">
                {/* 背景円 */}
                <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                  <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6" />
                  <motion.circle
                    cx="50" cy="50" r="40"
                    fill="none"
                    strokeWidth="6"
                    strokeLinecap="round"
                    stroke={pressureCfg.color}
                    strokeDasharray={`${2 * Math.PI * 40}`}
                    initial={{ strokeDashoffset: 2 * Math.PI * 40 }}
                    animate={{
                      strokeDashoffset: 2 * Math.PI * 40 * (1 - pressureCfg.intensity),
                    }}
                    transition={{ duration: 0.5, ease: "easeOut" }}
                  />
                </svg>
                {/* 中央テキスト */}
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span
                    className="font-mono font-bold text-lg tabular-nums"
                    style={{ color: pressureCfg.color }}
                  >
                    {Math.round(pressureCfg.intensity * 100)}
                  </span>
                  <span className="font-mono text-[7px] text-white/20 tracking-widest">%</span>
                </div>
              </div>
              <div className="text-center">
                <div
                  className="font-mono text-[9px] tracking-widest uppercase"
                  style={{ color: pressureCfg.color }}
                >
                  {pressureCfg.label}
                </div>
                <div className="font-mono text-[8px] text-white/20 mt-0.5">
                  圧力状態
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* ナビゲーション */}
        <div className="border-t border-white/5 px-5 py-3 flex items-center justify-between">
          <button
            onClick={() => setActive(Math.max(0, active - 1))}
            disabled={active === 0}
            className="font-mono text-[9px] text-white/25 hover:text-white/60 disabled:opacity-20 tracking-widest transition-colors"
          >
            ← PREV
          </button>
          <div className="flex gap-1.5">
            {phases.map((_, i) => (
              <button
                key={i}
                onClick={() => setActive(i)}
                className="w-1.5 h-1.5 rounded-full transition-all"
                style={{
                  background: i === active ? pressureCfg.color : "rgba(255,255,255,0.12)",
                  transform: i === active ? "scale(1.3)" : "scale(1)",
                }}
              />
            ))}
          </div>
          <button
            onClick={() => setActive(Math.min(phases.length - 1, active + 1))}
            disabled={active === phases.length - 1}
            className="font-mono text-[9px] text-white/25 hover:text-white/60 disabled:opacity-20 tracking-widest transition-colors"
          >
            NEXT →
          </button>
        </div>
      </div>

      {/* コブ技術の汎用性メモ */}
      <div className="mt-4 border border-red-500/15 bg-red-950/8 px-5 py-4">
        <div className="flex items-start gap-3">
          <div className="w-px self-stretch bg-red-500/30 flex-shrink-0" />
          <div>
            <p className="font-mono text-[8px] text-red-400/50 tracking-widest uppercase mb-2">
              現代的理解
            </p>
            <p className="text-xs text-white/50 leading-relaxed">
              コブで身につく技術——吸収・ライン読み・下半身独立・圧のコントロール——は急斜面・パウダー・不整地に直接転用できる。
              コブは特殊競技ではなく、あらゆる地形への適応力を高める最良のトレーニングフィールドだ。
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── コブ断面SVG ── */
function MogulSectionSVG({ activePhase }: { activePhase: number }) {
  const W = 800, H = 96;

  // コブの形状（5つ）
  const bumps = [60, 200, 340, 480, 620, 760];
  const bumpPath = bumps.map((x, i) => {
    if (i === 0) return `M ${x} ${H}`;
    const prev = bumps[i - 1]!;
    const mid = (prev + x) / 2;
    return `Q ${mid} 30 ${mid} ${H / 2 + 10} Q ${mid} ${H} ${x} ${H}`;
  }).join(" ") + ` L ${W} ${H} Z`;

  // 各フェーズの位置
  const phaseX = [80, 180, 340, 480, 640];
  const activeX = phaseX[activePhase] ?? 200;

  const pc = PRESSURE_CONFIG[MOGUL_PHASES[activePhase]?.pressureState ?? "neutral"];

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-full" preserveAspectRatio="xMidYMid slice">
      {/* 背景 */}
      <rect width={W} height={H} fill="#080808" />

      {/* グリッドライン */}
      {[20, 40, 60, 80].map(y => (
        <line key={y} x1={0} y1={y} x2={W} y2={y} stroke="rgba(255,255,255,0.03)" strokeWidth={1} />
      ))}

      {/* コブ形状 */}
      <path
        d={`M 0 ${H} Q 30 ${H * 0.5} 60 ${H * 0.7} Q 130 30 200 ${H * 0.6} Q 270 ${H} 340 ${H * 0.5} Q 410 20 480 ${H * 0.55} Q 550 ${H} 620 ${H * 0.45} Q 690 20 760 ${H * 0.7} Q 790 ${H} ${W} ${H} Z`}
        fill="rgba(255,255,255,0.04)"
        stroke="rgba(255,255,255,0.12)"
        strokeWidth="1"
      />

      {/* フェーズマーカー */}
      {phaseX.map((x, i) => {
        const isActive = i === activePhase;
        const pCfg = PRESSURE_CONFIG[MOGUL_PHASES[i]?.pressureState ?? "neutral"];
        return (
          <g key={i}>
            <line
              x1={x} y1={20} x2={x} y2={H - 8}
              stroke={isActive ? pCfg.color : "rgba(255,255,255,0.1)"}
              strokeWidth={isActive ? 1.5 : 0.5}
              strokeDasharray={isActive ? "none" : "3 3"}
            />
            <circle
              cx={x} cy={22}
              r={isActive ? 5 : 3}
              fill={isActive ? pCfg.color : "rgba(255,255,255,0.15)"}
            />
            <text
              x={x} y={12}
              textAnchor="middle"
              fill={isActive ? pCfg.color : "rgba(255,255,255,0.2)"}
              fontSize={8}
              fontFamily="monospace"
            >
              {String(i + 1).padStart(2, "0")}
            </text>
          </g>
        );
      })}

      {/* アクティブ位置のスキーヤーアイコン */}
      <motion.g
        animate={{ x: activeX }}
        initial={{ x: phaseX[0] ?? 80 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
      >
        {/* シンプルなスキーヤー点 */}
        <circle cy={40} r={4} fill={pc.color} fillOpacity={0.9} />
        <line y1={44} y2={56} stroke={pc.color} strokeWidth={1.5} strokeOpacity={0.7} />
        <line y1={48} x1={-8} y2={52} x2={8} stroke={pc.color} strokeWidth={1} strokeOpacity={0.5} />
      </motion.g>
    </svg>
  );
}
