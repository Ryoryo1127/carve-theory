"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export interface CompareRow {
  aspect: string;        // 比較項目
  beginner: string;      // 初心者の理解・動作
  advanced: string;      // 上級者の理解・動作
  impact: "high" | "medium" | "low";  // 影響度
}

interface TechCompareProps {
  title?: string;
  rows: CompareRow[];
  className?: string;
}

const IMPACT_LABEL = { high: "重要", medium: "中", low: "低" };
const IMPACT_COLOR = {
  high: "text-red-400 border-red-500/30 bg-red-500/10",
  medium: "text-yellow-400 border-yellow-500/30 bg-yellow-500/10",
  low: "text-white/40 border-white/15 bg-white/5",
};

export function TechCompare({
  title = "初心者 vs 上級者の理解の差",
  rows,
  className,
}: TechCompareProps) {
  const [highlighted, setHighlighted] = useState<number | null>(null);

  return (
    <div className={cn("my-10", className)}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <div className="w-5 h-px bg-white/25" />
        <p className="font-mono-custom text-[9px] text-white/30 tracking-[0.2em] uppercase">
          Tech Comparison
        </p>
      </div>

      {title && (
        <h4 className="font-display font-bold text-white/80 text-xl mb-5">{title}</h4>
      )}

      {/* Column headers */}
      <div className="grid grid-cols-[1fr_1fr_1fr_56px] gap-px mb-px">
        <div className="bg-[#0c0c0c] border border-white/6 px-4 py-2.5">
          <span className="font-mono-custom text-[9px] text-white/25 tracking-widest uppercase">
            技術要素
          </span>
        </div>
        <div className="bg-[#0c0c0c] border border-white/6 px-4 py-2.5 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500/60 flex-shrink-0" />
          <span className="font-mono-custom text-[9px] text-green-500/60 tracking-widest uppercase">
            初心者
          </span>
        </div>
        <div className="bg-[#0c0c0c] border border-white/6 px-4 py-2.5 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-white/50 flex-shrink-0" />
          <span className="font-mono-custom text-[9px] text-white/50 tracking-widest uppercase">
            上級者
          </span>
        </div>
        <div className="bg-[#0c0c0c] border border-white/6 px-4 py-2.5">
          <span className="font-mono-custom text-[9px] text-white/20 tracking-widest uppercase">
            重要度
          </span>
        </div>
      </div>

      {/* Rows */}
      <div className="flex flex-col gap-px">
        {rows.map((row, i) => (
          <motion.div
            key={row.aspect}
            initial={{ opacity: 0, x: -8 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.35, delay: i * 0.05 }}
            className={cn(
              "grid grid-cols-[1fr_1fr_1fr_56px] gap-px cursor-pointer",
            )}
            onMouseEnter={() => setHighlighted(i)}
            onMouseLeave={() => setHighlighted(null)}
          >
            {/* Aspect */}
            <div className={cn(
              "border border-white/5 px-4 py-4 transition-colors duration-150",
              highlighted === i ? "bg-white/[0.04]" : "bg-[#0a0a0a]"
            )}>
              <span className="font-display font-bold text-white/70 text-sm">
                {row.aspect}
              </span>
            </div>

            {/* Beginner */}
            <div className={cn(
              "border border-white/5 px-4 py-4 transition-colors duration-150",
              highlighted === i ? "bg-green-950/20" : "bg-[#0a0a0a]"
            )}>
              <p className="text-white/40 text-xs leading-relaxed">{row.beginner}</p>
            </div>

            {/* Advanced */}
            <div className={cn(
              "border border-white/5 px-4 py-4 transition-colors duration-150",
              highlighted === i ? "bg-white/[0.04]" : "bg-[#0a0a0a]"
            )}>
              <p className="text-white/70 text-xs leading-relaxed">{row.advanced}</p>
            </div>

            {/* Impact */}
            <div className={cn(
              "border border-white/5 px-4 py-4 flex items-start justify-center transition-colors duration-150",
              highlighted === i ? "bg-white/[0.04]" : "bg-[#0a0a0a]"
            )}>
              <span className={cn(
                "font-mono-custom text-[8px] border px-1.5 py-0.5 tracking-wider",
                IMPACT_COLOR[row.impact]
              )}>
                {IMPACT_LABEL[row.impact]}
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Mobile: card layout (hidden on md+) */}
      <div className="md:hidden mt-4 space-y-3">
        {rows.map((row, i) => (
          <div key={`mobile-${i}`} className="border border-white/6 bg-[#0a0a0a] p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-display font-bold text-white/70 text-sm">{row.aspect}</span>
              <span className={cn(
                "font-mono-custom text-[8px] border px-1.5 py-0.5",
                IMPACT_COLOR[row.impact]
              )}>{IMPACT_LABEL[row.impact]}</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="font-mono-custom text-[8px] text-green-500/50 tracking-widest block mb-1">初心者</span>
                <p className="text-white/40 text-xs leading-relaxed">{row.beginner}</p>
              </div>
              <div>
                <span className="font-mono-custom text-[8px] text-white/40 tracking-widest block mb-1">上級者</span>
                <p className="text-white/65 text-xs leading-relaxed">{row.advanced}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
