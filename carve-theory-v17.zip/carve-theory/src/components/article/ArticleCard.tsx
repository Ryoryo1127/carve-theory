"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Clock, ArrowRight } from "lucide-react";
import { cn, getCategoryBySlug, formatDate, truncate } from "@/lib/utils";
import { LevelBadge, RouteBadge } from "@/components/ui/Badge";
import type { ArticleMeta } from "@/types";

interface ArticleCardProps {
  article: ArticleMeta;
  variant?: "default" | "featured" | "compact" | "horizontal";
  index?: number;
  className?: string;
}

export function ArticleCard({
  article,
  variant = "default",
  index = 0,
  className,
}: ArticleCardProps) {
  const category = getCategoryBySlug(article.category);

  if (variant === "compact") {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.4, delay: index * 0.05 }}
      >
        <Link
          href={`/articles/${article.slug}`}
          className={cn(
            "group flex items-start gap-4 p-4 border border-white/5 hover:border-white/12",
            "bg-white/[0.02] hover:bg-white/[0.04] transition-all duration-200",
            className
          )}
        >
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <LevelBadge level={article.level} />
              <RouteBadge route={article.route} />
            </div>
            <h3 className="font-display font-bold text-white/80 group-hover:text-white text-sm leading-tight transition-colors line-clamp-2">
              {article.title}
            </h3>
          </div>
          <ArrowRight
            size={14}
            className="text-white/20 group-hover:text-white/50 flex-shrink-0 mt-1 transition-all group-hover:translate-x-0.5"
          />
        </Link>
      </motion.div>
    );
  }

  if (variant === "horizontal") {
    return (
      <motion.div
        initial={{ opacity: 0, x: -16 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.4, delay: index * 0.06 }}
      >
        <Link
          href={`/articles/${article.slug}`}
          className={cn(
            "group flex items-start gap-6 py-5 border-b border-white/5",
            "hover:bg-white/[0.02] transition-colors duration-200 px-4 -mx-4",
            className
          )}
        >
          {/* Number */}
          <span className="font-mono-custom text-xs text-white/15 pt-1 flex-shrink-0 w-8 text-right">
            {String(index + 1).padStart(2, "0")}
          </span>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <LevelBadge level={article.level} />
              <RouteBadge route={article.route} />
              {category && (
                <span className="font-mono-custom text-[9px] text-white/25 tracking-widest uppercase">
                  {category.labelEn}
                </span>
              )}
            </div>
            <h3 className="font-display font-bold text-white/75 group-hover:text-white text-base transition-colors line-clamp-1 mb-1">
              {article.title}
            </h3>
            <p className="text-xs text-white/35 line-clamp-1">{article.subtitle}</p>
          </div>

          {/* Meta */}
          <div className="flex items-center gap-1.5 text-white/25 flex-shrink-0">
            <Clock size={11} />
            <span className="font-mono-custom text-[10px]">{article.readTime}分</span>
          </div>
        </Link>
      </motion.div>
    );
  }

  if (variant === "featured") {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: index * 0.08 }}
      >
        <Link
          href={`/articles/${article.slug}`}
          className={cn(
            "group relative flex flex-col justify-end min-h-[360px] p-8",
            "bg-[#0c0c0c] border border-white/5 hover:border-white/15",
            "overflow-hidden transition-all duration-300",
            className
          )}
        >
          {/* Background pattern */}
          <div className="absolute inset-0 opacity-5">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id={`grid-${article.slug}`} width="32" height="32" patternUnits="userSpaceOnUse">
                  <path d="M 32 0 L 0 0 0 32" fill="none" stroke="white" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill={`url(#grid-${article.slug})`} />
            </svg>
          </div>

          {/* Accent line top */}
          <div
            className="absolute top-0 left-0 right-0 h-[2px] transition-opacity duration-300 opacity-60 group-hover:opacity-100"
            style={{ background: category?.color ?? "white" }}
          />

          {/* Category label */}
          <div className="absolute top-6 right-6">
            <span className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase">
              {category?.labelEn ?? article.category}
            </span>
          </div>

          {/* Content */}
          <div className="relative z-10">
            <div className="flex flex-wrap gap-2 mb-4">
              <LevelBadge level={article.level} />
              <RouteBadge route={article.route} />
            </div>

            <h2 className="font-display font-black text-white text-xl md:text-2xl leading-tight mb-3 group-hover:text-white transition-colors">
              {article.title}
            </h2>
            <p className="text-white/40 text-sm leading-relaxed mb-5">
              {article.subtitle}
            </p>

            <p className="text-white/30 text-xs leading-relaxed mb-6 line-clamp-2">
              {truncate(article.excerpt, 80)}
            </p>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-white/25">
                <Clock size={11} />
                <span className="font-mono-custom text-[10px]">
                  {article.readTime}分
                </span>
              </div>
              <ArrowRight
                size={14}
                className="text-white/30 group-hover:text-white group-hover:translate-x-1 transition-all duration-200"
              />
            </div>
          </div>
        </Link>
      </motion.div>
    );
  }

  // Default card
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.06 }}
    >
      <Link
        href={`/articles/${article.slug}`}
        className={cn(
          "group block p-6 bg-[#0c0c0c] border border-white/5",
          "hover:border-white/12 hover:bg-[#111] transition-all duration-200",
          className
        )}
      >
        <div className="flex items-center gap-2 mb-4">
          <LevelBadge level={article.level} />
          <RouteBadge route={article.route} />
        </div>

        <h3 className="font-display font-bold text-white/80 group-hover:text-white text-lg leading-tight mb-2 transition-colors">
          {article.title}
        </h3>
        <p className="text-white/35 text-xs mb-3">{article.subtitle}</p>
        <p className="text-white/40 text-sm leading-relaxed line-clamp-2 mb-5">
          {article.excerpt}
        </p>

        <div className="flex flex-wrap gap-2 mb-5">
          {article.tags.slice(0, 3).map((tag) => (
            <span
              key={tag}
              className="font-mono-custom text-[9px] text-white/25 border border-white/8 px-2 py-0.5 tracking-widest"
            >
              #{tag}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-white/5">
          <div className="flex items-center gap-3 text-white/25">
            <Clock size={11} />
            <span className="font-mono-custom text-[10px]">{article.readTime}分</span>
            {category && (
              <>
                <span className="text-white/15">·</span>
                <span className="font-mono-custom text-[10px] tracking-widest uppercase">
                  {category.labelEn}
                </span>
              </>
            )}
          </div>
          <ArrowRight
            size={13}
            className="text-white/20 group-hover:text-white/60 group-hover:translate-x-0.5 transition-all duration-200"
          />
        </div>
      </Link>
    </motion.div>
  );
}
