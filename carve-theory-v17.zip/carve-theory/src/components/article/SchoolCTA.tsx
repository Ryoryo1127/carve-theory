"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Building2 } from "lucide-react";
import { cn } from "@/lib/utils";

/* ─────────────────────────────────────────────────────────────
   記事本文中に挿入する帯状CTA
   配置目安：技術解説が一区切りついた箇所（中盤〜後半）
───────────────────────────────────────────────────────────── */

interface SchoolCTAProps {
  className?: string;
  /** コンテキストに応じて文言を変える */
  variant?: "default" | "compact";
}

export function SchoolCTA({ className, variant = "default" }: SchoolCTAProps) {
  if (variant === "compact") {
    return <SchoolCTACompact className={className} />;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.4 }}
      className={cn(
        "my-12 relative overflow-hidden border border-cyan-500/15 bg-[#080d12]",
        className
      )}
    >
      {/* 上部アクセントライン */}
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{ background: "#22d3ee", opacity: 0.3 }}
      />
      {/* 右上の控えめなグロー */}
      <div
        className="absolute top-0 right-0 w-48 h-48 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse at 100% 0%, rgba(34,211,238,0.06) 0%, transparent 70%)",
        }}
      />

      <div className="relative flex flex-col sm:flex-row sm:items-center gap-5 px-6 py-6 md:px-8 md:py-7">
        {/* アイコン */}
        <div className="flex-shrink-0 w-11 h-11 border border-cyan-500/20 bg-cyan-950/20 flex items-center justify-center">
          <Building2 size={18} className="text-cyan-400/70" />
        </div>

        {/* テキスト */}
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="font-mono text-[8px] text-cyan-400/50 tracking-[0.18em] uppercase">
              For Organizations
            </span>
          </div>
          <p className="font-display font-bold text-white/85 text-base mb-1.5 leading-snug">
            この技術体系は、指導カリキュラムとしてもご利用いただけます
          </p>
          <p className="text-white/40 text-xs leading-relaxed">
            スキースクール・指導者育成団体向けに、現代技術論に基づく教材・研修コンテンツをライセンス提供しています。
          </p>
        </div>

        {/* CTA ボタン */}
        <Link
          href="/for-schools"
          className="flex-shrink-0 inline-flex items-center justify-center gap-2 border border-cyan-500/30 text-cyan-400/80 px-5 py-3 text-xs font-bold tracking-wider hover:bg-cyan-500/10 hover:border-cyan-400/50 transition-all whitespace-nowrap"
        >
          詳しく見る <ArrowRight size={12} />
        </Link>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────────────────────────
   省スペース版（記事末尾・タグ付近などに）
───────────────────────────────────────────────────────────── */

function SchoolCTACompact({ className }: { className?: string }) {
  return (
    <Link
      href="/for-schools"
      className={cn(
        "group flex items-center gap-3 border border-cyan-500/15 bg-cyan-950/8 px-5 py-4 hover:border-cyan-500/30 hover:bg-cyan-950/15 transition-all",
        className
      )}
    >
      <Building2 size={14} className="text-cyan-400/50 flex-shrink-0" />
      <span className="flex-1 text-xs text-white/50 leading-relaxed">
        <span className="text-white/70 font-medium">スクール・指導者育成団体の方へ：</span>
        {" "}技術教材のライセンス提供・指導者研修を承っています
      </span>
      <ArrowRight
        size={12}
        className="text-cyan-400/40 flex-shrink-0 group-hover:translate-x-0.5 transition-transform"
      />
    </Link>
  );
}

/* ─────────────────────────────────────────────────────────────
   サイドバー埋め込み用（常時表示・控えめ）
───────────────────────────────────────────────────────────── */

export function SchoolCTASidebar({ className }: { className?: string }) {
  return (
    <div className={cn("border border-cyan-500/12 bg-cyan-950/6 p-4", className)}>
      <div className="flex items-center gap-2 mb-2.5">
        <Building2 size={11} className="text-cyan-400/50" />
        <p className="font-mono text-[8px] text-cyan-400/45 tracking-widest uppercase">
          For Organizations
        </p>
      </div>
      <p className="text-[11px] text-white/45 leading-relaxed mb-3">
        この技術体系をスクール・指導者育成団体の教材としてご利用いただけます。
      </p>
      <Link
        href="/for-schools"
        className="inline-flex items-center gap-1.5 text-[11px] text-cyan-400/70 hover:text-cyan-300/90 transition-colors font-medium"
      >
        詳しく見る <ArrowRight size={10} />
      </Link>
    </div>
  );
}
