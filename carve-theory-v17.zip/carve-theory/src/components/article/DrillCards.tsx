"use client";

import { motion } from "framer-motion";
import { Clock, MapPin, TrendingUp, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export interface Drill {
  number: number;
  title: string;
  duration: string;       // "5〜10分"
  terrain: string;        // "緩斜面"
  difficulty: 1 | 2 | 3; // 難易度
  goal: string;           // このドリルの目的
  steps: string[];        // 手順
  checkpoint: string;     // できた判断基準
  tip?: string;           // コーチのヒント
}

interface DrillCardsProps {
  drills: Drill[];
  className?: string;
}

export function DrillCards({ drills, className }: DrillCardsProps) {
  return (
    <div className={cn("my-10", className)}>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-5 h-px bg-white/25" />
        <p className="font-mono-custom text-[9px] text-white/30 tracking-[0.2em] uppercase">
          Practice Drills
        </p>
      </div>
      <h4 className="font-display font-bold text-white/80 text-xl mb-6">
        修正ドリル
      </h4>

      <div className="space-y-4">
        {drills.map((drill, i) => (
          <DrillCard key={drill.number} drill={drill} index={i} />
        ))}
      </div>
    </div>
  );
}

function DrillCard({ drill, index }: { drill: Drill; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.07 }}
      className="border border-white/8 bg-[#0a0a0a] overflow-hidden"
    >
      {/* Top accent - difficulty based */}
      <div
        className="h-[2px]"
        style={{
          background:
            drill.difficulty === 1
              ? "rgba(74, 222, 128, 0.6)"
              : drill.difficulty === 2
              ? "rgba(250, 204, 21, 0.6)"
              : "rgba(248, 113, 113, 0.6)",
        }}
      />

      <div className="p-5">
        {/* Header */}
        <div className="flex items-start gap-4 mb-4">
          {/* Number */}
          <div className="flex-shrink-0 w-9 h-9 border border-white/12 flex items-center justify-center">
            <span className="font-mono-custom font-bold text-white/50 text-sm">
              {String(drill.number).padStart(2, "0")}
            </span>
          </div>

          <div className="flex-1 min-w-0">
            <h5 className="font-display font-bold text-white/85 text-base mb-1">
              {drill.title}
            </h5>
            <p className="text-white/40 text-xs leading-relaxed">{drill.goal}</p>
          </div>

          {/* Difficulty */}
          <div className="flex-shrink-0 flex gap-0.5">
            {[1, 2, 3].map((d) => (
              <div
                key={d}
                className="w-1.5 h-5"
                style={{
                  background:
                    d <= drill.difficulty
                      ? drill.difficulty === 1
                        ? "rgba(74,222,128,0.5)"
                        : drill.difficulty === 2
                        ? "rgba(250,204,21,0.5)"
                        : "rgba(248,113,113,0.5)"
                      : "rgba(255,255,255,0.06)",
                }}
              />
            ))}
          </div>
        </div>

        {/* Meta row */}
        <div className="flex flex-wrap items-center gap-4 mb-4 pb-4 border-b border-white/5">
          <div className="flex items-center gap-1.5 text-white/30">
            <Clock size={11} />
            <span className="font-mono-custom text-[9px] tracking-wider">{drill.duration}</span>
          </div>
          <div className="flex items-center gap-1.5 text-white/30">
            <MapPin size={11} />
            <span className="font-mono-custom text-[9px] tracking-wider">{drill.terrain}</span>
          </div>
        </div>

        {/* Steps */}
        <ol className="space-y-2 mb-4">
          {drill.steps.map((step, i) => (
            <li key={i} className="flex items-start gap-3">
              <span className="font-mono-custom text-[9px] text-white/25 w-5 flex-shrink-0 pt-0.5 text-right">
                {i + 1}.
              </span>
              <span className="text-white/55 text-xs leading-relaxed">{step}</span>
            </li>
          ))}
        </ol>

        {/* Checkpoint */}
        <div className="border border-white/8 bg-white/[0.03] px-4 py-3 flex items-start gap-3">
          <CheckCircle size={13} className="text-white/30 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-mono-custom text-[8px] text-white/20 tracking-widest uppercase mb-1">
              できた判断基準
            </p>
            <p className="text-white/55 text-xs leading-relaxed">{drill.checkpoint}</p>
          </div>
        </div>

        {/* Coach tip */}
        {drill.tip && (
          <div className="mt-3 pl-4 border-l border-white/12">
            <p className="font-mono-custom text-[8px] text-white/20 tracking-widest uppercase mb-1">
              コーチのひとこと
            </p>
            <p className="text-white/40 text-xs leading-relaxed italic">{drill.tip}</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
