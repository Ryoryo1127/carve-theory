"use client";

import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import type { Heading } from "@/types";

interface TableOfContentsProps {
  headings: Heading[];
}

export function TableOfContents({ headings }: TableOfContentsProps) {
  const [activeId, setActiveId] = useState<string>("");

  useEffect(() => {
    if (headings.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveId(entry.target.id);
          }
        });
      },
      { rootMargin: "-80px 0% -70% 0%" }
    );

    headings.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [headings]);

  if (headings.length === 0) return null;

  return (
    <nav aria-label="目次" className="sticky top-24">
      <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-4">
        Contents
      </p>
      <ul className="space-y-1">
        {headings.map((heading) => (
          <li key={heading.id}>
            <a
              href={`#${heading.id}`}
              className={cn(
                "block text-xs leading-relaxed transition-all duration-200 hover:text-white/80",
                heading.depth === 3 && "pl-3",
                activeId === heading.id
                  ? "text-white/80 border-l-2 border-white/40 pl-3"
                  : "text-white/25 border-l border-white/8 pl-3 hover:border-white/20"
              )}
              onClick={(e) => {
                e.preventDefault();
                document
                  .getElementById(heading.id)
                  ?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              {heading.text}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}
