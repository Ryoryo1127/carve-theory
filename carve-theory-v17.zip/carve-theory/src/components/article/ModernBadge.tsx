"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { TechEra } from "@/types";

/* ── 時代バッジ ── */
export function EraBadge({ era }: { era: TechEra | "both" }) {
  if (era === "both") {
    return (
      <span className="inline-flex items-center gap-1.5 font-mono text-[8px] tracking-widest uppercase px-2 py-0.5 border border-white/15 text-white/40">
        <span className="text-white/20">〜18</span>
        <span className="text-white/10">/</span>
        <span className="text-cyan-400/60">22〜</span>
      </span>
    );
  }
  if (era === "modern") {
    return (
      <span className="inline-flex items-center gap-1.5 font-mono text-[8px] tracking-widest uppercase px-2 py-0.5 border border-cyan-500/30 text-cyan-400/70 bg-cyan-500/6">
        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400/60 animate-pulse" />
        2026
      </span>
    );
  }
  return (
    <span className="inline-flex items-center font-mono text-[8px] tracking-widest uppercase px-2 py-0.5 border border-white/10 text-white/30">
      CLASSIC
    </span>
  );
}

/* ── 現代技術更新済みバッジ ── */
export function ModernUpdatedBanner({ className }: { className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className={cn(
        "flex items-center gap-3 px-4 py-2.5 border mb-6",
        "border-cyan-500/20 bg-cyan-950/15",
        className
      )}
    >
      <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse flex-shrink-0" />
      <p className="font-mono text-[9px] text-cyan-400/60 tracking-widest uppercase">
        2026年版技術論に更新済み
      </p>
      <div className="flex-1 h-px bg-cyan-500/10" />
      <span className="font-mono text-[8px] text-cyan-400/30">MODERN TECH</span>
    </motion.div>
  );
}

/* ── インラインモダンコールアウト ── */
interface ModernCalloutProps {
  children: React.ReactNode;
  label?: string;
  className?: string;
}

export function ModernCallout({ children, label = "現代的理解", className }: ModernCalloutProps) {
  return (
    <div className={cn("my-6 flex gap-3 border border-cyan-500/15 bg-cyan-950/8 px-5 py-4", className)}>
      <div className="w-px self-stretch bg-cyan-500/30 flex-shrink-0" />
      <div>
        <p className="font-mono text-[8px] text-cyan-400/50 tracking-widest uppercase mb-2">
          {label}
        </p>
        <div className="text-sm text-white/55 leading-relaxed">{children}</div>
      </div>
    </div>
  );
}

/* ── 旧概念の打ち消し表示 ── */
interface OldConceptProps {
  old: string;
  modern: string;
  className?: string;
}

export function ConceptUpdate({ old, modern, className }: OldConceptProps) {
  return (
    <div className={cn("my-4 border border-white/6 bg-[#0a0a0a] overflow-hidden", className)}>
      <div className="flex gap-px">
        <div className="flex-1 px-4 py-3 bg-[#090909]">
          <p className="font-mono text-[8px] text-white/20 tracking-widest uppercase mb-1.5">
            旧来の理解
          </p>
          <p className="text-xs text-white/30 leading-relaxed line-through decoration-white/20">
            {old}
          </p>
        </div>
        <div className="w-px bg-white/5 flex-shrink-0" />
        <div className="flex-1 px-4 py-3 bg-[#080d14] relative">
          <div className="absolute top-0 left-0 right-0 h-px" style={{ background: "#22d3ee", opacity: 0.3 }} />
          <p className="font-mono text-[8px] text-cyan-400/50 tracking-widest uppercase mb-1.5">
            現代の理解
          </p>
          <p className="text-xs text-white/65 leading-relaxed">{modern}</p>
        </div>
      </div>
    </div>
  );
}

/* ── 現代技術タグリスト ── */
interface ModernTagsProps {
  tags: string[];
  className?: string;
}

export function ModernTags({ tags, className }: ModernTagsProps) {
  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {tags.map((tag) => (
        <span
          key={tag}
          className="font-mono text-[8px] tracking-widest px-2.5 py-1 border border-cyan-500/20 text-cyan-400/60 bg-cyan-500/5"
        >
          {tag}
        </span>
      ))}
    </div>
  );
}
