"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { List, X } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Heading } from "@/types";

export function MobileTOC({ headings }: { headings: Heading[] }) {
  const [open, setOpen] = useState(false);

  if (headings.length === 0) return null;

  return (
    <>
      {/* Trigger button */}
      <button
        onClick={() => setOpen(true)}
        className="lg:hidden fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-white text-black px-4 py-2.5 text-xs font-bold tracking-wider shadow-2xl"
        aria-label="目次を開く"
      >
        <List size={14} />
        目次
      </button>

      {/* Overlay */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm lg:hidden"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-[#0e0e0e] border-t border-white/10 px-6 pt-6 pb-10 lg:hidden max-h-[70vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <p className="font-mono-custom text-[9px] text-white/30 tracking-[0.2em] uppercase">
                  Contents
                </p>
                <button onClick={() => setOpen(false)} className="text-white/40 hover:text-white/80">
                  <X size={18} />
                </button>
              </div>
              <ul className="space-y-1">
                {headings.map((h) => (
                  <li key={h.id}>
                    <a
                      href={`#${h.id}`}
                      onClick={() => setOpen(false)}
                      className={cn(
                        "block py-2 text-sm leading-snug border-l pl-4 transition-colors",
                        h.depth === 3 ? "pl-7 text-xs" : "",
                        "border-white/10 text-white/50 hover:text-white/90 hover:border-white/40"
                      )}
                    >
                      {h.text}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
