"use client";

import {
  useState,
  useRef,
  useEffect,
  useCallback,
  useMemo,
} from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";
import { ERA_DETAIL_DATA } from "@/lib/era-comparison-data";
import type { TechEraDetail, ComparisonTopic } from "@/types";

/* ═══════════════════════════════════════════════════════
   定数・カラー
═══════════════════════════════════════════════════════ */

const CLASSIC_COLOR = "rgba(255,255,255,0.45)";
const MODERN_COLOR  = "#22d3ee";
const CLASSIC_BG    = "rgba(255,255,255,0.03)";
const MODERN_BG     = "rgba(34,211,238,0.05)";

/* ═══════════════════════════════════════════════════════
   型
═══════════════════════════════════════════════════════ */

export interface TechEraAnalysisProps {
  /** 表示するトピック（未指定なら全10件） */
  topics?: ComparisonTopic[];
  /** スタンドアロン表示か記事内埋め込みか */
  variant?: "standalone" | "embedded";
  className?: string;
}

/* ═══════════════════════════════════════════════════════
   Topic tab ラベル
═══════════════════════════════════════════════════════ */

function TopicTab({
  item,
  isActive,
  onClick,
}: {
  item: TechEraDetail;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "relative flex-shrink-0 px-4 py-3 text-left transition-all duration-150",
        "border-b-2 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-white/30",
        isActive
          ? "border-[#22d3ee] bg-[#0a1418]"
          : "border-transparent hover:border-white/12 hover:bg-white/[0.02]"
      )}
    >
      <div className={cn(
        "font-mono text-[8px] tracking-[0.18em] uppercase mb-0.5",
        isActive ? "text-cyan-400/70" : "text-white/20"
      )}>
        {item.labelEn}
      </div>
      <div className={cn(
        "font-display font-bold text-sm transition-colors",
        isActive ? "text-white" : "text-white/40"
      )}>
        {item.label}
      </div>
    </button>
  );
}

/* ═══════════════════════════════════════════════════════
   メトリクスバー（左右比較）
═══════════════════════════════════════════════════════ */

function MetricBar({
  metric,
  index,
  animate,
}: {
  metric: TechEraDetail["metrics"][number];
  index: number;
  animate: boolean;
}) {
  const betterIsHigher = metric.higherIsBetter !== false;
  const classicBetter = betterIsHigher
    ? metric.classic > metric.modern
    : metric.classic < metric.modern;
  const modernBetter = !classicBetter;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={animate ? { opacity: 1, y: 0 } : { opacity: 0, y: 8 }}
      transition={{ duration: 0.35, delay: index * 0.07 }}
      className="mb-5"
    >
      {/* ラベル行 */}
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-white/55 font-medium">{metric.label}</span>
        {metric.unit && (
          <span className="font-mono text-[8px] text-white/20 tracking-widest">
            {metric.unit}
          </span>
        )}
      </div>

      {/* バー比較 */}
      <div className="space-y-1.5">
        {/* Classic bar */}
        <div className="flex items-center gap-2">
          <span className="font-mono text-[8px] text-white/25 w-12 text-right flex-shrink-0">
            〜'18
          </span>
          <div className="flex-1 h-[3px] bg-white/6 relative overflow-hidden">
            <motion.div
              className="absolute left-0 top-0 bottom-0 rounded-full"
              style={{ background: classicBetter ? CLASSIC_COLOR : "rgba(255,255,255,0.18)" }}
              initial={{ width: 0 }}
              animate={animate ? { width: `${metric.classic}%` } : { width: 0 }}
              transition={{ duration: 0.7, delay: index * 0.07 + 0.1, ease: "easeOut" }}
            />
          </div>
          <span className={cn(
            "font-mono text-[10px] w-6 text-right flex-shrink-0",
            classicBetter ? "text-white/50" : "text-white/20"
          )}>
            {metric.classic}
          </span>
        </div>

        {/* Modern bar */}
        <div className="flex items-center gap-2">
          <span className="font-mono text-[8px] text-cyan-400/40 w-12 text-right flex-shrink-0">
            '22〜
          </span>
          <div className="flex-1 h-[3px] bg-white/6 relative overflow-hidden">
            <motion.div
              className="absolute left-0 top-0 bottom-0 rounded-full"
              style={{ background: modernBetter ? MODERN_COLOR : "rgba(34,211,238,0.25)" }}
              initial={{ width: 0 }}
              animate={animate ? { width: `${metric.modern}%` } : { width: 0 }}
              transition={{ duration: 0.7, delay: index * 0.07 + 0.2, ease: "easeOut" }}
            />
          </div>
          <span className={cn(
            "font-mono text-[10px] w-6 text-right flex-shrink-0",
            modernBetter ? "text-cyan-400/80" : "text-cyan-400/30"
          )}>
            {metric.modern}
          </span>
        </div>
      </div>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════
   SVGビジュアライゼーション（トピック別）
═══════════════════════════════════════════════════════ */

function TopicSVG({
  topic,
  side,
  animated,
}: {
  topic: ComparisonTopic;
  side: "classic" | "modern";
  animated: boolean;
}) {
  const isModern = side === "modern";
  const baseColor = isModern ? MODERN_COLOR : CLASSIC_COLOR;
  const W = 200, H = 160;

  /* ── 軌道コンポーネント ── */
  const TurnPath = ({ d, opacity = 1 }: { d: string; opacity?: number }) => (
    <path d={d} stroke={baseColor} strokeWidth="1.5" fill="none"
      strokeOpacity={opacity}
      style={{
        strokeDasharray: 600,
        strokeDashoffset: animated ? 0 : 600,
        transition: "stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)",
      }}
    />
  );

  /* ── 重心マーカー ── */
  const ComMarker = ({ x, y, delay = 0 }: { x: number; y: number; delay?: number }) => (
    <motion.circle cx={x} cy={y} r={3} fill={baseColor} fillOpacity={0.8}
      initial={{ scale: 0, opacity: 0 }}
      animate={animated ? { scale: 1, opacity: 0.8 } : { scale: 0, opacity: 0 }}
      transition={{ delay: delay + 0.8, duration: 0.3 }}
    />
  );

  /* ─── スキーヤーシルエット（シンプルSVG図） ─── */
  const SkierFigure = ({
    cx, cy, angulation, comY,
  }: {
    cx: number; cy: number; angulation: number; comY: number;
  }) => {
    const lean = isModern ? -12 : -6; // 傾き
    const hipHeight = isModern ? -24 : -20;
    const headY = hipHeight - 18;
    return (
      <g transform={`translate(${cx},${cy}) rotate(${lean})`}>
        {/* 脚 */}
        <line x1={0} y1={0} x2={-8} y2={hipHeight + 8}
          stroke={baseColor} strokeWidth="2" strokeOpacity="0.7" />
        <line x1={0} y1={0} x2={8} y2={hipHeight + 8}
          stroke={baseColor} strokeWidth="2" strokeOpacity="0.7" />
        {/* 胴体 */}
        <line x1={0} y1={hipHeight + 8} x2={angulation} y2={headY + 6}
          stroke={baseColor} strokeWidth="2.5" strokeOpacity="0.8" />
        {/* 頭 */}
        <circle cx={angulation} cy={headY} r={4}
          fill="none" stroke={baseColor} strokeWidth="1.5" strokeOpacity="0.7" />
        {/* 重心点 */}
        <circle cx={angulation / 2} cy={comY} r={3} fill={baseColor} fillOpacity="0.6" />
        {/* 重心からの線 */}
        <line x1={angulation / 2} y1={comY} x2={0} y2={0}
          stroke={baseColor} strokeWidth="0.5" strokeOpacity="0.25" strokeDasharray="2 2" />
      </g>
    );
  };

  /* ─── 各トピックのビジュアル定義 ─── */
  const renderContent = () => {
    switch (topic) {
      /* ── 外向傾 ── */
      case "angulation": {
        const ang = isModern ? 6 : 18; // 外向傾の角度（px）
        return (
          <g>
            {/* 斜面ライン */}
            <line x1={20} y1={H - 20} x2={W - 20} y2={H - 20}
              stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
            {/* スキーヤー */}
            <SkierFigure cx={W / 2} cy={H - 30} angulation={ang} comY={-28} />
            {/* 外向傾の角度表示 */}
            <motion.path
              d={`M ${W / 2} ${H - 50} A 20 20 0 0 1 ${W / 2 + ang} ${H - 68}`}
              stroke={baseColor} strokeWidth="1" fill="none" strokeOpacity="0.4"
              initial={{ pathLength: 0 }} animate={animated ? { pathLength: 1 } : { pathLength: 0 }}
              transition={{ delay: 0.9, duration: 0.4 }}
            />
            <motion.text
              x={W / 2 + ang / 2 + 6} y={H - 55}
              fill={baseColor} fontSize="8" fontFamily="monospace" fillOpacity="0.6"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 1.2 }}
            >
              {isModern ? "自然" : "強制"}
            </motion.text>
          </g>
        );
      }

      /* ── 荷重 ── */
      case "pressure": {
        // 荷重グラフ（時系列）
        const classicPoints = "20,120 40,110 70,50 100,40 130,55 160,100 180,120";
        const modernPoints  = "20,120 30,105 55,65 80,45 100,50 120,70 145,95 180,120";
        const pts = isModern ? modernPoints : classicPoints;
        return (
          <g>
            {/* グリッド */}
            {[40, 60, 80, 100].map(y => (
              <line key={y} x1={20} y1={y} x2={W - 20} y2={y}
                stroke="rgba(255,255,255,0.04)" strokeWidth="1" />
            ))}
            {/* 軸ラベル */}
            <text x={15} y={45} fill="rgba(255,255,255,0.2)" fontSize="7" fontFamily="monospace">高</text>
            <text x={15} y={125} fill="rgba(255,255,255,0.2)" fontSize="7" fontFamily="monospace">低</text>
            <text x={20} y={H - 5} fill="rgba(255,255,255,0.2)" fontSize="7" fontFamily="monospace">ターン開始</text>
            <text x={W - 50} y={H - 5} fill="rgba(255,255,255,0.2)" fontSize="7" fontFamily="monospace">終了</text>
            {/* 圧グラフライン */}
            <polyline points={pts} fill="none"
              stroke={baseColor} strokeWidth="1.5"
              style={{
                strokeDasharray: 600, strokeDashoffset: animated ? 0 : 600,
                transition: "stroke-dashoffset 1.2s ease",
              }}
            />
            {/* 面積塗り */}
            <motion.polygon
              points={`20,120 ${pts} 180,120`}
              fill={baseColor} fillOpacity="0.06"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 0.8 }}
            />
            {/* ラベル */}
            <motion.text x={isModern ? 95 : 100} y={isModern ? 35 : 28}
              fill={baseColor} fontSize="8" fontFamily="monospace" textAnchor="middle"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 1.0 }}>
              {isModern ? "圧の流れ" : "踏み込み"}
            </motion.text>
          </g>
        );
      }

      /* ── 切り替え ── */
      case "transition": {
        // ターン軌跡と切り替えポイント
        const classicPath = "M 30 20 Q 100 60 100 100 Q 100 140 170 140";
        const modernPath  = "M 30 20 Q 90 50 95 85 Q 98 110 170 140";
        return (
          <g>
            {/* フォールライン */}
            <line x1={W / 2} y1={10} x2={W / 2} y2={H - 10}
              stroke="rgba(255,255,255,0.06)" strokeWidth="1" strokeDasharray="4 4" />
            <text x={W / 2 + 4} y={20} fill="rgba(255,255,255,0.15)" fontSize="7" fontFamily="monospace">
              FL
            </text>
            {/* ターン軌跡 */}
            <TurnPath d={isModern ? modernPath : classicPath} />
            {/* 切り替えポイントマーカー */}
            <ComMarker x={isModern ? 95 : 100} y={isModern ? 85 : 100} delay={0} />
            {/* 矢印：切り替え開始 */}
            <motion.line
              x1={isModern ? 95 : 100} y1={isModern ? 85 : 100}
              x2={isModern ? 120 : 130} y2={isModern ? 65 : 90}
              stroke={baseColor} strokeWidth="1" strokeOpacity="0.5"
              markerEnd="none"
              initial={{ pathLength: 0 }} animate={animated ? { pathLength: 1 } : { pathLength: 0 }}
              transition={{ delay: 1.1, duration: 0.4 }}
            />
            <motion.text
              x={isModern ? 115 : 130} y={isModern ? 55 : 82}
              fill={baseColor} fontSize="8" fontFamily="monospace" fillOpacity="0.7"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 1.3 }}>
              {isModern ? "早期" : "遅延"}
            </motion.text>
          </g>
        );
      }

      /* ── ポジション / 重心高さ ── */
      case "position":
      case "com-path": {
        const comHeightClassic = 55;
        const comHeightModern  = 75; // 低い方がY値大きい
        const comH = isModern ? comHeightModern : comHeightClassic;
        return (
          <g>
            {/* 地面 */}
            <line x1={20} y1={H - 20} x2={W - 20} y2={H - 20}
              stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
            {/* スキーヤー */}
            <SkierFigure cx={W / 2} cy={H - 22} angulation={isModern ? 4 : 10} comY={-comH + 20} />
            {/* 重心の高さ表示 */}
            <motion.line
              x1={W / 2 + 20} y1={H - 22 - comH + 20}
              x2={W / 2 + 40} y2={H - 22 - comH + 20}
              stroke={baseColor} strokeWidth="1" strokeOpacity="0.5"
              initial={{ scaleX: 0 }} animate={animated ? { scaleX: 1 } : { scaleX: 0 }}
              transition={{ delay: 0.9, duration: 0.3 }}
            />
            <motion.text
              x={W / 2 + 44} y={H - 22 - comH + 24}
              fill={baseColor} fontSize="8" fontFamily="monospace" fillOpacity="0.7"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 1.1 }}>
              {topic === "com-path"
                ? (isModern ? "斜め前" : "横移動")
                : (isModern ? "低重心" : "高重心")}
            </motion.text>
          </g>
        );
      }

      /* ── 上半身 ── */
      case "upper-body": {
        return (
          <g>
            <line x1={20} y1={H - 20} x2={W - 20} y2={H - 20}
              stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
            <SkierFigure cx={W / 2} cy={H - 22} angulation={isModern ? 5 : 16} comY={-30} />
            {/* 運動連鎖の矢印 */}
            {[0, 1, 2].map(i => (
              <motion.line key={i}
                x1={W / 2 + (isModern ? 5 : 16) - i * 4} y1={H - 70 + i * 12}
                x2={W / 2 - i * 5} y2={H - 30 + i * 2}
                stroke={baseColor} strokeWidth="0.8" strokeOpacity="0.35"
                strokeDasharray="3 3"
                initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
                transition={{ delay: 0.8 + i * 0.1 }}
              />
            ))}
            <motion.text x={W - 60} y={50}
              fill={baseColor} fontSize="8" fontFamily="monospace" fillOpacity="0.7"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 1.2 }}>
              {isModern ? "自然連鎖" : "強制固定"}
            </motion.text>
          </g>
        );
      }

      /* ── エッジング ── */
      case "edging": {
        // エッジ角の断面図
        const angle = isModern ? 52 : 38;
        const rad = (angle * Math.PI) / 180;
        const edgeLen = 40;
        const ex = Math.cos(rad) * edgeLen;
        const ey = Math.sin(rad) * edgeLen;
        return (
          <g>
            {/* 雪面 */}
            <line x1={20} y1={H - 30} x2={W - 20} y2={H - 30}
              stroke="rgba(255,255,255,0.15)" strokeWidth="1.5" />
            {/* スキー板断面 */}
            <motion.line
              x1={W / 2 - ex} y1={H - 30 + ey}
              x2={W / 2 + ex} y2={H - 30 - ey}
              stroke={baseColor} strokeWidth="3" strokeOpacity="0.8"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 0.5, duration: 0.4 }}
            />
            {/* 角度アーク */}
            <motion.path
              d={`M ${W / 2} ${H - 30} A 30 30 0 0 0 ${W / 2 + 30} ${H - 30}`}
              stroke={baseColor} strokeWidth="1" fill="none" strokeOpacity="0.4"
              initial={{ pathLength: 0 }} animate={animated ? { pathLength: 1 } : { pathLength: 0 }}
              transition={{ delay: 0.8, duration: 0.5 }}
            />
            <motion.text x={W / 2 + 18} y={H - 42}
              fill={baseColor} fontSize="9" fontFamily="monospace" fontWeight="bold" fillOpacity="0.8"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 1.2 }}>
              {angle}°
            </motion.text>
            {/* 開始タイミングインジケーター */}
            <motion.text x={W / 2 - 50} y={H - 60}
              fill={baseColor} fontSize="8" fontFamily="monospace" fillOpacity="0.6"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 1.3 }}>
              {isModern ? "体幹から" : "足首から"}
            </motion.text>
          </g>
        );
      }

      /* ── 板の走り ── */
      case "ski-run": {
        const classicPath2 = "M 20 60 Q 60 80 80 110 Q 100 130 140 140 Q 160 145 180 140";
        const modernPath2  = "M 20 60 Q 55 50 80 65 Q 110 80 140 75 Q 160 72 180 70";
        return (
          <g>
            {/* 走りのベクトル矢印 */}
            <defs>
              <marker id={`arr-${side}`} markerWidth="6" markerHeight="6"
                refX="3" refY="3" orient="auto">
                <path d="M0,0 L6,3 L0,6 Z" fill={baseColor} fillOpacity="0.6" />
              </marker>
            </defs>
            {/* 軌跡 */}
            <TurnPath d={isModern ? modernPath2 : classicPath2} />
            {/* スキッドゾーン（クラシック） */}
            {!isModern && (
              <motion.rect x={80} y={100} width={60} height={20}
                fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.12)"
                strokeWidth="0.5" strokeDasharray="3 2"
                initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
                transition={{ delay: 0.9 }}>
              </motion.rect>
            )}
            <motion.text x={isModern ? 140 : 85} y={isModern ? 60 : 112}
              fill={baseColor} fontSize="8" fontFamily="monospace" fillOpacity="0.7"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 1.1 }}>
              {isModern ? "走り" : "スキッド"}
            </motion.text>
          </g>
        );
      }

      /* ── ショートターン ── */
      case "short-turn": {
        // リズム波形
        const rhythmPoints = isModern
          ? "20,80 40,50 60,80 80,50 100,80 120,50 140,80 160,50 180,80"
          : "20,80 50,40 80,80 100,80 130,40 160,80 180,80";
        return (
          <g>
            {/* 基準線 */}
            <line x1={20} y1={80} x2={W - 20} y2={80}
              stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
            {/* リズム波形 */}
            <polyline points={rhythmPoints} fill="none"
              stroke={baseColor} strokeWidth="1.5"
              style={{
                strokeDasharray: 400, strokeDashoffset: animated ? 0 : 400,
                transition: "stroke-dashoffset 1.2s ease",
              }}
            />
            {/* 切り替えマーカー */}
            {(isModern ? [40, 80, 120, 160] : [50, 130]).map((x, i) => (
              <ComMarker key={i} x={x} y={50} delay={i * 0.15} />
            ))}
            <motion.text x={W / 2} y={H - 15}
              fill={baseColor} fontSize="8" fontFamily="monospace" textAnchor="middle" fillOpacity="0.6"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 1.3 }}>
              {isModern ? "均一リズム（圧主導）" : "不均一（エッジ主導）"}
            </motion.text>
          </g>
        );
      }

      /* ── コブ処理 ── */
      case "mogul": {
        // コブ形状 + 吸収軌跡
        return (
          <g>
            {/* コブ断面 */}
            <path d="M 20 130 Q 60 70 100 130 Q 140 70 180 130"
              fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.15)" strokeWidth="1" />
            {/* 滑走ライン */}
            <TurnPath
              d={isModern
                ? "M 20 100 Q 55 85 80 105 Q 100 120 125 100 Q 148 85 180 100"
                : "M 20 128 Q 50 90 80 128 Q 110 90 140 128 Q 160 100 180 128"
              }
            />
            {/* 吸収動作ライン（モダンのみ） */}
            {isModern && (
              <motion.path
                d="M 80 105 Q 85 90 95 85 Q 105 90 110 105"
                stroke={baseColor} strokeWidth="1" fill="none" strokeOpacity="0.4"
                strokeDasharray="3 2"
                initial={{ pathLength: 0 }} animate={animated ? { pathLength: 1 } : { pathLength: 0 }}
                transition={{ delay: 1.0, duration: 0.5 }}
              />
            )}
            <motion.text x={W / 2} y={H - 8}
              fill={baseColor} fontSize="8" fontFamily="monospace" textAnchor="middle" fillOpacity="0.6"
              initial={{ opacity: 0 }} animate={animated ? { opacity: 1 } : { opacity: 0 }}
              transition={{ delay: 1.2 }}>
              {isModern ? "吸収・ライン維持" : "エッジ制動"}
            </motion.text>
          </g>
        );
      }

      default:
        return null;
    }
  };

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-full" aria-hidden="true">
      {/* 背景グリッド */}
      <defs>
        <pattern id={`grid-${side}-${topic}`} width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(255,255,255,0.025)" strokeWidth="0.5" />
        </pattern>
      </defs>
      <rect width={W} height={H} fill={`url(#grid-${side}-${topic})`} />
      {renderContent()}
    </svg>
  );
}

/* ═══════════════════════════════════════════════════════
   左右比較パネル
═══════════════════════════════════════════════════════ */

function ComparePanel({ item }: { item: TechEraDetail }) {
  const [svgVisible, setSvgVisible] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();

  useEffect(() => {
    setSvgVisible(false);
    const timer = setTimeout(() => setSvgVisible(true), reduced ? 0 : 120);
    return () => clearTimeout(timer);
  }, [item.id, reduced]);

  return (
    <div ref={panelRef} className="flex flex-col gap-px bg-white/5">
      {/* SVGビジュアル比較 */}
      <div className="grid grid-cols-2 gap-px bg-white/5">
        {(["classic", "modern"] as const).map((side) => (
          <div key={side}
            className={cn(
              "relative",
              side === "modern" ? "bg-[#080e12]" : "bg-[#0a0a0a]"
            )}
          >
            {/* サイドラベル */}
            <div className={cn(
              "absolute top-0 left-0 right-0 flex items-center gap-2 px-3 py-1.5 z-10",
              "border-b border-white/5"
            )}>
              <div className="w-1 h-1 rounded-full flex-shrink-0"
                style={{ background: side === "modern" ? MODERN_COLOR : CLASSIC_COLOR }} />
              <span className="font-mono text-[8px] tracking-[0.18em] uppercase"
                style={{ color: side === "modern" ? "rgba(34,211,238,0.5)" : "rgba(255,255,255,0.3)" }}>
                {side === "modern" ? "2022年〜 現代" : "〜2018年 従来"}
              </span>
            </div>
            {/* SVG領域 */}
            <div className="pt-8 h-[196px] px-3 pb-2">
              <TopicSVG topic={item.id} side={side} animated={svgVisible} />
            </div>
          </div>
        ))}
      </div>

      {/* テキスト左右比較 */}
      <div className="grid grid-cols-2 gap-px bg-white/5">
        {(["classic", "modern"] as const).map((side) => {
          const isModern = side === "modern";
          const text = isModern ? item.modern : item.classic;
          const bodyEffect = isModern ? item.modernBodyEffect : item.classicBodyEffect;
          return (
            <div key={side}
              className={cn("px-5 py-5", isModern ? "bg-[#080e12]" : "bg-[#090909]")}
            >
              <p className="text-sm leading-[1.85] mb-4"
                style={{ color: isModern ? "rgba(255,255,255,0.7)" : "rgba(255,255,255,0.4)" }}>
                {text}
              </p>
              <div className={cn(
                "px-3 py-2.5 border",
                isModern
                  ? "border-cyan-500/15 bg-cyan-950/10"
                  : "border-white/6 bg-white/[0.02]"
              )}>
                <p className="font-mono text-[8px] tracking-widest uppercase mb-1.5"
                  style={{ color: isModern ? "rgba(34,211,238,0.4)" : "rgba(255,255,255,0.2)" }}>
                  身体への影響
                </p>
                <p className="text-[11px] leading-relaxed"
                  style={{ color: isModern ? "rgba(255,255,255,0.55)" : "rgba(255,255,255,0.3)" }}>
                  {bodyEffect}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   なぜ変化したか・誤解パネル
═══════════════════════════════════════════════════════ */

function WhyPanel({ item }: { item: TechEraDetail }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="border border-white/6 bg-[#080808] overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-5 py-3.5 text-left hover:bg-white/[0.02] transition-colors"
      >
        <div className="w-1 h-1 rounded-full bg-cyan-400/50 flex-shrink-0" />
        <span className="font-mono text-[9px] text-white/30 tracking-[0.18em] uppercase flex-1">
          なぜ技術が変化したのか
        </span>
        <motion.span
          animate={{ rotate: open ? 180 : 0 }}
          transition={{ duration: 0.2 }}
          className="font-mono text-[10px] text-white/20"
        >
          ▾
        </motion.span>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 pt-2 border-t border-white/5 space-y-5">
              {/* Why */}
              <div>
                <p className="text-sm text-white/55 leading-[1.88]">{item.why}</p>
              </div>

              {/* Drivers */}
              <div>
                <p className="font-mono text-[8px] text-white/20 tracking-widest uppercase mb-3">
                  変化を引き起こした要因
                </p>
                <ul className="space-y-2">
                  {item.drivers.map((d, i) => (
                    <motion.li key={i}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.06 }}
                      className="flex items-start gap-2.5"
                    >
                      <span className="font-mono text-[9px] text-cyan-400/40 flex-shrink-0 pt-0.5">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span className="text-xs text-white/45 leading-relaxed">{d}</span>
                    </motion.li>
                  ))}
                </ul>
              </div>

              {/* Misconception */}
              <div className="border border-yellow-500/15 bg-yellow-950/8 px-4 py-3">
                <p className="font-mono text-[8px] text-yellow-400/50 tracking-widest uppercase mb-2">
                  よくある誤解
                </p>
                <p className="text-xs text-white/45 leading-relaxed">{item.commonMisconception}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   メインコンポーネント
═══════════════════════════════════════════════════════ */

export function TechEraAnalysis({
  topics,
  variant = "embedded",
  className,
}: TechEraAnalysisProps) {
  const data = useMemo(() => {
    if (!topics) return ERA_DETAIL_DATA;
    return ERA_DETAIL_DATA.filter((d) => topics.includes(d.id));
  }, [topics]);

  const [activeId, setActiveId] = useState<ComparisonTopic>(data[0]!.id);
  const tabsRef = useRef<HTMLDivElement>(null);

  const activeItem = useMemo(
    () => data.find((d) => d.id === activeId) ?? data[0]!,
    [data, activeId]
  );

  const handleSelect = useCallback((id: ComparisonTopic) => {
    setActiveId(id);
  }, []);

  /* 選択時にタブをスクロールして見せる */
  useEffect(() => {
    const tabs = tabsRef.current;
    if (!tabs) return;
    const active = tabs.querySelector<HTMLElement>('[data-active="true"]');
    active?.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
  }, [activeId]);

  return (
    <div className={cn("my-12", variant === "standalone" && "max-w-5xl mx-auto", className)}>

      {/* ── ヘッダー ── */}
      <div className="flex items-end justify-between mb-6 flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-5 h-px bg-white/20" />
            <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
              Era Analysis
            </span>
            <span className="font-mono text-[8px] text-cyan-400/50 border border-cyan-500/20 px-1.5 py-0.5 tracking-widest">
              2026
            </span>
          </div>
          <h3 className="font-display font-black text-white"
            style={{ fontSize: "clamp(20px, 2.8vw, 32px)" }}>
            旧技術 vs 現代技術
          </h3>
          <p className="text-white/35 text-xs mt-1.5 max-w-md leading-relaxed">
            2010年代と2022年以降の技術論の違い。どちらが「正しい」ではなく、
            <em className="not-italic text-white/50">なぜ変化したか</em>を理解する。
          </p>
        </div>

        {/* 凡例 */}
        <div className="flex items-center gap-4 flex-shrink-0">
          <div className="flex items-center gap-1.5">
            <div className="w-4 h-px" style={{ background: CLASSIC_COLOR }} />
            <span className="font-mono text-[8px] text-white/30 tracking-wider">〜2018 従来</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-4 h-px" style={{ background: MODERN_COLOR }} />
            <span className="font-mono text-[8px] text-cyan-400/50 tracking-wider">2022〜 現代</span>
          </div>
        </div>
      </div>

      {/* ── タブナビゲーション ── */}
      <div ref={tabsRef}
        className="flex border-b border-white/8 overflow-x-auto scrollbar-hide mb-px"
        style={{ scrollbarWidth: "none" }}
      >
        {data.map((item) => (
          <div key={item.id} data-active={item.id === activeId}>
            <TopicTab
              item={item}
              isActive={item.id === activeId}
              onClick={() => handleSelect(item.id)}
            />
          </div>
        ))}
      </div>

      {/* ── メインコンテンツ ── */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeId}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.22, ease: "easeOut" }}
        >
          {/* SVG + テキスト 左右比較 */}
          <ComparePanel item={activeItem} />

          {/* メトリクス + なぜ変化したか */}
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-px bg-white/5 mt-px">

            {/* Why & Misconception */}
            <div className="bg-[#080808] p-5">
              <WhyPanel item={activeItem} />
            </div>

            {/* メトリクスバー */}
            <div className="bg-[#09090d] p-5">
              <p className="font-mono text-[8px] text-white/20 tracking-[0.18em] uppercase mb-5">
                Metrics Comparison
              </p>
              {activeItem.metrics.map((metric, i) => (
                <MetricBar key={metric.label} metric={metric} index={i} animate={true} />
              ))}
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* ── フッター注記 ── */}
      <div className="mt-4 flex items-start gap-3 px-1">
        <div className="w-px h-full bg-white/8 flex-shrink-0 self-stretch mt-0.5" />
        <p className="font-mono text-[8px] text-white/15 leading-relaxed">
          ※ 数値は相対的なスコアです。絶対値ではなく傾向の比較として参照してください。
          技術の変化は「旧技術が誤り」ではなく、用具・競技・研究の蓄積によって最適解が更新されたことを意味します。
        </p>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   単一トピックの埋め込みバージョン（記事内の簡易版）
═══════════════════════════════════════════════════════ */

export function TechEraInline({
  topic,
  className,
}: {
  topic: ComparisonTopic;
  className?: string;
}) {
  return (
    <TechEraAnalysis topics={[topic]} variant="embedded" className={className} />
  );
}
