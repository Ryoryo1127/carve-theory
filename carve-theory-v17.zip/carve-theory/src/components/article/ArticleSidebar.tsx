"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Twitter, Link2, BookOpen, Dumbbell } from "lucide-react";
import { TableOfContents } from "./TableOfContents";
import { SchoolCTASidebar } from "./SchoolCTA";
import type { Heading, ArticleMeta } from "@/types";
import { cn } from "@/lib/utils";

interface ArticleSidebarProps {
  headings: Heading[];
  article: ArticleMeta;
  relatedDrills?: { title: string; href: string }[];
}

export function ArticleSidebar({ headings, article, relatedDrills }: ArticleSidebarProps) {
  const [readPercent, setReadPercent] = useState(0);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const update = () => {
      const el = document.documentElement;
      const scrollTop = el.scrollTop || document.body.scrollTop;
      const scrollHeight = el.scrollHeight - el.clientHeight;
      setReadPercent(scrollHeight > 0 ? Math.round((scrollTop / scrollHeight) * 100) : 0);
    };
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);

  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const tweetText = encodeURIComponent(
    `${article.title} | CARVE THEORY\n${typeof window !== "undefined" ? window.location.href : ""}`
  );

  return (
    <aside className="sticky top-24 space-y-8">
      {/* Reading progress */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <p className="font-mono-custom text-[9px] text-white/20 tracking-widest uppercase">
            Reading
          </p>
          <span className="font-mono-custom text-[9px] text-white/30 tabular-nums">
            {readPercent}%
          </span>
        </div>
        <div className="h-px bg-white/8">
          <div
            className="h-full bg-white/50 transition-all duration-200"
            style={{ width: `${readPercent}%` }}
          />
        </div>
        <div className="flex items-center gap-1.5 mt-2">
          <BookOpen size={10} className="text-white/20" />
          <span className="font-mono-custom text-[9px] text-white/20">
            {article.readTime}分で読める
          </span>
        </div>
      </div>

      {/* TOC */}
      <TableOfContents headings={headings} />

      {/* Level info */}
      <div className="border border-white/6 bg-white/[0.02] p-4 space-y-3">
        <p className="font-mono-custom text-[9px] text-white/20 tracking-widest uppercase">
          Article Info
        </p>
        <div className="space-y-2">
          {[
            ["レベル", article.level],
            ["種別", article.route],
            ["読了", `${article.readTime}分`],
          ].map(([k, v]) => (
            <div key={k} className="flex items-center justify-between">
              <span className="text-white/30 text-xs">{k}</span>
              <span className="text-white/60 text-xs font-medium">{v}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Related drills */}
      {relatedDrills && relatedDrills.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Dumbbell size={11} className="text-white/25" />
            <p className="font-mono-custom text-[9px] text-white/25 tracking-widest uppercase">
              Related Drills
            </p>
          </div>
          <ul className="space-y-1.5">
            {relatedDrills.map((drill) => (
              <li key={drill.href}>
                <Link
                  href={drill.href}
                  className="text-xs text-white/35 hover:text-white/70 transition-colors leading-snug block"
                >
                  → {drill.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Share */}
      <div>
        <p className="font-mono-custom text-[9px] text-white/20 tracking-widest uppercase mb-3">
          Share
        </p>
        <div className="flex gap-2">
          <a
            href={`https://twitter.com/intent/tweet?text=${tweetText}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 border border-white/8 px-3 py-2 text-white/30 hover:text-white/70 hover:border-white/20 transition-all text-xs"
          >
            <Twitter size={12} />
            <span className="font-mono-custom text-[9px] tracking-wider">POST</span>
          </a>
          <button
            onClick={handleCopyLink}
            className={cn(
              "flex items-center gap-2 border px-3 py-2 transition-all text-xs",
              copied
                ? "border-white/20 text-white/70"
                : "border-white/8 text-white/30 hover:text-white/70 hover:border-white/20"
            )}
          >
            <Link2 size={12} />
            <span className="font-mono-custom text-[9px] tracking-wider">
              {copied ? "COPIED" : "COPY"}
            </span>
          </button>
        </div>
      </div>

      {/* For organizations CTA */}
      <SchoolCTASidebar />
    </aside>
  );
}
