"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface PressurePoint {
  phase: string;        // 局面名
  phaseEn: string;
  outer: number;        // 外足荷重 0-100
  inner: number;        // 内足荷重 0-100
  description: string;
}

interface PressureChartProps {
  title?: string;
  data?: PressurePoint[];
  className?: string;
}

const DEFAULT_DATA: PressurePoint[] = [
  {
    phase: "ターン前",
    phaseEn: "PRE-TURN",
    outer: 50,
    inner: 50,
    description: "両足均等。重心はまだ中央にある。",
  },
  {
    phase: "谷回り前半",
    phaseEn: "INITIATION",
    outer: 65,
    inner: 35,
    description: "重心が谷側へ落ち始める。外足への移行が始まる。",
  },
  {
    phase: "フォールライン",
    phaseEn: "FALL LINE",
    outer: 85,
    inner: 15,
    description: "外足荷重のピーク。遠心力＋重力が最大化する局面。",
  },
  {
    phase: "山回り後半",
    phaseEn: "COMPLETION",
    outer: 75,
    inner: 25,
    description: "荷重を維持しながら次のターンへの準備を始める。",
  },
  {
    phase: "切り替え",
    phaseEn: "TRANSITION",
    outer: 50,
    inner: 50,
    description: "エッジがフラットになる瞬間。一瞬だけ均等荷重。",
  },
];

export function PressureChart({
  title = "ターン中の荷重分布",
  data = DEFAULT_DATA,
  className,
}: PressureChartProps) {
  const [active, setActive] = useState<number | null>(null);
  const [animated, setAnimated] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setAnimated(true); },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const activeData = active !== null ? data[active] : null;

  return (
    <div ref={ref} className={cn("my-10 border border-white/8 bg-[#0c0c0c]", className)}>
      {/* Header */}
      <div className="px-6 py-4 border-b border-white/6 flex items-center gap-3">
        <div className="w-4 h-px bg-white/30" />
        <p className="font-mono-custom text-[9px] text-white/30 tracking-[0.2em] uppercase">
          Pressure Distribution
        </p>
      </div>

      <div className="p-6">
        {title && (
          <h4 className="font-display font-bold text-white/80 text-lg mb-6">{title}</h4>
        )}

        {/* Chart */}
        <div className="flex items-end gap-3 mb-6 h-32">
          {data.map((point, i) => (
            <button
              key={point.phase}
              onMouseEnter={() => setActive(i)}
              onMouseLeave={() => setActive(null)}
              onClick={() => setActive(active === i ? null : i)}
              className="flex-1 flex flex-col items-center gap-1 group"
            >
              {/* Stacked bars */}
              <div className="w-full flex flex-col-reverse gap-0.5 h-24">
                {/* Outer foot */}
                <motion.div
                  initial={{ scaleY: 0 }}
                  animate={{ scaleY: animated ? 1 : 0 }}
                  transition={{ duration: 0.6, delay: i * 0.08, ease: "easeOut" }}
                  className={cn(
                    "w-full origin-bottom transition-opacity duration-200",
                    active === i ? "opacity-100" : "opacity-70 group-hover:opacity-90"
                  )}
                  style={{
                    height: `${point.outer}%`,
                    background: active === i
                      ? "rgba(255,255,255,0.7)"
                      : "rgba(255,255,255,0.35)",
                  }}
                />
                {/* Inner foot */}
                <motion.div
                  initial={{ scaleY: 0 }}
                  animate={{ scaleY: animated ? 1 : 0 }}
                  transition={{ duration: 0.6, delay: i * 0.08 + 0.05, ease: "easeOut" }}
                  className="w-full origin-bottom"
                  style={{
                    height: `${point.inner}%`,
                    background: active === i
                      ? "rgba(255,255,255,0.2)"
                      : "rgba(255,255,255,0.08)",
                  }}
                />
              </div>

              {/* Phase label */}
              <span
                className={cn(
                  "font-mono-custom text-[8px] text-center leading-tight tracking-wider transition-colors",
                  active === i ? "text-white/70" : "text-white/25"
                )}
              >
                {point.phaseEn}
              </span>
            </button>
          ))}
        </div>

        {/* Legend */}
        <div className="flex items-center gap-5 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-white/40" />
            <span className="font-mono-custom text-[9px] text-white/35 tracking-wider">外足</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-white/10" />
            <span className="font-mono-custom text-[9px] text-white/35 tracking-wider">内足</span>
          </div>
        </div>

        {/* Active description */}
        <div className="min-h-[60px]">
          {activeData ? (
            <motion.div
              key={active}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className="border border-white/8 bg-white/[0.03] p-4"
            >
              <div className="flex items-center gap-3 mb-2">
                <span className="font-display font-bold text-white/80 text-sm">
                  {activeData.phase}
                </span>
                <span className="font-mono-custom text-[9px] text-white/30 tracking-widest">
                  外足 {activeData.outer}% · 内足 {activeData.inner}%
                </span>
              </div>
              <p className="text-white/45 text-xs leading-relaxed">
                {activeData.description}
              </p>
            </motion.div>
          ) : (
            <p className="text-white/20 text-xs font-mono-custom tracking-widest">
              ← 各フェーズをホバーして詳細を見る
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

/* ── Edge angle chart ── */
interface EdgeAngleProps {
  className?: string;
}

export function EdgeAngleChart({ className }: EdgeAngleProps) {
  const [animated, setAnimated] = useState(false);
  const ref = useRef<SVGSVGElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) setAnimated(true); },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  // Data: [phase_x, angle_degrees]
  const expertData = [
    [0, 0], [15, 8], [30, 22], [50, 55], [65, 72], [80, 60], [100, 0],
  ];
  const beginnerData = [
    [0, 0], [15, 3], [30, 10], [50, 30], [65, 42], [80, 30], [100, 0],
  ];

  const W = 400, H = 140;
  const padX = 36, padY = 16;
  const chartW = W - padX * 2;
  const chartH = H - padY * 2;

  const toSvg = (d: number[][]) =>
    d.map(([x, y]) => [
      padX + (x / 100) * chartW,
      padY + chartH - (y / 80) * chartH,
    ]);

  const toPath = (pts: number[][]) =>
    pts.map((p, i) => `${i === 0 ? "M" : "L"} ${p[0]} ${p[1]}`).join(" ");

  const expertPts = toSvg(expertData);
  const beginnerPts = toSvg(beginnerData);

  const phaseLabels = [
    { x: 0, label: "開始" },
    { x: 50, label: "FL" },
    { x: 100, label: "終了" },
  ];

  return (
    <div className={cn("my-10 border border-white/8 bg-[#0c0c0c]", className)}>
      <div className="px-6 py-4 border-b border-white/6 flex items-center gap-3">
        <div className="w-4 h-px bg-white/30" />
        <p className="font-mono-custom text-[9px] text-white/30 tracking-[0.2em] uppercase">
          Edge Angle Through Turn
        </p>
      </div>
      <div className="p-6">
        <h4 className="font-display font-bold text-white/80 text-lg mb-5">
          ターン中のエッジ角変化
        </h4>

        <svg
          ref={ref}
          viewBox={`0 0 ${W} ${H}`}
          className="w-full"
          aria-label="エッジ角グラフ"
        >
          {/* Grid lines */}
          {[0, 20, 40, 60, 80].map((deg) => {
            const y = padY + chartH - (deg / 80) * chartH;
            return (
              <g key={deg}>
                <line x1={padX} y1={y} x2={W - padX} y2={y}
                  stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
                <text x={padX - 4} y={y + 4} fill="rgba(255,255,255,0.2)"
                  fontSize="8" textAnchor="end" fontFamily="monospace">
                  {deg}°
                </text>
              </g>
            );
          })}

          {/* Phase labels */}
          {phaseLabels.map(({ x, label }) => {
            const svgX = padX + (x / 100) * chartW;
            return (
              <text key={label} x={svgX} y={H - 2}
                fill="rgba(255,255,255,0.2)" fontSize="8"
                textAnchor="middle" fontFamily="monospace">
                {label}
              </text>
            );
          })}

          {/* Fall line marker */}
          <line
            x1={padX + 0.5 * chartW} y1={padY}
            x2={padX + 0.5 * chartW} y2={padY + chartH}
            stroke="rgba(255,255,255,0.08)" strokeWidth="1" strokeDasharray="4 3"
          />

          {/* Beginner line */}
          <motion.path
            d={toPath(beginnerPts)}
            fill="none"
            stroke="rgba(255,255,255,0.2)"
            strokeWidth="1.5"
            strokeDasharray="5 3"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: animated ? 1 : 0 }}
            transition={{ duration: 1.5, delay: 0.2, ease: "easeInOut" }}
          />

          {/* Expert line */}
          <motion.path
            d={toPath(expertPts)}
            fill="none"
            stroke="rgba(255,255,255,0.7)"
            strokeWidth="2"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: animated ? 1 : 0 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
          />

          {/* Dots at key points */}
          {animated && expertPts.filter((_, i) => [3, 4].includes(i)).map((p, i) => (
            <circle key={i} cx={p[0]} cy={p[1]} r="3"
              fill="white" fillOpacity="0.7" />
          ))}
        </svg>

        {/* Legend */}
        <div className="flex items-center gap-6 mt-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-px bg-white/60" />
            <span className="font-mono-custom text-[9px] text-white/40 tracking-wider">上級者</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 border-t border-dashed border-white/25" />
            <span className="font-mono-custom text-[9px] text-white/25 tracking-wider">初級者</span>
          </div>
          <span className="font-mono-custom text-[9px] text-white/20 ml-auto">
            FL = フォールライン
          </span>
        </div>
      </div>
    </div>
  );
}
