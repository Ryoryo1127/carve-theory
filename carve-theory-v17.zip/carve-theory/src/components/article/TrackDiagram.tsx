"use client";

import { useEffect, useState, useRef } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface TrackDiagramProps {
  className?: string;
}

export function TrackDiagram({ className }: TrackDiagramProps) {
  const [animated, setAnimated] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) setAnimated(true); },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className={cn("my-10 border border-white/8 bg-[#0c0c0c]", className)}>
      {/* Header */}
      <div className="px-6 py-4 border-b border-white/6 flex items-center gap-3">
        <div className="w-4 h-px bg-white/30" />
        <p className="font-mono-custom text-[9px] text-white/30 tracking-[0.2em] uppercase">
          Schprur Comparison
        </p>
      </div>

      <div className="p-6">
        <h4 className="font-display font-bold text-white/80 text-xl mb-6">
          シュプールで判断する
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Carving track */}
          <TrackPanel
            label="カービング"
            labelEn="TRUE CARVING"
            description="一本の細い線。板のトップからテールまで同じラインを追っている。"
            positive
            animated={animated}
            trackType="carving"
          />

          {/* Drift track */}
          <TrackPanel
            label="ドリフト（ズレ）"
            labelEn="SKIDDED TURN"
            description="二本の線が広がっている。テールが外側に逃げている証拠。"
            positive={false}
            animated={animated}
            trackType="drift"
          />
        </div>

        <p className="text-white/25 text-xs mt-5 leading-relaxed">
          滑走後に振り返ってシュプールを確認する習慣をつけることが、カービング上達の最短ルートだ。
          撮影して後から分析するのも効果的。
        </p>
      </div>
    </div>
  );
}

function TrackPanel({
  label,
  labelEn,
  description,
  positive,
  animated,
  trackType,
}: {
  label: string;
  labelEn: string;
  description: string;
  positive: boolean;
  animated: boolean;
  trackType: "carving" | "drift";
}) {
  const W = 180, H = 280;

  return (
    <div className={cn(
      "border p-5",
      positive ? "border-white/12 bg-white/[0.02]" : "border-white/6 bg-transparent"
    )}>
      {/* Status */}
      <div className="flex items-center gap-2 mb-4">
        <div className={cn(
          "w-2 h-2 rounded-full",
          positive ? "bg-white/60" : "bg-white/20"
        )} />
        <span className="font-display font-bold text-sm text-white/75">{label}</span>
        <span className="font-mono-custom text-[8px] text-white/25 ml-auto tracking-widest">
          {labelEn}
        </span>
      </div>

      {/* SVG track */}
      <div className="flex justify-center mb-4">
        <svg viewBox={`0 0 ${W} ${H}`} className="w-32 h-48" aria-label={`${label}のシュプール`}>
          {/* Slope lines */}
          {[60, 130, 200].map((y) => (
            <line key={y} x1={10} y1={y} x2={W - 10} y2={y + 8}
              stroke="white" strokeOpacity="0.04" strokeWidth="1" />
          ))}

          {trackType === "carving" ? (
            <>
              {/* Single clean carved line */}
              <motion.path
                d="M 90 20 Q 140 70 120 130 Q 100 190 150 240 Q 160 255 140 270"
                stroke="rgba(255,255,255,0.7)"
                strokeWidth="1.5"
                fill="none"
                strokeLinecap="round"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: animated ? 1 : 0 }}
                transition={{ duration: 1.6, ease: "easeInOut" }}
              />
              {/* Arrow indicating direction */}
              <motion.circle
                cx={140} cy={270} r={3}
                fill="rgba(255,255,255,0.6)"
                initial={{ opacity: 0 }}
                animate={{ opacity: animated ? 1 : 0 }}
                transition={{ delay: 1.5 }}
              />
            </>
          ) : (
            <>
              {/* Two diverging lines = skid */}
              <motion.path
                d="M 85 20 Q 135 70 110 130 Q 80 190 130 240"
                stroke="rgba(255,255,255,0.35)"
                strokeWidth="1.5"
                fill="none"
                strokeLinecap="round"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: animated ? 1 : 0 }}
                transition={{ duration: 1.6, ease: "easeInOut" }}
              />
              <motion.path
                d="M 95 20 Q 155 80 140 145 Q 135 205 168 248"
                stroke="rgba(255,255,255,0.2)"
                strokeWidth="1.5"
                fill="none"
                strokeLinecap="round"
                strokeDasharray="5 3"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: animated ? 1 : 0 }}
                transition={{ duration: 1.6, ease: "easeInOut", delay: 0.1 }}
              />
              {/* Spread indicator at end */}
              <motion.line
                x1={130} y1={240} x2={168} y2={248}
                stroke="rgba(248,113,113,0.5)" strokeWidth="1"
                strokeDasharray="3 2"
                initial={{ opacity: 0 }}
                animate={{ opacity: animated ? 1 : 0 }}
                transition={{ delay: 1.5 }}
              />
            </>
          )}
        </svg>
      </div>

      <p className={cn(
        "text-xs leading-relaxed",
        positive ? "text-white/50" : "text-white/30"
      )}>
        {description}
      </p>
    </div>
  );
}

/* ── Body Position Diagram ── */
interface PositionPoint {
  label: string;
  good: string;
  bad: string;
}

const POSITIONS: PositionPoint[] = [
  { label: "視線", good: "2〜3ターン先を見ている", bad: "板の先や直前を見ている" },
  { label: "肩のライン", good: "斜面に対してほぼ水平", bad: "内肩が下がり内倒している" },
  { label: "骨盤", good: "谷方向に正対、前傾", bad: "回転し後傾になっている" },
  { label: "膝", good: "外膝を押し出すように適度に曲げる", bad: "内側に入り込んでいる" },
  { label: "足首", good: "ブーツのタングを押す軽い圧", bad: "過度に押して板のテールを浮かせる" },
  { label: "外足荷重", good: "拇指球に体重を感じている", bad: "体重が抜け内足頼りになっている" },
];

export function BodyPositionTable({ className }: { className?: string }) {
  return (
    <div className={cn("my-10", className)}>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-5 h-px bg-white/25" />
        <p className="font-mono-custom text-[9px] text-white/30 tracking-[0.2em] uppercase">
          Body Position Check
        </p>
      </div>
      <h4 className="font-display font-bold text-white/80 text-xl mb-5">
        ポジション確認表
      </h4>

      <div className="space-y-px">
        {POSITIONS.map((pos, i) => (
          <motion.div
            key={pos.label}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay: i * 0.04 }}
            className="grid grid-cols-[100px_1fr_1fr] gap-px"
          >
            <div className="bg-[#0c0c0c] border border-white/5 px-3 py-3 flex items-center">
              <span className="font-display font-bold text-white/60 text-sm">{pos.label}</span>
            </div>
            <div className="bg-[#0a0a0a] border border-white/5 px-4 py-3 flex items-start gap-2">
              <span className="text-green-500/40 text-[10px] font-mono-custom flex-shrink-0 mt-0.5">○</span>
              <p className="text-white/55 text-xs leading-relaxed">{pos.good}</p>
            </div>
            <div className="bg-[#090909] border border-white/5 px-4 py-3 flex items-start gap-2">
              <span className="text-red-500/40 text-[10px] font-mono-custom flex-shrink-0 mt-0.5">×</span>
              <p className="text-white/30 text-xs leading-relaxed">{pos.bad}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
