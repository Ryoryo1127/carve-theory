"use client";

import { useEffect, useRef } from "react";

interface ArticleBodyProps {
  content: string;
}

/* シンプルなMarkdown→HTML変換（本番ではnext-mdx-remoteを使う） */
function markdownToHtml(markdown: string): string {
  return markdown
    // h2
    .replace(/^## (.+)$/gm, (_, t) => {
      const id = t
        .toLowerCase()
        .replace(/[^a-z0-9\u3040-\u9fff\u30a0-\u30ff\u4e00-\u9fff]/g, "-")
        .replace(/-+/g, "-");
      return `<h2 id="${id}">${t}</h2>`;
    })
    // h3
    .replace(/^### (.+)$/gm, (_, t) => {
      const id = t
        .toLowerCase()
        .replace(/[^a-z0-9\u3040-\u9fff\u30a0-\u30ff\u4e00-\u9fff]/g, "-")
        .replace(/-+/g, "-");
      return `<h3 id="${id}">${t}</h3>`;
    })
    // bold
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    // italic
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    // code inline
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    // hr
    .replace(/^---$/gm, "<hr>")
    // blockquote
    .replace(/^> (.+)$/gm, "<blockquote>$1</blockquote>")
    // ul
    .replace(/^- (.+)$/gm, "<li>$1</li>")
    .replace(/(<li>[\s\S]+?<\/li>\n?)+/g, (m) => `<ul>${m}</ul>`)
    // ol
    .replace(/^\d+\. (.+)$/gm, "<li>$1</li>")
    // paragraphs
    .split(/\n\n+/)
    .map((block) => {
      if (/^<(h[23]|ul|ol|hr|blockquote)/.test(block.trim())) return block;
      if (!block.trim()) return "";
      return `<p>${block.replace(/\n/g, " ").trim()}</p>`;
    })
    .join("\n");
}

export function ArticleBody({ content }: ArticleBodyProps) {
  const ref = useRef<HTMLDivElement>(null);

  // Add smooth scroll to internal links
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const links = el.querySelectorAll('a[href^="#"]');
    const handler = (e: Event) => {
      const a = e.currentTarget as HTMLAnchorElement;
      const target = document.getElementById(a.hash.slice(1));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: "smooth" });
      }
    };
    links.forEach((l) => l.addEventListener("click", handler));
    return () => links.forEach((l) => l.removeEventListener("click", handler));
  }, []);

  const html = markdownToHtml(content);

  return (
    <div
      ref={ref}
      className="prose-carve"
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
