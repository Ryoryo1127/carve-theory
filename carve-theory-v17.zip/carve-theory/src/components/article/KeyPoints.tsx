"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Copy, Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface KeyPoint {
  text: string;
  emphasis?: boolean;
}

interface KeyPointsCardProps {
  title?: string;
  points: KeyPoint[];
  variant?: "summary" | "principle" | "warning";
  className?: string;
}

export function KeyPointsCard({
  title = "この記事のキーポイント",
  points,
  variant = "summary",
  className,
}: KeyPointsCardProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    const text = points.map((p) => `・${p.text}`).join("\n");
    await navigator.clipboard.writeText(`【${title}】\n${text}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const accentColor =
    variant === "warning"
      ? "border-red-500/20 bg-red-950/10"
      : variant === "principle"
      ? "border-white/15 bg-white/[0.03]"
      : "border-white/10 bg-white/[0.025]";

  return (
    <div className={cn("my-10 border", accentColor, className)}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-white/6">
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-1 h-5",
            variant === "warning" ? "bg-red-500/50" : "bg-white/40"
          )} />
          <span className="font-display font-bold text-white/80 text-sm">{title}</span>
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-white/25 hover:text-white/60 transition-colors text-xs font-mono-custom tracking-widest"
          aria-label="コピー"
        >
          {copied ? (
            <>
              <Check size={11} className="text-green-400" />
              <span className="text-green-400">COPIED</span>
            </>
          ) : (
            <>
              <Copy size={11} />
              COPY
            </>
          )}
        </button>
      </div>

      {/* Points */}
      <ul className="p-5 space-y-3">
        {points.map((point, i) => (
          <motion.li
            key={i}
            initial={{ opacity: 0, x: -6 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay: i * 0.05 }}
            className="flex items-start gap-3"
          >
            <span className="font-mono-custom text-[9px] text-white/25 flex-shrink-0 pt-0.5">
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className={cn(
              "text-sm leading-relaxed",
              point.emphasis ? "text-white/85 font-medium" : "text-white/55"
            )}>
              {point.text}
            </span>
          </motion.li>
        ))}
      </ul>
    </div>
  );
}

/* ── Inline callout box ── */
interface CalloutProps {
  type?: "info" | "tip" | "warning" | "quote";
  children: React.ReactNode;
  label?: string;
  className?: string;
}

export function Callout({ type = "info", children, label, className }: CalloutProps) {
  const styles = {
    info: "border-white/12 bg-white/[0.03]",
    tip: "border-white/15 bg-white/[0.04]",
    warning: "border-red-500/20 bg-red-950/10",
    quote: "border-l-2 border-white/30 bg-transparent pl-5",
  };

  const labels = {
    info: "INFO",
    tip: "現場のコツ",
    warning: "注意",
    quote: "",
  };

  return (
    <div className={cn(
      "my-6 border px-5 py-4",
      styles[type],
      type === "quote" ? "border-0 border-l-2" : "",
      className
    )}>
      {(label ?? labels[type]) && type !== "quote" && (
        <p className="font-mono-custom text-[8px] text-white/25 tracking-[0.2em] uppercase mb-2">
          {label ?? labels[type]}
        </p>
      )}
      <div className={cn(
        "text-sm leading-relaxed",
        type === "warning" ? "text-red-300/70" :
        type === "quote" ? "text-white/50 italic" :
        "text-white/60"
      )}>
        {children}
      </div>
    </div>
  );
}
