"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

export interface FailurePattern {
  name: string;
  nameEn: string;
  cause: string;       // 原因
  symptom: string;     // 症状・見え方
  fix: string;         // 修正法
  drill?: string;      // 即効ドリル
  severity: "critical" | "common" | "minor";
}

interface FailurePatternsProps {
  patterns: FailurePattern[];
  className?: string;
}

const SEVERITY = {
  critical: { label: "要注意", color: "text-red-400", bg: "bg-red-500/10 border-red-500/20" },
  common: { label: "よくある", color: "text-yellow-400", bg: "bg-yellow-500/10 border-yellow-500/20" },
  minor: { label: "軽度", color: "text-white/40", bg: "bg-white/5 border-white/10" },
};

export function FailurePatterns({ patterns, className }: FailurePatternsProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className={cn("my-10", className)}>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-5 h-px bg-white/25" />
        <p className="font-mono-custom text-[9px] text-white/30 tracking-[0.2em] uppercase">
          Failure Patterns
        </p>
      </div>
      <h4 className="font-display font-bold text-white/80 text-xl mb-5">
        よくある失敗と修正法
      </h4>

      <div className="space-y-px">
        {patterns.map((p, i) => {
          const sv = SEVERITY[p.severity];
          const isOpen = openIndex === i;

          return (
            <div key={p.name} className="border border-white/6 bg-[#0a0a0a] overflow-hidden">
              {/* Header row */}
              <button
                className="w-full flex items-center gap-4 px-5 py-4 text-left group"
                onClick={() => setOpenIndex(isOpen ? null : i)}
                aria-expanded={isOpen}
              >
                {/* Icon */}
                <AlertTriangle
                  size={14}
                  className={cn("flex-shrink-0 transition-opacity", sv.color, isOpen ? "opacity-80" : "opacity-40")}
                />

                {/* Name */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="font-display font-bold text-white/75 group-hover:text-white/90 transition-colors text-base">
                      {p.name}
                    </span>
                    <span className="font-mono-custom text-[9px] text-white/25 tracking-wider">
                      {p.nameEn}
                    </span>
                  </div>
                  {!isOpen && (
                    <p className="text-white/30 text-xs mt-0.5 truncate">{p.symptom}</p>
                  )}
                </div>

                {/* Severity + chevron */}
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className={cn(
                    "font-mono-custom text-[8px] border px-2 py-0.5 tracking-wider hidden sm:inline",
                    sv.bg, sv.color
                  )}>
                    {sv.label}
                  </span>
                  <ChevronDown
                    size={14}
                    className={cn(
                      "text-white/25 transition-transform duration-200",
                      isOpen && "rotate-180"
                    )}
                  />
                </div>
              </button>

              {/* Expanded content */}
              <AnimatePresence>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <div className="px-5 pb-5 pt-1 grid sm:grid-cols-3 gap-4 border-t border-white/5">
                      {/* Cause */}
                      <div>
                        <p className="font-mono-custom text-[8px] text-white/20 tracking-widest uppercase mb-2">
                          原因
                        </p>
                        <p className="text-white/55 text-xs leading-relaxed">{p.cause}</p>
                      </div>

                      {/* Symptom */}
                      <div>
                        <p className="font-mono-custom text-[8px] text-white/20 tracking-widest uppercase mb-2">
                          症状・見え方
                        </p>
                        <p className="text-white/55 text-xs leading-relaxed">{p.symptom}</p>
                      </div>

                      {/* Fix */}
                      <div>
                        <p className="font-mono-custom text-[8px] text-white/20 tracking-widest uppercase mb-2">
                          修正法
                        </p>
                        <p className="text-white/70 text-xs leading-relaxed">{p.fix}</p>
                        {p.drill && (
                          <div className="mt-3 border border-white/8 bg-white/[0.03] px-3 py-2">
                            <p className="font-mono-custom text-[8px] text-white/25 tracking-widest mb-1">
                              即効ドリル
                            </p>
                            <p className="text-white/50 text-xs leading-relaxed">{p.drill}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
}
