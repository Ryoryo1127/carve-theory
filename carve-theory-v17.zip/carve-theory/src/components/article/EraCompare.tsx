"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import type { TechEraComparison } from "@/types";
import { ERA_COMPARISONS } from "@/lib/constants";

interface EraCompareProps {
  comparisons?: TechEraComparison[];
  className?: string;
}

const IMPACT_LABEL = { high: "大", medium: "中", low: "低" };
const IMPACT_COLOR = {
  high: "text-red-400 border-red-500/30 bg-red-500/8",
  medium: "text-yellow-400 border-yellow-500/30 bg-yellow-500/8",
  low: "text-white/30 border-white/10 bg-white/4",
};

export function EraCompare({
  comparisons = ERA_COMPARISONS,
  className,
}: EraCompareProps) {
  const [active, setActive] = useState<number | null>(null);
  const [view, setView] = useState<"table" | "card">("table");

  return (
    <div className={cn("my-12", className)}>
      {/* ヘッダー */}
      <div className="flex items-end justify-between mb-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-5 h-px bg-white/20" />
            <span className="font-mono text-[9px] text-white/30 tracking-[0.2em] uppercase">
              Era Comparison
            </span>
          </div>
          <h4 className="font-display font-bold text-xl text-white/80">
            技術の変化：2010年代 → 2022年以降
          </h4>
        </div>
        {/* テーブル/カード切り替え */}
        <div className="flex gap-1">
          {(["table", "card"] as const).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={cn(
                "px-3 py-1.5 font-mono text-[8px] tracking-widest uppercase border transition-all",
                view === v
                  ? "bg-white text-black border-white"
                  : "border-white/10 text-white/30 hover:border-white/20 hover:text-white/50"
              )}
            >
              {v === "table" ? "TABLE" : "CARD"}
            </button>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {view === "table" ? (
          <motion.div
            key="table"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.2 }}
          >
            <TableView
              comparisons={comparisons}
              active={active}
              onSetActive={setActive}
            />
          </motion.div>
        ) : (
          <motion.div
            key="card"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.2 }}
          >
            <CardView comparisons={comparisons} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── テーブルビュー ── */
function TableView({
  comparisons,
  active,
  onSetActive,
}: {
  comparisons: TechEraComparison[];
  active: number | null;
  onSetActive: (i: number | null) => void;
}) {
  return (
    <>
      {/* カラムヘッダー */}
      <div className="grid grid-cols-[1fr_1fr_1fr_40px] gap-px mb-px">
        {[
          { label: "技術要素", sub: "ASPECT" },
          { label: "従来（〜2018年）", sub: "CLASSIC", accent: "rgba(255,255,255,0.2)" },
          { label: "現代（2022年〜）", sub: "MODERN", accent: "#22d3ee" },
          null,
        ].map((col, i) =>
          col ? (
            <div
              key={i}
              className="bg-[#0c0c0c] border border-white/6 px-4 py-2.5"
              style={col.accent ? { borderTop: `2px solid ${col.accent}` } : {}}
            >
              <div className="font-display font-bold text-xs text-white/60">{col.label}</div>
              <div className="font-mono text-[8px] text-white/20 tracking-widest mt-0.5">{col.sub}</div>
            </div>
          ) : (
            <div key={i} className="bg-[#0c0c0c] border border-white/6" />
          )
        )}
      </div>

      {/* 行 */}
      <div className="flex flex-col gap-px">
        {comparisons.map((row, i) => (
          <motion.div
            key={row.aspect}
            initial={{ opacity: 0, x: -8 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.04 }}
          >
            <div
              className={cn(
                "grid grid-cols-[1fr_1fr_1fr_40px] gap-px cursor-pointer group"
              )}
              onClick={() => onSetActive(active === i ? null : i)}
            >
              {/* 技術要素 */}
              <div className={cn(
                "border border-white/5 px-4 py-4 transition-colors",
                active === i ? "bg-white/[0.05]" : "bg-[#0a0a0a] group-hover:bg-white/[0.025]"
              )}>
                <span className="font-display font-bold text-sm text-white/70">{row.aspect}</span>
              </div>

              {/* 従来 */}
              <div className={cn(
                "border border-white/5 px-4 py-4 transition-colors",
                active === i ? "bg-[#0e0e0e]" : "bg-[#090909] group-hover:bg-[#0b0b0b]"
              )}>
                <p className="text-xs text-white/30 leading-relaxed">{row.classic}</p>
              </div>

              {/* 現代 */}
              <div className={cn(
                "border border-white/5 px-4 py-4 transition-colors relative overflow-hidden",
                active === i ? "bg-[#0a1018]" : "bg-[#090909] group-hover:bg-[#0a0f14]"
              )}>
                {/* モダン色のアクセントライン */}
                <div
                  className="absolute top-0 left-0 right-0 h-[1px] transition-opacity"
                  style={{ background: "#22d3ee", opacity: active === i ? 0.5 : 0.15 }}
                />
                <p className="text-xs text-white/65 leading-relaxed">{row.modern}</p>
              </div>

              {/* Impact */}
              <div className={cn(
                "border border-white/5 flex items-start justify-center pt-4 transition-colors",
                active === i ? "bg-white/[0.04]" : "bg-[#0a0a0a]"
              )}>
                <span className={cn(
                  "font-mono text-[7px] border px-1.5 py-0.5 tracking-wider",
                  IMPACT_COLOR[row.impact]
                )}>
                  {IMPACT_LABEL[row.impact]}
                </span>
              </div>
            </div>

            {/* 展開: なぜ変化したか */}
            <AnimatePresence>
              {active === i && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="border border-white/5 border-t-0 bg-[#0a1018] px-4 py-4 flex items-start gap-3">
                    <div
                      className="w-px self-stretch flex-shrink-0"
                      style={{ background: "#22d3ee", opacity: 0.4 }}
                    />
                    <div>
                      <p className="font-mono text-[8px] text-cyan-400/40 tracking-widest uppercase mb-2">
                        なぜ変化したか
                      </p>
                      <p className="text-xs text-white/50 leading-relaxed">{row.why}</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>

      {/* 凡例 */}
      <div className="flex items-center gap-6 mt-4 px-1">
        <span className="font-mono text-[8px] text-white/15">クリックで変化の理由を見る</span>
        <div className="flex items-center gap-4 ml-auto">
          <div className="flex items-center gap-1.5">
            <div className="w-6 h-px" style={{ background: "rgba(255,255,255,0.2)" }} />
            <span className="font-mono text-[8px] text-white/25">従来</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-6 h-px" style={{ background: "#22d3ee", opacity: 0.6 }} />
            <span className="font-mono text-[8px] text-cyan-400/50">現代</span>
          </div>
        </div>
      </div>
    </>
  );
}

/* ── カードビュー（モバイル向け） ── */
function CardView({ comparisons }: { comparisons: TechEraComparison[] }) {
  return (
    <div className="space-y-3">
      {comparisons.map((row, i) => (
        <motion.div
          key={row.aspect}
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.05 }}
          className="border border-white/8 bg-[#0a0a0a] overflow-hidden"
        >
          <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between">
            <span className="font-display font-bold text-sm text-white/75">{row.aspect}</span>
            <span className={cn(
              "font-mono text-[7px] border px-1.5 py-0.5",
              IMPACT_COLOR[row.impact]
            )}>
              {IMPACT_LABEL[row.impact]}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-px bg-white/5">
            <div className="bg-[#090909] px-4 py-4">
              <p className="font-mono text-[8px] text-white/20 tracking-widest mb-2">〜2018</p>
              <p className="text-xs text-white/35 leading-relaxed">{row.classic}</p>
            </div>
            <div className="bg-[#090f14] px-4 py-4 relative">
              <div className="absolute top-0 left-0 right-0 h-[1px]" style={{ background: "#22d3ee", opacity: 0.4 }} />
              <p className="font-mono text-[8px] text-cyan-400/50 tracking-widest mb-2">2022〜</p>
              <p className="text-xs text-white/60 leading-relaxed">{row.modern}</p>
            </div>
          </div>
          <div className="px-4 py-3 bg-[#080d12]">
            <p className="font-mono text-[8px] text-cyan-400/30 tracking-widest mb-1">変化の理由</p>
            <p className="text-[11px] text-white/35 leading-relaxed">{row.why}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
