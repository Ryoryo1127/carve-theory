"use client";

import {
  useState,
  useRef,
  useEffect,
  useCallback,
  useMemo,
} from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { Play, Pause, ChevronRight, Activity, Eye, AlertTriangle, Zap } from "lucide-react";
import type { LucideProps } from "lucide-react";
import { cn } from "@/lib/utils";

/* ─────────────────────────────────────────────────────────────
   型定義
───────────────────────────────────────────────────────────── */

export type CheckpointCategory =
  | "pressure"   // 荷重・プレッシャー
  | "edge"       // エッジング
  | "position"   // ポジション・重心
  | "transition" // 切り替え
  | "error"      // 失敗・問題点
  | "key"        // キーポイント（デフォルト）;

export interface Checkpoint {
  /** "0:32" or "1:15" or "2:04:30" */
  time: string;
  /** 短いラベル（タイムライン上に表示） */
  label: string;
  /** 詳細な分析コメント */
  analysis: string;
  /** チェックポイントの種類 */
  category?: CheckpointCategory;
  /** 注目すべき身体部位や技術要素 */
  focus?: string;
}

export interface VideoEmbedProps {
  videoId: string;
  title: string;
  description?: string;
  /** 分析チェックポイント */
  checkpoints?: Checkpoint[];
  /** 動画の総秒数（タイムライン表示に使用） */
  durationSeconds?: number;
  className?: string;
}

/* ─────────────────────────────────────────────────────────────
   定数
───────────────────────────────────────────────────────────── */

type IconComponent = React.ComponentType<Pick<LucideProps, "size" | "className">>;

const CATEGORY_CONFIG: Record<
  CheckpointCategory,
  { color: string; bg: string; border: string; icon: IconComponent; label: string }
> = {
  pressure: {
    color: "#60a5fa",
    bg: "rgba(96,165,250,0.08)",
    border: "rgba(96,165,250,0.25)",
    icon: Activity,
    label: "荷重",
  },
  edge: {
    color: "#fbbf24",
    bg: "rgba(251,191,36,0.08)",
    border: "rgba(251,191,36,0.25)",
    icon: Zap,
    label: "エッジ",
  },
  position: {
    color: "#34d399",
    bg: "rgba(52,211,153,0.08)",
    border: "rgba(52,211,153,0.25)",
    icon: Eye,
    label: "ポジション",
  },
  transition: {
    color: "#a78bfa",
    bg: "rgba(167,139,250,0.08)",
    border: "rgba(167,139,250,0.25)",
    icon: ChevronRight,
    label: "切り替え",
  },
  error: {
    color: "#f87171",
    bg: "rgba(248,113,113,0.08)",
    border: "rgba(248,113,113,0.25)",
    icon: AlertTriangle,
    label: "問題点",
  },
  key: {
    color: "rgba(255,255,255,0.7)",
    bg: "rgba(255,255,255,0.05)",
    border: "rgba(255,255,255,0.15)",
    icon: Play,
    label: "キー",
  },
};

/* ─────────────────────────────────────────────────────────────
   ユーティリティ
───────────────────────────────────────────────────────────── */

/** "M:SS" or "MM:SS" → 秒数 */
function parseTime(t: string): number {
  const parts = t.split(":").map(Number);
  if (parts.length === 3) return (parts[0]??0) * 3600 + (parts[1]??0) * 60 + (parts[2]??0);
  if (parts.length === 2) return (parts[0]??0) * 60 + (parts[1]??0);
  return 0;
}

/** 秒数 → "M:SS" */
function formatTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

/* ─────────────────────────────────────────────────────────────
   YouTube iframe API をラップするカスタムフック
   postMessageでシークのみ制御（Player API未使用）
───────────────────────────────────────────────────────────── */

function useYouTubePlayer(videoId: string) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  /* postMessage で YouTube iframe API を操作 */
  const postToYT = useCallback((func: string, args?: unknown[]) => {
    iframeRef.current?.contentWindow?.postMessage(
      JSON.stringify({ event: "command", func, args: args ?? [] }),
      "*"
    );
  }, []);

  const seekTo = useCallback(
    (seconds: number) => {
      postToYT("seekTo", [seconds, true]);
      setCurrentTime(seconds);
    },
    [postToYT]
  );

  const play = useCallback(() => {
    postToYT("playVideo");
    setIsPlaying(true);
  }, [postToYT]);

  const pause = useCallback(() => {
    postToYT("pauseVideo");
    setIsPlaying(false);
  }, [postToYT]);

  /* YouTube からのメッセージを受け取る */
  useEffect(() => {
    const handler = (e: MessageEvent) => {
      try {
        const data = typeof e.data === "string" ? JSON.parse(e.data) : e.data;
        if (data?.event === "infoDelivery" && data?.info?.currentTime != null) {
          setCurrentTime(data.info.currentTime as number);
        }
        if (data?.event === "onStateChange") {
          // 1=playing, 2=paused, 0=ended
          if (data.info === 1) setIsPlaying(true);
          if (data.info === 2 || data.info === 0) setIsPlaying(false);
        }
      } catch {
        // ignore non-JSON messages
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  /* 再生中は0.5秒ごとにgetVideoDataを要求して時間を取得 */
  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        postToYT("getVideoData");
      }, 500);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isPlaying, postToYT]);

  return { iframeRef, isPlaying, currentTime, seekTo, play, pause };
}

/* ─────────────────────────────────────────────────────────────
   タイムライン上のマーカー点
───────────────────────────────────────────────────────────── */

function TimelineMarker({
  checkpoint,
  position,
  isActive,
  onClick,
}: {
  checkpoint: Checkpoint;
  position: number; // 0~100%
  isActive: boolean;
  onClick: () => void;
}) {
  const cat = CATEGORY_CONFIG[checkpoint.category ?? "key"];

  return (
    <motion.button
      className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 group z-10"
      style={{ left: `${position}%` }}
      onClick={onClick}
      whileHover={{ scale: 1.3 }}
      whileTap={{ scale: 0.9 }}
      aria-label={`${checkpoint.time}: ${checkpoint.label}`}
    >
      {/* ドット */}
      <motion.div
        className="w-3 h-3 rounded-full border-2 transition-colors duration-200"
        style={{
          background: isActive ? cat.color : "rgba(255,255,255,0.15)",
          borderColor: isActive ? cat.color : "rgba(255,255,255,0.3)",
          boxShadow: isActive ? `0 0 8px ${cat.color}66` : "none",
        }}
        animate={isActive ? { scale: [1, 1.3, 1] } : { scale: 1 }}
        transition={{ duration: 0.4, repeat: isActive ? Infinity : 0, repeatDelay: 1.5 }}
      />

      {/* ホバー時のラベル吹き出し */}
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-150 pointer-events-none whitespace-nowrap">
        <div
          className="px-2 py-1 text-[9px] font-mono rounded-sm"
          style={{
            background: "rgba(10,10,10,0.95)",
            border: `1px solid ${cat.color}44`,
            color: cat.color,
          }}
        >
          {checkpoint.time}
        </div>
      </div>
    </motion.button>
  );
}

/* ─────────────────────────────────────────────────────────────
   分析パネル（アクティブチェックポイントの詳細）
───────────────────────────────────────────────────────────── */

function AnalysisPanel({ checkpoint }: { checkpoint: Checkpoint }) {
  const cat = CATEGORY_CONFIG[checkpoint.category ?? "key"];
  const Icon = cat.icon;
  const prefersReduced = useReducedMotion();

  return (
    <motion.div
      key={checkpoint.time}
      initial={prefersReduced ? { opacity: 0 } : { opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={prefersReduced ? { opacity: 0 } : { opacity: 0, y: -8 }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      className="relative overflow-hidden"
      style={{
        background: cat.bg,
        border: `1px solid ${cat.border}`,
      }}
    >
      {/* 左カラーバー */}
      <div
        className="absolute top-0 left-0 bottom-0 w-[2px]"
        style={{ background: cat.color }}
      />

      <div className="px-5 py-4 pl-6">
        {/* ヘッダー行 */}
        <div className="flex items-center gap-2.5 mb-3">
          <span style={{ color: cat.color, display:"flex", alignItems:"center" }}><Icon size={12} /></span>
          <span
            className="font-mono text-[9px] tracking-[0.18em] uppercase"
            style={{ color: cat.color }}
          >
            {cat.label}
          </span>
          <span className="ml-auto font-mono text-[10px] tabular-nums"
            style={{ color: "rgba(255,255,255,0.3)" }}
          >
            {checkpoint.time}
          </span>
        </div>

        {/* ラベル */}
        <p className="font-display font-bold text-sm text-white/80 leading-snug mb-2">
          {checkpoint.label}
        </p>

        {/* 分析コメント */}
        <p className="text-xs text-white/50 leading-[1.8]">
          {checkpoint.analysis}
        </p>

        {/* フォーカス */}
        {checkpoint.focus && (
          <div className="mt-3 flex items-center gap-2">
            <span className="font-mono text-[8px] text-white/20 tracking-widest uppercase">
              注目
            </span>
            <span
              className="font-mono text-[9px] px-2 py-0.5"
              style={{
                color: cat.color,
                background: `${cat.color}15`,
                border: `1px solid ${cat.color}30`,
              }}
            >
              {checkpoint.focus}
            </span>
          </div>
        )}
      </div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────────────────────────
   チェックポイントリスト（サイドパネル or 下部）
───────────────────────────────────────────────────────────── */

function CheckpointList({
  checkpoints,
  activeIndex,
  onSelect,
}: {
  checkpoints: Checkpoint[];
  activeIndex: number | null;
  onSelect: (index: number, seconds: number) => void;
}) {
  return (
    <ul className="space-y-px">
      {checkpoints.map((cp, i) => {
        const cat = CATEGORY_CONFIG[cp.category ?? "key"];
        const Icon = cat.icon;
        const isActive = activeIndex === i;

        return (
          <motion.li key={cp.time} layout>
            <button
              onClick={() => onSelect(i, parseTime(cp.time))}
              className={cn(
                "w-full flex items-start gap-3 px-4 py-3 text-left transition-all duration-150 group",
                isActive
                  ? "bg-white/[0.06]"
                  : "hover:bg-white/[0.03]"
              )}
              style={{
                borderLeft: `2px solid ${isActive ? cat.color : "transparent"}`,
              }}
            >
              {/* 時刻 */}
              <span
                className="font-mono text-[10px] tabular-nums flex-shrink-0 pt-0.5"
                style={{ color: isActive ? cat.color : "rgba(255,255,255,0.25)" }}
              >
                {cp.time}
              </span>

              {/* 内容 */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span style={{ color: isActive ? cat.color : "rgba(255,255,255,0.2)", display:"flex", alignItems:"center", flexShrink:0 }}><Icon size={9} /></span>
                  <span
                    className="font-mono text-[8px] tracking-widest uppercase"
                    style={{ color: isActive ? cat.color : "rgba(255,255,255,0.2)" }}
                  >
                    {cat.label}
                  </span>
                </div>
                <p
                  className="text-xs leading-snug line-clamp-1 transition-colors"
                  style={{ color: isActive ? "rgba(255,255,255,0.8)" : "rgba(255,255,255,0.4)" }}
                >
                  {cp.label}
                </p>
              </div>

              {/* アクティブインジケーター */}
              <motion.div
                animate={{ opacity: isActive ? 1 : 0, scale: isActive ? 1 : 0.5 }}
                className="w-1 h-1 rounded-full flex-shrink-0 mt-1.5"
                style={{ background: cat.color }}
              />
            </button>
          </motion.li>
        );
      })}
    </ul>
  );
}

/* ─────────────────────────────────────────────────────────────
   カテゴリ凡例
───────────────────────────────────────────────────────────── */

function CategoryLegend({ categories }: { categories: Set<CheckpointCategory> }) {
  const catArray = Array.from(categories);
  if (catArray.length <= 1) return null;

  return (
    <div className="flex flex-wrap items-center gap-3">
      {catArray.map((c) => {
        const cfg = CATEGORY_CONFIG[c];
        const Icon = cfg.icon;
        return (
          <div key={c} className="flex items-center gap-1.5">
            <span style={{ color: cfg.color, display:"flex" }}><Icon size={9} /></span>
            <span
              className="font-mono text-[8px] tracking-wider"
              style={{ color: "rgba(255,255,255,0.35)" }}
            >
              {cfg.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────
   メインコンポーネント
───────────────────────────────────────────────────────────── */

export function VideoEmbed({
  videoId,
  title,
  description,
  checkpoints = [],
  durationSeconds,
  className,
}: VideoEmbedProps) {
  const [loaded, setLoaded] = useState(false);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [layout, setLayout] = useState<"side" | "bottom">("side");
  const wrapperRef = useRef<HTMLDivElement>(null);

  const thumbUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
  const fallbackThumb = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

  const { iframeRef, isPlaying, currentTime, seekTo, play, pause } =
    useYouTubePlayer(videoId);

  /* 動画の総秒数を推定（checkpointsの最大値から+30秒） */
  const totalDuration = useMemo(() => {
    if (durationSeconds) return durationSeconds;
    if (checkpoints.length === 0) return 300; // 5分デフォルト
    const maxSec = Math.max(...checkpoints.map((c) => parseTime(c.time)));
    return maxSec + 30;
  }, [checkpoints, durationSeconds]);

  /* 現在時刻に最も近いチェックポイントをアクティブにする */
  useEffect(() => {
    if (!isPlaying || checkpoints.length === 0) return;
    const idx = checkpoints.reduce<number | null>((best, cp, i) => {
      const sec = parseTime(cp.time);
      const diff = Math.abs(currentTime - sec);
      if (diff > 3) return best; // 3秒以内のみ
      if (best === null) return i;
      return diff < Math.abs(currentTime - parseTime(checkpoints[best]!.time))
        ? i
        : best;
    }, null);
    setActiveIndex(idx);
  }, [currentTime, isPlaying, checkpoints]);

  /* レスポンシブ: コンテナ幅で layout 切り替え */
  useEffect(() => {
    if (!wrapperRef.current) return;
    const obs = new ResizeObserver(([entry]) => {
      setLayout((entry?.contentRect.width ?? 0) >= 860 ? "side" : "bottom");
    });
    obs.observe(wrapperRef.current);
    return () => obs.disconnect();
  }, []);

  /* チェックポイントクリック */
  const handleCheckpointSelect = useCallback(
    (index: number, seconds: number) => {
      setActiveIndex(index);
      if (loaded) {
        seekTo(seconds);
        play();
      }
    },
    [loaded, seekTo, play]
  );

  /* 使用カテゴリのセット */
  const usedCategories = useMemo(
    () =>
      new Set(
        checkpoints.map((c) => (c.category ?? "key") as CheckpointCategory)
      ),
    [checkpoints]
  );

  const activeCheckpoint =
    activeIndex !== null ? checkpoints[activeIndex] : null;

  const hasCheckpoints = checkpoints.length > 0;

  return (
    <div ref={wrapperRef} className={cn("my-10", className)}>
      {/* ── ヘッダー ── */}
      <div className="flex items-center gap-3 mb-4">
        <div className="w-5 h-px bg-white/20" />
        <span className="font-mono text-[9px] text-white/30 tracking-[0.2em] uppercase">
          Video Analysis
        </span>
        {hasCheckpoints && (
          <>
            <div className="flex-1 h-px bg-white/5" />
            <CategoryLegend categories={usedCategories} />
          </>
        )}
      </div>

      {/* ── メインレイアウト ── */}
      <div
        className={cn(
          "border border-white/8 bg-[#080808] overflow-hidden",
          layout === "side" && hasCheckpoints
            ? "grid grid-cols-[1fr_280px]"
            : "flex flex-col"
        )}
      >
        {/* ── 左カラム: 動画 + タイムライン ── */}
        <div className="flex flex-col">
          {/* プレイヤー本体 */}
          <div className="relative aspect-video bg-black">
            {!loaded ? (
              /* サムネイル */
              <button
                className="group absolute inset-0 flex items-center justify-center overflow-hidden"
                onClick={() => setLoaded(true)}
                aria-label={`動画を再生: ${title}`}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={thumbUrl}
                  alt={title}
                  className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-65 transition-opacity duration-400"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = fallbackThumb;
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

                {/* プレイボタン */}
                <motion.div
                  whileHover={{ scale: 1.06 }}
                  whileTap={{ scale: 0.94 }}
                  className="relative z-10 w-14 h-14 bg-white/95 flex items-center justify-center shadow-2xl"
                >
                  <Play size={20} fill="black" className="ml-0.5" />
                </motion.div>

                {/* タイトル */}
                <div className="absolute bottom-0 left-0 right-0 px-5 pb-4 z-10">
                  <p className="font-display font-bold text-white text-sm leading-snug line-clamp-2 drop-shadow-lg">
                    {title}
                  </p>
                  {description && (
                    <p className="text-white/50 text-xs mt-1 line-clamp-1">{description}</p>
                  )}
                </div>

                {/* チェックポイント数バッジ */}
                {hasCheckpoints && (
                  <div className="absolute top-4 right-4 z-10 flex items-center gap-1.5 bg-black/60 backdrop-blur-sm px-2.5 py-1 border border-white/10">
                    <Activity size={9} className="text-white/50" />
                    <span className="font-mono text-[9px] text-white/50 tracking-wider">
                      {checkpoints.length} CHECKPOINTS
                    </span>
                  </div>
                )}
              </button>
            ) : (
              <>
                <iframe
                  ref={iframeRef}
                  src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1&enablejsapi=1&origin=${typeof window !== "undefined" ? window.location.origin : ""}`}
                  title={title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="absolute inset-0 w-full h-full"
                />
              </>
            )}
          </div>

          {/* ── タイムライン ── */}
          {hasCheckpoints && loaded && (
            <div className="px-4 py-3 bg-[#080808] border-t border-white/5">
              {/* プログレスバー + マーカー */}
              <div className="relative h-8 flex items-center">
                {/* トラック */}
                <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-px bg-white/10" />

                {/* 再生位置インジケーター */}
                <motion.div
                  className="absolute top-1/2 -translate-y-1/2 h-[2px] bg-white/30 origin-left"
                  style={{
                    width: `${Math.min((currentTime / totalDuration) * 100, 100)}%`,
                  }}
                  transition={{ duration: 0.1 }}
                />

                {/* チェックポイントマーカー */}
                {checkpoints.map((cp, i) => {
                  const sec = parseTime(cp.time);
                  const pos = Math.min((sec / totalDuration) * 100, 100);
                  return (
                    <TimelineMarker
                      key={cp.time}
                      checkpoint={cp}
                      position={pos}
                      isActive={activeIndex === i}
                      onClick={() => handleCheckpointSelect(i, sec)}
                    />
                  );
                })}
              </div>

              {/* 時間表示 */}
              <div className="flex justify-between mt-0.5">
                <span className="font-mono text-[8px] text-white/20 tabular-nums">
                  {formatTime(currentTime)}
                </span>
                <span className="font-mono text-[8px] text-white/15 tabular-nums">
                  {formatTime(totalDuration)}
                </span>
              </div>
            </div>
          )}

          {/* ── ロード前の静的タイムライン ── */}
          {hasCheckpoints && !loaded && (
            <div className="px-4 py-3 bg-[#080808] border-t border-white/5">
              <div className="relative h-6 flex items-center">
                <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-px bg-white/8" />
                {checkpoints.map((cp, i) => {
                  const sec = parseTime(cp.time);
                  const pos = Math.min((sec / totalDuration) * 100, 100);
                  const cat = CATEGORY_CONFIG[cp.category ?? "key"];
                  return (
                    <div
                      key={cp.time}
                      className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-2 h-2 rounded-full"
                      style={{
                        left: `${pos}%`,
                        background: cat.color,
                        opacity: 0.5,
                      }}
                    />
                  );
                })}
              </div>
              <p className="font-mono text-[8px] text-white/15 mt-1 text-center">
                ▶ 再生すると連動します
              </p>
            </div>
          )}

          {/* ── アクティブ分析パネル (bottom layout) ── */}
          {layout === "bottom" && (
            <div className="border-t border-white/5">
              <AnimatePresence mode="wait">
                {activeCheckpoint ? (
                  <AnalysisPanel key={activeCheckpoint.time} checkpoint={activeCheckpoint} />
                ) : (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="px-5 py-4 text-center"
                  >
                    <p className="font-mono text-[9px] text-white/15 tracking-widest">
                      {loaded
                        ? "チェックポイントを選択 または 再生すると自動で連動"
                        : "動画を再生 または チェックポイントをクリック"}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </div>

        {/* ── 右カラム: チェックポイントリスト + 分析パネル (side layout) ── */}
        {layout === "side" && hasCheckpoints && (
          <div
            className="flex flex-col border-l border-white/5 overflow-hidden"
            style={{ minWidth: 0 }}
          >
            {/* 分析パネル */}
            <div className="flex-shrink-0 min-h-[100px]">
              <AnimatePresence mode="wait">
                {activeCheckpoint ? (
                  <AnalysisPanel
                    key={activeCheckpoint.time}
                    checkpoint={activeCheckpoint}
                  />
                ) : (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="px-5 py-5 flex flex-col items-center justify-center h-[100px]"
                  >
                    <Activity size={14} className="text-white/15 mb-2" />
                    <p className="font-mono text-[8px] text-white/15 tracking-widest text-center leading-relaxed">
                      {loaded
                        ? "再生 or クリックで\n分析が連動"
                        : "チェックポイントを\nクリックして開始"}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* チェックポイントリスト */}
            <div
              className="flex-1 overflow-y-auto border-t border-white/5"
              style={{ maxHeight: "calc(56.25vw * 0.55)" }}
            >
              <div className="px-3 py-2 border-b border-white/5 flex items-center justify-between">
                <span className="font-mono text-[8px] text-white/20 tracking-widest uppercase">
                  Checkpoints
                </span>
                <span className="font-mono text-[8px] text-white/15">
                  {checkpoints.length}
                </span>
              </div>
              <CheckpointList
                checkpoints={checkpoints}
                activeIndex={activeIndex}
                onSelect={handleCheckpointSelect}
              />
            </div>
          </div>
        )}
      </div>

      {/* ── bottom layout: チェックポイントリスト ── */}
      {layout === "bottom" && hasCheckpoints && (
        <div className="border border-t-0 border-white/8 bg-[#080808]">
          <div className="px-4 py-2 border-b border-white/5 flex items-center justify-between">
            <span className="font-mono text-[8px] text-white/20 tracking-widest uppercase">
              Checkpoints
            </span>
            <span className="font-mono text-[8px] text-white/15">{checkpoints.length}</span>
          </div>
          <CheckpointList
            checkpoints={checkpoints}
            activeIndex={activeIndex}
            onSelect={handleCheckpointSelect}
          />
        </div>
      )}

      {/* ── 説明文 ── */}
      {description && !loaded && (
        <p className="mt-3 text-xs text-white/30 leading-relaxed">{description}</p>
      )}
    </div>
  );
}
