import { cn, LEVEL_COLORS, ROUTE_COLORS } from "@/lib/utils";
import type { LevelType, RouteType } from "@/types";

interface BadgeProps {
  children: React.ReactNode;
  className?: string;
  variant?: "default" | "outline";
  size?: "sm" | "md";
}

export function Badge({
  children,
  className,
  variant = "default",
  size = "sm",
}: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center font-mono-custom tracking-widest uppercase border",
        size === "sm" ? "text-[9px] px-2 py-0.5" : "text-[10px] px-2.5 py-1",
        variant === "outline"
          ? "bg-transparent border-white/15 text-white/50"
          : "bg-white/8 border-white/12 text-white/60",
        className
      )}
    >
      {children}
    </span>
  );
}

export function LevelBadge({ level }: { level: LevelType }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 text-[9px] font-mono-custom tracking-widest uppercase px-2 py-0.5 border",
        LEVEL_COLORS[level]
      )}
    >
      <span className="w-1 h-1 rounded-full bg-current opacity-70" />
      {level}
    </span>
  );
}

export function RouteBadge({ route }: { route: RouteType }) {
  return (
    <span
      className={cn(
        "inline-flex items-center text-[9px] font-mono-custom tracking-widest uppercase px-2 py-0.5 border",
        ROUTE_COLORS[route]
      )}
    >
      {route}
    </span>
  );
}
