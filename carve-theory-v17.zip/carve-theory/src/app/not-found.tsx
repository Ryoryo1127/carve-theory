import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

export default function NotFound() {
  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen flex items-center justify-center bg-[#080808]">
        <div className="text-center px-6">
          <p className="font-mono-custom text-[10px] text-white/20 tracking-[0.25em] uppercase mb-6">
            404 Not Found
          </p>
          <h1 className="font-display font-black text-white text-6xl md:text-8xl mb-4">
            404
          </h1>
          <p className="text-white/35 text-sm mb-10 max-w-xs mx-auto leading-relaxed">
            ページが見つかりませんでした。
            コースを外れてしまったようです。
          </p>
          <Link
            href="/"
            className="inline-flex items-center gap-2 bg-white text-black px-6 py-3 text-sm font-bold tracking-wider hover:bg-white/90 transition-colors"
          >
            トップに戻る
          </Link>
        </div>
      </main>
      <Footer />
    </>
  );
}
