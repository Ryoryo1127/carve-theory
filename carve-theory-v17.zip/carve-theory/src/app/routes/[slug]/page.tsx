import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { ArticleCard } from "@/components/article/ArticleCard";
import { ROUTES_DATA, getRouteBySlug } from "@/lib/routes-data";
import { MOCK_ARTICLES } from "@/lib/articles";
import { SITE_NAME, SITE_URL } from "@/lib/constants";
import { ChevronRight, ArrowRight } from "lucide-react";
import { buildRoutePageSchemas } from "./schema";

export async function generateStaticParams() {
  return ROUTES_DATA.map((r) => ({ slug: r.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const route = getRouteBySlug(params.slug);
  if (!route) return { title: "Not Found" };
  return {
    title: `${route.title} | ${SITE_NAME}`,
    description: route.description,
    alternates: { canonical: `${SITE_URL}/routes/${route.slug}` },
  };
}

export default function RoutePage({ params }: { params: { slug: string } }) {
  const route = getRouteBySlug(params.slug);
  if (!route) notFound();

  const recommended = route.recommendedSlugs
    .map((slug) => MOCK_ARTICLES.find((a) => a.slug === slug))
    .filter((a): a is NonNullable<typeof a> => !!a);

  const otherRoutes = ROUTES_DATA.filter((r) => r.slug !== route.slug);

  const schemaJson = buildRoutePageSchemas(route, recommended);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: schemaJson }}
      />
      <Header />
      <main className="pt-16 bg-[#080808] min-h-screen">
        {/* Header */}
        <div className="bg-[#060606] border-b border-white/5 py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 mb-8">
              <Link
                href="/"
                className="font-mono-custom text-[9px] text-white/25 hover:text-white/50 tracking-widest uppercase transition-colors"
              >
                Home
              </Link>
              <ChevronRight size={10} className="text-white/15" />
              <span className="font-mono-custom text-[9px] text-white/50 tracking-widest uppercase">
                {route.title}
              </span>
            </nav>

            <div className="w-8 h-px mb-6" style={{ background: route.color }} />

            <p className="font-mono-custom text-[9px] text-white/25 tracking-[0.2em] uppercase mb-3">
              {route.subtitle}
            </p>
            <h1 className="font-display font-black text-white text-4xl md:text-5xl mb-4">
              {route.title}
            </h1>
            <p className="text-white/40 text-sm md:text-base max-w-2xl leading-relaxed">
              {route.description}
            </p>
          </div>
        </div>

        {/* 推奨記事を順番に */}
        <section className="py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <div className="flex items-center gap-3 mb-10">
              <div className="w-5 h-px bg-white/20" />
              <span className="font-mono-custom text-[9px] text-white/25 tracking-[0.2em] uppercase">
                Recommended Order
              </span>
            </div>

            <div className="space-y-px">
              {recommended.map((article, i) => (
                <Link
                  key={article.slug}
                  href={`/articles/${article.slug}`}
                  className="group flex items-center gap-6 border border-white/6 bg-[#0a0a0a] hover:bg-[#0e0e0e] p-6 transition-colors"
                >
                  <span
                    className="font-mono text-2xl font-black flex-shrink-0"
                    style={{ color: route.color, opacity: 0.4 }}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-display font-bold text-white/85 group-hover:text-white text-base mb-1 transition-colors">
                      {article.title}
                    </h3>
                    <p className="text-white/35 text-xs leading-relaxed line-clamp-1">
                      {article.excerpt}
                    </p>
                  </div>
                  <ArrowRight
                    size={14}
                    className="text-white/20 group-hover:text-white/50 flex-shrink-0 group-hover:translate-x-0.5 transition-all"
                  />
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* 他のルートへの導線 */}
        <section className="border-t border-white/5 py-12 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-5">
              Other Routes
            </p>
            <div className="flex flex-wrap gap-2">
              {otherRoutes.map((r) => (
                <Link
                  key={r.slug}
                  href={`/routes/${r.slug}`}
                  className="font-mono-custom text-[9px] text-white/30 border border-white/8 px-3 py-1.5 hover:border-white/20 hover:text-white/60 tracking-widest transition-all"
                >
                  {r.title}
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
