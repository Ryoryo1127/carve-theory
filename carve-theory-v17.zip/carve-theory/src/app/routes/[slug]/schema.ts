/**
 * /routes/[slug] ページ用スキーマビルダー
 * CollectionPage + BreadcrumbList
 */

import {
  buildBreadcrumbSchema,
  buildCollectionPageSchema,
  buildSchemaGraph,
} from "@/lib/schema";
import type { ArticleMeta } from "@/types";
import type { RouteDefinition } from "@/lib/routes-data";
import type { AnySchema } from "@/types/schema";

export function buildRoutePageSchemas(
  route: RouteDefinition,
  articles: ArticleMeta[]
): string {
  const schemas: AnySchema[] = [];

  schemas.push(
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "学習ルート一覧", href: "/routes" },
      { name: route.title, href: `/routes/${route.slug}` },
    ])
  );

  schemas.push(
    buildCollectionPageSchema({
      slug: route.slug,
      name: `${route.title} | CARVE THEORY`,
      description: route.description,
      articles,
      basePath: "routes",
    })
  );

  return JSON.stringify(
    buildSchemaGraph(schemas),
    null,
    process.env.NODE_ENV === "development" ? 2 : 0
  );
}
