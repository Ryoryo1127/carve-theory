import type { Metadata } from "next";
import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { ROUTES_DATA } from "@/lib/routes-data";
import { SITE_NAME, SITE_URL } from "@/lib/constants";
import { ArrowRight } from "lucide-react";
import { buildBreadcrumbSchema, buildItemListSchema, buildSchemaGraph } from "@/lib/schema";
import type { AnySchema } from "@/types/schema";

export const metadata: Metadata = {
  title: `学習ルート一覧 | ${SITE_NAME}`,
  description: "レベル・種目別に、おすすめの記事を順番で読める学習ルート。",
};

export default function RoutesIndexPage() {
  const schemas: AnySchema[] = [
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "学習ルート一覧", href: "/routes" },
    ]),
    buildItemListSchema(
      `${SITE_URL}/routes#itemlist`,
      "レベル・種目別 学習ルート一覧",
      ROUTES_DATA.map((r) => ({
        name: r.title,
        url: `/routes/${r.slug}`,
        description: r.description,
      })),
      "レベル・種目別に、おすすめの記事を順番で読める学習ルート。"
    ),
  ];
  const schemaJson = JSON.stringify(buildSchemaGraph(schemas), null, 0);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: schemaJson }}
      />
      <Header />
      <main className="pt-16 bg-[#080808] min-h-screen">
        <div className="bg-[#060606] border-b border-white/5 py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-4">
              Routes
            </p>
            <h1 className="font-display font-black text-white text-4xl md:text-5xl">
              学習ルート一覧
            </h1>
          </div>
        </div>

        <section className="py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5">
            {ROUTES_DATA.map((route) => (
              <Link
                key={route.slug}
                href={`/routes/${route.slug}`}
                className="group flex flex-col p-7 bg-[#0a0a0a] hover:bg-[#0e0e0e] transition-colors duration-300"
              >
                <div
                  className="w-6 h-px mb-6 transition-opacity duration-300 opacity-50 group-hover:opacity-100"
                  style={{ background: route.color }}
                />
                <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-2">
                  {route.subtitle}
                </p>
                <h2 className="font-display font-bold text-white/80 group-hover:text-white text-2xl mb-3 transition-colors">
                  {route.title}
                </h2>
                <p className="text-white/35 text-sm leading-relaxed mb-6">
                  {route.description}
                </p>
                <div className="mt-auto flex items-center justify-between">
                  <span className="font-mono-custom text-[9px] text-white/20 tracking-widest">
                    {route.recommendedSlugs.length} 記事
                  </span>
                  <ArrowRight
                    size={13}
                    className="text-white/20 group-hover:text-white/50 group-hover:translate-x-0.5 transition-all"
                  />
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
