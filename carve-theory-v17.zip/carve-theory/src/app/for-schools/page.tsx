import type { Metadata } from "next";
import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { InquiryForm } from "@/components/business/InquiryForm";
import { SITE_NAME, SITE_URL } from "@/lib/constants";
import { buildServiceSchema, buildBreadcrumbSchema, buildSchemaGraph } from "@/lib/schema";
import type { AnySchema } from "@/types/schema";
import {
  FileText,
  BarChart3,
  BookOpen,
  ShieldCheck,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";

export const metadata: Metadata = {
  title: `スキースクール・指導者育成団体の方へ | ${SITE_NAME}`,
  description:
    "CARVE THEORYの技術解説システムをスクール・指導者育成団体向けにライセンス提供。構造化された現代技術カリキュラム、指導者研修プログラム、コンテンツ監修を承ります。",
  alternates: { canonical: `${SITE_URL}/for-schools` },
  openGraph: {
    title: `スキースクール・指導者育成団体の方へ | ${SITE_NAME}`,
    description: "現代技術論に基づく教材システムのライセンス提供。",
    url: `${SITE_URL}/for-schools`,
    type: "website",
  },
};

/* ─────────────────────────────────────────────────────────────
   提供メニュー
───────────────────────────────────────────────────────────── */

const OFFERINGS = [
  {
    icon: BookOpen,
    title: "技術カリキュラムのライセンス提供",
    description:
      "「旧技術 vs 現代技術」比較分析、圧コントロール・早期切り替えなど2026年基準の技術体系を、貴校の指導カリキュラムとして利用可能な形式で提供します。",
    points: ["指導者向け解説資料一式", "生徒向け説明素材", "貴校ブランドでの利用が可能"],
  },
  {
    icon: BarChart3,
    title: "指導者向け技術研修コンテンツ",
    description:
      "現代技術論への理解をアップデートするための研修素材。旧来の指導法との違いを定量的・視覚的に整理し、指導者間で共通言語を作ります。",
    points: ["時代比較分析データ一式", "研修用スライド・資料", "オンラインでの質疑対応"],
  },
  {
    icon: FileText,
    title: "コンテンツ監修・記事制作",
    description:
      "貴校のWebサイト・SNS向けに、技術的な正確性が保証された解説記事・コンテンツを制作します。構造化データ対応によりSEO面でも優位性があります。",
    points: ["記事制作・技術監修", "構造化データ（JSON-LD）対応", "継続的なコンテンツ更新も対応可能"],
  },
];

/* ─────────────────────────────────────────────────────────────
   進め方ステップ
───────────────────────────────────────────────────────────── */

const PROCESS_STEPS = [
  {
    step: "01",
    title: "お問い合わせ",
    description: "フォームより、課題や検討中の規模感をご連絡ください。",
  },
  {
    step: "02",
    title: "資料のご案内",
    description: "メールにて具体的な提供内容・サンプル資料をお送りします。",
  },
  {
    step: "03",
    title: "ご相談・すり合わせ",
    description: "テキスト・音声通話にて、貴校の状況に合わせた進め方を相談します。",
  },
  {
    step: "04",
    title: "ご提供開始",
    description: "契約内容に応じて教材・研修コンテンツの提供を開始します。",
  },
];

export default function ForSchoolsPage() {
  /* JSON-LD: Service + BreadcrumbList */
  const schemas: AnySchema[] = [
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "スクール・団体の方へ", href: "/for-schools" },
    ]),
    buildServiceSchema({
      name: "CARVE THEORY 技術教材ライセンス・指導者研修サービス",
      description:
        "2026年基準の現代スキー・スノーボード技術論に基づく教材・研修コンテンツを、スキースクールおよび指導者育成団体向けに提供するサービス。",
      serviceType: "技術教育コンテンツライセンス",
      offerings: OFFERINGS.map((o) => ({ name: o.title, description: o.description })),
    }),
  ];
  const schemaJson = JSON.stringify(buildSchemaGraph(schemas), null, 0);

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: schemaJson }} />
      <Header />

      <main className="pt-[60px] bg-[#050505] min-h-screen">
        {/* ── ヘッダーセクション ── */}
        <section className="relative border-b border-white/5 overflow-hidden">
          {/* グリッド背景 */}
          <div className="absolute inset-0" style={{
            backgroundImage: "linear-gradient(rgba(255,255,255,0.02) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.02) 1px,transparent 1px)",
            backgroundSize: "56px 56px",
          }} />
          <div className="absolute top-0 right-0 w-96 h-96 pointer-events-none" style={{
            background: "radial-gradient(ellipse at 100% 0%, rgba(34,211,238,0.06) 0%, transparent 70%)"
          }} />

          <div className="relative max-w-5xl mx-auto px-6 md:px-10 py-20 md:py-28">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-6 h-px bg-white/20" />
              <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
                For Schools &amp; Organizations
              </span>
            </div>

            <h1
              className="font-display font-black text-white leading-[1.1] mb-6"
              style={{ fontSize: "clamp(28px, 5vw, 52px)" }}
            >
              スキースクール・<br />
              指導者育成団体の方へ
            </h1>

            <p className="text-white/45 text-base md:text-lg leading-relaxed max-w-2xl mb-8">
              CARVE THEORYで体系化してきた2026年基準の現代技術論を、
              貴校の指導カリキュラム・研修コンテンツとしてご利用いただけます。
            </p>

            <div className="flex flex-wrap gap-3">
              <a
                href="#inquiry"
                className="inline-flex items-center gap-2 bg-white text-black px-6 py-3.5 text-sm font-bold tracking-wider hover:bg-white/90 transition-colors"
              >
                お問い合わせ <ArrowRight size={14} />
              </a>
              <a
                href="#offerings"
                className="inline-flex items-center gap-2 border border-white/15 text-white/50 px-6 py-3.5 text-sm font-medium tracking-wider hover:border-white/30 hover:text-white/75 transition-all"
              >
                提供内容を見る
              </a>
            </div>
          </div>
        </section>

        {/* ── 課題提起セクション ── */}
        <section className="border-b border-white/5 py-16 md:py-20">
          <div className="max-w-5xl mx-auto px-6 md:px-10">
            <div className="grid md:grid-cols-2 gap-px bg-white/5">
              <div className="bg-[#090909] p-8">
                <p className="font-mono text-[8px] text-white/20 tracking-widest uppercase mb-4">
                  Problem
                </p>
                <h2 className="font-display font-bold text-white/80 text-xl mb-4 leading-snug">
                  指導内容が更新されていない
                </h2>
                <p className="text-white/40 text-sm leading-relaxed">
                  外向傾・荷重・切り替えなどの基本技術論は、2022年以降大きく変化しています。
                  しかし指導現場では、旧来の理解のまま指導が続いているケースが少なくありません。
                  指導者間で技術論の前提が揃っていないと、生徒に矛盾した指導が伝わってしまいます。
                </p>
              </div>
              <div className="bg-[#080d12] p-8 relative">
                <div className="absolute top-0 left-0 right-0 h-px" style={{ background: "#22d3ee", opacity: 0.3 }} />
                <p className="font-mono text-[8px] text-cyan-400/40 tracking-widest uppercase mb-4">
                  Solution
                </p>
                <h2 className="font-display font-bold text-white/85 text-xl mb-4 leading-snug">
                  体系化された現代技術論を提供
                </h2>
                <p className="text-white/55 text-sm leading-relaxed">
                  CARVE THEORYでは、旧技術と現代技術を10項目で定量的に比較・整理し、
                  「なぜ変化したのか」まで含めた教材体系を構築しています。
                  この体系を、貴校の指導者研修・カリキュラムとしてそのままご利用いただけます。
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ── 提供メニュー ── */}
        <section id="offerings" className="border-b border-white/5 py-16 md:py-20">
          <div className="max-w-5xl mx-auto px-6 md:px-10">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-5 h-px bg-white/20" />
              <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
                Offerings
              </span>
            </div>
            <h2 className="font-display font-bold text-white text-2xl md:text-3xl mb-12">
              提供メニュー
            </h2>

            <div className="space-y-px">
              {OFFERINGS.map((offering, i) => {
                const Icon = offering.icon;
                return (
                  <div key={offering.title} className="border border-white/6 bg-[#0a0a0a] p-6 md:p-8">
                    <div className="flex flex-col md:flex-row gap-6">
                      {/* アイコン + 番号 */}
                      <div className="flex-shrink-0 flex md:flex-col items-center md:items-start gap-3">
                        <div className="w-10 h-10 border border-white/10 flex items-center justify-center">
                          <Icon size={16} className="text-cyan-400/60" />
                        </div>
                        <span className="font-mono text-[10px] text-white/20 tracking-widest">
                          {String(i + 1).padStart(2, "0")}
                        </span>
                      </div>

                      {/* コンテンツ */}
                      <div className="flex-1">
                        <h3 className="font-display font-bold text-white/85 text-lg mb-3">
                          {offering.title}
                        </h3>
                        <p className="text-white/45 text-sm leading-relaxed mb-4">
                          {offering.description}
                        </p>
                        <ul className="space-y-1.5">
                          {offering.points.map((point) => (
                            <li key={point} className="flex items-start gap-2">
                              <CheckCircle2 size={12} className="text-cyan-400/40 flex-shrink-0 mt-0.5" />
                              <span className="text-xs text-white/40">{point}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* ── 信頼性セクション（顔出しなしの専門性証明） ── */}
        <section className="border-b border-white/5 py-16 md:py-20 bg-[#060606]">
          <div className="max-w-5xl mx-auto px-6 md:px-10">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-5 h-px bg-white/20" />
              <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
                Why CARVE THEORY
              </span>
            </div>
            <h2 className="font-display font-bold text-white text-2xl md:text-3xl mb-10">
              提供体制について
            </h2>

            <div className="grid sm:grid-cols-3 gap-px bg-white/5">
              <div className="bg-[#0a0a0a] p-6">
                <ShieldCheck size={18} className="text-white/30 mb-4" />
                <h3 className="font-display font-bold text-white/75 text-sm mb-2">
                  競技・指導経験に基づく内容
                </h3>
                <p className="text-white/35 text-xs leading-relaxed">
                  競技スキー歴・複数リゾートでの指導実績をもとに、現場感のある技術解説を体系化しています。
                </p>
              </div>
              <div className="bg-[#0a0a0a] p-6">
                <BarChart3 size={18} className="text-white/30 mb-4" />
                <h3 className="font-display font-bold text-white/75 text-sm mb-2">
                  定量データに基づく整理
                </h3>
                <p className="text-white/35 text-xs leading-relaxed">
                  感覚論ではなく、メトリクス・比較データを用いた説明可能な技術体系を採用しています。
                </p>
              </div>
              <div className="bg-[#0a0a0a] p-6">
                <FileText size={18} className="text-white/30 mb-4" />
                <h3 className="font-display font-bold text-white/75 text-sm mb-2">
                  テキストベースでの対応
                </h3>
                <p className="text-white/35 text-xs leading-relaxed">
                  ご相談・制作のやり取りは基本的にメール・テキスト・音声通話で完結します。対面での打ち合わせは必須ではありません。
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ── 進め方 ── */}
        <section className="border-b border-white/5 py-16 md:py-20">
          <div className="max-w-5xl mx-auto px-6 md:px-10">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-5 h-px bg-white/20" />
              <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
                Process
              </span>
            </div>
            <h2 className="font-display font-bold text-white text-2xl md:text-3xl mb-12">
              ご相談の進め方
            </h2>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-white/5">
              {PROCESS_STEPS.map((s) => (
                <div key={s.step} className="bg-[#0a0a0a] p-6">
                  <span className="font-mono text-2xl font-bold text-white/10">{s.step}</span>
                  <h3 className="font-display font-bold text-white/75 text-sm mt-3 mb-2">
                    {s.title}
                  </h3>
                  <p className="text-white/35 text-xs leading-relaxed">{s.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── お問い合わせフォーム ── */}
        <section id="inquiry" className="py-16 md:py-24">
          <div className="max-w-2xl mx-auto px-6 md:px-10">
            <div className="text-center mb-10">
              <div className="flex items-center justify-center gap-3 mb-3">
                <div className="w-5 h-px bg-white/20" />
                <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
                  Inquiry
                </span>
                <div className="w-5 h-px bg-white/20" />
              </div>
              <h2 className="font-display font-bold text-white text-2xl md:text-3xl mb-3">
                お問い合わせ
              </h2>
              <p className="text-white/35 text-sm leading-relaxed">
                ご検討段階でのご相談も歓迎しています。まずはお気軽にご連絡ください。
              </p>
            </div>

            <InquiryForm />
          </div>
        </section>

        {/* ── 関連リンク ── */}
        <section className="border-t border-white/5 py-10">
          <div className="max-w-5xl mx-auto px-6 md:px-10 flex flex-wrap items-center justify-center gap-6">
            <Link href="/era-analysis" className="text-xs text-white/30 hover:text-white/60 transition-colors">
              旧技術 vs 現代技術比較を見る →
            </Link>
            <Link href="/categories/modern-technique" className="text-xs text-white/30 hover:text-white/60 transition-colors">
              現代技術カテゴリを見る →
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}
