import type { Metadata } from "next";
import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { HeroSection, LevelSelector } from "@/components/home/HeroSection";
import { FeaturedArticles } from "@/components/home/FeaturedArticles";
import { TechPrinciples } from "@/components/home/TechPrinciples";
import { ArticlesGrid } from "@/components/home/ArticlesGrid";
import { PlayerAnalysis } from "@/components/home/PlayerAnalysis";
import { SnowConditions } from "@/components/home/SnowConditions";
import { MOCK_ARTICLES_V2 } from "@/lib/constants";
import { SITE_NAME, SITE_DESCRIPTION, SITE_URL, TECH_PRINCIPLES } from "@/lib/constants";
import { buildBreadcrumbSchema, buildItemListSchema, buildSchemaGraph } from "@/lib/schema";
import type { AnySchema } from "@/types/schema";

export const metadata: Metadata = {
  title: `${SITE_NAME} | 2026年基準 スキー・スノーボード技術分析メディア`,
  description: SITE_DESCRIPTION,
  alternates: { canonical: SITE_URL },
};

export default function HomePage() {
  const allArticles = MOCK_ARTICLES_V2;
  const featuredArticles = allArticles.filter((a) => a.featured).slice(0, 4);

  const schemas: AnySchema[] = [
    buildBreadcrumbSchema([{ name: "ホーム", href: "/" }]),
    buildItemListSchema(
      `${SITE_URL}/#featured`,
      "CARVE THEORY 注目の技術記事",
      featuredArticles.map((a) => ({ name: a.title, url: `/articles/${a.slug}`, description: a.excerpt }))
    ),
    buildItemListSchema(
      `${SITE_URL}/#principles`,
      "2026年基準 スキー技術の6原則",
      TECH_PRINCIPLES.map((p) => ({ name: p.title, url: `/#principles`, description: p.description }))
    ),
  ];
  const schemaJson = JSON.stringify(buildSchemaGraph(schemas), null, 0);

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: schemaJson }} />
      <Header />
      <main>
        <HeroSection />
        <LevelSelector />
        <FeaturedArticles articles={featuredArticles} />
        <TechPrinciples />
        <ArticlesGrid articles={allArticles} title="技術記事データベース" />
        <PlayerAnalysis />
        <SnowConditions />
        <CTASection />
      </main>
      <Footer />
    </>
  );
}

function CTASection() {
  return (
    <section className="bg-[#050505] border-t border-white/4 py-24">
      <div className="max-w-8xl mx-auto px-6 md:px-10 text-center">
        <p className="font-mono text-[9px] text-white/15 tracking-[0.28em] uppercase mb-6">Start Here</p>
        <h2 className="font-display font-black text-white leading-tight mb-5"
          style={{ fontSize: "clamp(30px, 5vw, 60px)" }}>
          2026年の滑りを<br />理解する。
        </h2>
        <p className="text-white/30 text-sm md:text-base leading-relaxed mb-10 max-w-lg mx-auto">
          低重心・早期切り替え・圧の流れ——現代技術の核心を理解したとき、
          修正の方向が初めて見えてくる。
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="#start"
            className="inline-flex items-center gap-2 bg-white text-black px-8 py-4 text-sm font-bold tracking-wider hover:bg-white/88 transition-colors">
            あなたのレベルから始める
          </Link>
          <Link href="/categories/modern-technique"
            className="inline-flex items-center gap-2 border border-cyan-500/25 text-cyan-400/65 px-8 py-4 text-sm font-medium tracking-wider hover:border-cyan-400/45 transition-all">
            現代技術の変化を見る
          </Link>
        </div>
      </div>
    </section>
  );
}
