import type { Metadata } from "next";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { PlayerAnalysis } from "@/components/home/PlayerAnalysis";
import { SITE_NAME, SITE_URL, PLAYERS } from "@/lib/constants";
import { buildProfilePageSchema, buildBreadcrumbSchema, buildSchemaGraph } from "@/lib/schema";
import type { AnySchema } from "@/types/schema";

export const metadata: Metadata = {
  title: `選手分析 | ${SITE_NAME}`,
  description:
    "技術選・アルペン・スノーボードの選手を技術的に分析。どこが違うのか、なぜ安定して見えるのか。",
  alternates: { canonical: `${SITE_URL}/players` },
  openGraph: {
    title: `選手分析 | ${SITE_NAME}`,
    description: "技術選・アルペン・スノーボードのトップ選手を技術的に分析。",
    url: `${SITE_URL}/players`,
    type: "website",
    locale: "ja_JP",
  },
};

export default function PlayersPage() {
  /* JSON-LD: ProfilePage + BreadcrumbList */
  const schemas: AnySchema[] = [
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "選手分析", href: "/players" },
    ]),
    buildProfilePageSchema({
      players: PLAYERS.map((p) => ({
        name: p.name,
        discipline: p.discipline,
      })),
    }),
  ];
  const schemaJson = JSON.stringify(
    buildSchemaGraph(schemas),
    null,
    process.env.NODE_ENV === "development" ? 2 : 0
  );

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: schemaJson }}
      />
      <Header />
      <main className="pt-16">
        <div className="bg-[#060606] border-b border-white/5 py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-4">
              Player Analysis
            </p>
            <h1 className="font-display font-black text-white text-4xl md:text-5xl mb-4">
              選手分析
            </h1>
            <p className="text-white/35 text-sm max-w-xl leading-relaxed">
              名前を出して終わりにしない。どこが違うのか、なぜ安定して見えるのか——
              滑りを構成する要素ごとに分解する。
            </p>
          </div>
        </div>
        <PlayerAnalysis />
      </main>
      <Footer />
    </>
  );
}
