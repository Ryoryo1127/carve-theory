import type { Metadata } from "next";
import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { DRILLS_LIBRARY } from "@/lib/drills-data";
import { SITE_NAME, SITE_URL } from "@/lib/constants";
import { ArrowRight, Clock, Mountain } from "lucide-react";
import { buildBreadcrumbSchema, buildItemListSchema, buildSchemaGraph } from "@/lib/schema";
import type { AnySchema } from "@/types/schema";

export const metadata: Metadata = {
  title: `ドリル一覧 | ${SITE_NAME}`,
  description: "技術記事と連動した実践ドリル集。感覚を体に入れるための具体的な練習法。",
};

export default function DrillsIndexPage() {
  const schemas: AnySchema[] = [
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "ドリル一覧", href: "/drills" },
    ]),
    buildItemListSchema(
      `${SITE_URL}/drills#itemlist`,
      "実践ドリル一覧",
      DRILLS_LIBRARY.map((d) => ({
        name: d.title,
        url: `/drills/${d.slug}`,
        description: d.summary,
      })),
      "技術記事と連動した実践ドリル集。感覚を体に入れるための具体的な練習法。"
    ),
  ];
  const schemaJson = JSON.stringify(buildSchemaGraph(schemas), null, 0);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: schemaJson }}
      />
      <Header />
      <main className="pt-16 bg-[#080808] min-h-screen">
        <div className="bg-[#060606] border-b border-white/5 py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-4">
              Drills
            </p>
            <h1 className="font-display font-black text-white text-4xl md:text-5xl mb-4">
              ドリル一覧
            </h1>
            <p className="text-white/40 text-sm max-w-xl leading-relaxed">
              技術記事の理解を、実際の動きに変換するための練習集。感覚は読むだけでは身につかない。
            </p>
          </div>
        </div>

        <section className="py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5">
            {DRILLS_LIBRARY.map((drill) => (
              <Link
                key={drill.slug}
                href={`/drills/${drill.slug}`}
                className="group flex flex-col p-7 bg-[#0a0a0a] hover:bg-[#0e0e0e] transition-colors duration-300"
              >
                <span className="font-mono text-xl font-black text-white/15 mb-4">
                  {String(drill.number).padStart(2, "0")}
                </span>
                <h2 className="font-display font-bold text-white/80 group-hover:text-white text-xl mb-3 transition-colors">
                  {drill.title}
                </h2>
                <p className="text-white/35 text-sm leading-relaxed mb-6">
                  {drill.summary}
                </p>
                <div className="mt-auto flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <Clock size={11} className="text-white/20" />
                      <span className="font-mono-custom text-[9px] text-white/20">{drill.duration}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Mountain size={11} className="text-white/20" />
                      <span className="font-mono-custom text-[9px] text-white/20">{drill.terrain}</span>
                    </div>
                  </div>
                  <ArrowRight
                    size={13}
                    className="text-white/20 group-hover:text-white/50 group-hover:translate-x-0.5 transition-all"
                  />
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
