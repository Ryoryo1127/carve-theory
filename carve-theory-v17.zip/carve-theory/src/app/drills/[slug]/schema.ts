/**
 * /drills/[slug] ページ用スキーマビルダー
 * HowTo + BreadcrumbList
 * ドリルは手順・目標・所要時間を持つため、HowTo schemaが最も適合する。
 */

import {
  buildBreadcrumbSchema,
  buildDrillHowToSchema,
  buildSchemaGraph,
} from "@/lib/schema";
import { SITE_URL } from "@/lib/constants";
import type { DrillDetail } from "@/lib/drills-data";
import type { AnySchema } from "@/types/schema";

export function buildDrillPageSchemas(drill: DrillDetail): string {
  const schemas: AnySchema[] = [];
  const url = `${SITE_URL}/drills/${drill.slug}`;

  schemas.push(
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "ドリル一覧", href: "/drills" },
      { name: drill.title, href: `/drills/${drill.slug}` },
    ])
  );

  schemas.push(
    buildDrillHowToSchema(
      `${url}#howto`,
      [
        {
          title: drill.title,
          goal: drill.goal,
          steps: drill.steps,
          duration: drill.duration,
          terrain: drill.terrain,
        },
      ],
      drill.title
    )
  );

  return JSON.stringify(
    buildSchemaGraph(schemas),
    null,
    process.env.NODE_ENV === "development" ? 2 : 0
  );
}
