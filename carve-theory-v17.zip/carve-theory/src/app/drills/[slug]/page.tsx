import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { DRILLS_LIBRARY, getDrillBySlug } from "@/lib/drills-data";
import { MOCK_ARTICLES } from "@/lib/articles";
import { SITE_NAME, SITE_URL } from "@/lib/constants";
import { ChevronRight, ArrowRight, Clock, Mountain, Target } from "lucide-react";
import { buildDrillPageSchemas } from "./schema";

export async function generateStaticParams() {
  return DRILLS_LIBRARY.map((d) => ({ slug: d.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const drill = getDrillBySlug(params.slug);
  if (!drill) return { title: "Not Found" };
  return {
    title: `${drill.title} | ドリル | ${SITE_NAME}`,
    description: drill.summary,
    alternates: { canonical: `${SITE_URL}/drills/${drill.slug}` },
  };
}

const DIFFICULTY_LABEL = ["", "易", "中", "難"];

export default function DrillPage({ params }: { params: { slug: string } }) {
  const drill = getDrillBySlug(params.slug);
  if (!drill) notFound();

  const relatedArticles = drill.relatedArticleSlugs
    .map((slug) => MOCK_ARTICLES.find((a) => a.slug === slug))
    .filter((a): a is NonNullable<typeof a> => !!a);

  const otherDrills = DRILLS_LIBRARY.filter((d) => d.slug !== drill.slug);

  const schemaJson = buildDrillPageSchemas(drill);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: schemaJson }}
      />
      <Header />
      <main className="pt-16 bg-[#080808] min-h-screen">
        {/* Header */}
        <div className="bg-[#060606] border-b border-white/5 py-16 px-6 md:px-10">
          <div className="max-w-3xl mx-auto">
            <nav className="flex items-center gap-2 mb-8">
              <Link
                href="/"
                className="font-mono-custom text-[9px] text-white/25 hover:text-white/50 tracking-widest uppercase transition-colors"
              >
                Home
              </Link>
              <ChevronRight size={10} className="text-white/15" />
              <span className="font-mono-custom text-[9px] text-white/50 tracking-widest uppercase">
                Drill {String(drill.number).padStart(2, "0")}
              </span>
            </nav>

            <p className="font-mono-custom text-[9px] text-white/25 tracking-[0.2em] uppercase mb-3">
              Drill
            </p>
            <h1 className="font-display font-black text-white text-3xl md:text-4xl mb-4">
              {drill.title}
            </h1>
            <p className="text-white/40 text-sm md:text-base leading-relaxed mb-8">
              {drill.summary}
            </p>

            <div className="flex flex-wrap gap-5">
              <div className="flex items-center gap-2">
                <Clock size={13} className="text-white/25" />
                <span className="font-mono-custom text-[10px] text-white/40 tracking-wider">
                  {drill.duration}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Mountain size={13} className="text-white/25" />
                <span className="font-mono-custom text-[10px] text-white/40 tracking-wider">
                  {drill.terrain}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Target size={13} className="text-white/25" />
                <span className="font-mono-custom text-[10px] text-white/40 tracking-wider">
                  難易度: {DIFFICULTY_LABEL[drill.difficulty]}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="max-w-3xl mx-auto px-6 md:px-10 py-14">
          {/* Goal */}
          <div className="border border-white/6 bg-[#0a0a0a] p-6 mb-10">
            <p className="font-mono-custom text-[9px] text-white/20 tracking-widest uppercase mb-3">
              Goal
            </p>
            <p className="text-white/65 text-sm leading-relaxed">{drill.goal}</p>
          </div>

          {/* Steps */}
          <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-5">
            Steps
          </p>
          <ol className="space-y-3 mb-10">
            {drill.steps.map((step, i) => (
              <li key={i} className="flex items-start gap-4 border border-white/5 bg-white/[0.015] p-4">
                <span className="font-mono text-sm font-bold text-white/20 flex-shrink-0">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="text-white/55 text-sm leading-relaxed">{step}</span>
              </li>
            ))}
          </ol>

          {/* Checkpoint */}
          <div className="border border-cyan-500/15 bg-cyan-950/8 p-6 mb-6">
            <p className="font-mono-custom text-[8px] text-cyan-400/50 tracking-widest uppercase mb-2">
              できた判断基準
            </p>
            <p className="text-white/55 text-sm leading-relaxed">{drill.checkpoint}</p>
          </div>

          {/* Tip */}
          {drill.tip && (
            <div className="border border-white/6 bg-white/[0.02] p-6 mb-12">
              <p className="font-mono-custom text-[8px] text-white/20 tracking-widest uppercase mb-2">
                Tip
              </p>
              <p className="text-white/45 text-sm leading-relaxed italic">{drill.tip}</p>
            </div>
          )}

          {/* Related articles */}
          {relatedArticles.length > 0 && (
            <div className="border-t border-white/5 pt-10 mb-10">
              <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-5">
                関連記事
              </p>
              <div className="space-y-2">
                {relatedArticles.map((article) => (
                  <Link
                    key={article.slug}
                    href={`/articles/${article.slug}`}
                    className="group flex items-center gap-3 text-white/40 hover:text-white/75 text-sm transition-colors"
                  >
                    <ArrowRight size={12} className="flex-shrink-0 group-hover:translate-x-0.5 transition-transform" />
                    {article.title}
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Other drills */}
          <div className="border-t border-white/5 pt-10">
            <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-5">
              他のドリル
            </p>
            <div className="flex flex-wrap gap-2">
              {otherDrills.map((d) => (
                <Link
                  key={d.slug}
                  href={`/drills/${d.slug}`}
                  className="font-mono-custom text-[9px] text-white/30 border border-white/8 px-3 py-1.5 hover:border-white/20 hover:text-white/60 tracking-widest transition-all"
                >
                  {d.title}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
