import type { Metadata } from "next";
import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CATEGORIES, SITE_NAME } from "@/lib/constants";
import { MOCK_ARTICLES } from "@/lib/articles";
import { ArrowRight } from "lucide-react";
import { buildCategoriesIndexSchemas } from "./[slug]/schema";

export const metadata: Metadata = {
  title: `カテゴリ一覧 | ${SITE_NAME}`,
  description:
    "カービング・エッジング・荷重・ポジションなど、技術カテゴリから記事を探す。",
};

export default function CategoriesPage() {
  const schemaJson = buildCategoriesIndexSchemas(CATEGORIES);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: schemaJson }}
      />
      <Header />
      <main className="pt-16">
        <div className="bg-[#060606] border-b border-white/5 py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-4">
              Categories
            </p>
            <h1 className="font-display font-black text-white text-4xl md:text-5xl">
              カテゴリ一覧
            </h1>
          </div>
        </div>

        <section className="bg-[#080808] py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5">
              {CATEGORIES.map((cat, i) => {
                const count = MOCK_ARTICLES.filter(
                  (a) => a.category === cat.slug
                ).length;
                return (
                  <Link
                    key={cat.slug}
                    href={`/categories/${cat.slug}`}
                    className="group flex flex-col p-7 bg-[#0a0a0a] hover:bg-[#0e0e0e] transition-colors duration-300"
                  >
                    <div
                      className="w-6 h-px mb-6 transition-opacity duration-300 opacity-50 group-hover:opacity-100"
                      style={{ background: cat.color }}
                    />
                    <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-2">
                      {cat.labelEn}
                    </p>
                    <h2 className="font-display font-bold text-white/80 group-hover:text-white text-2xl mb-3 transition-colors">
                      {cat.label}
                    </h2>
                    <p className="text-white/35 text-sm leading-relaxed mb-6">
                      {cat.description}
                    </p>
                    <div className="mt-auto flex items-center justify-between">
                      <span className="font-mono-custom text-[9px] text-white/20 tracking-widest">
                        {count} 記事
                      </span>
                      <ArrowRight
                        size={13}
                        className="text-white/20 group-hover:text-white/50 group-hover:translate-x-0.5 transition-all"
                      />
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
