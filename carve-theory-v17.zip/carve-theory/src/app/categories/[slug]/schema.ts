/**
 * カテゴリページ用スキーマビルダー
 * CollectionPage + BreadcrumbList + ItemList
 */

import {
  buildBreadcrumbSchema,
  buildCollectionPageSchema,
  buildItemListSchema,
  buildSchemaGraph,
} from "@/lib/schema";
import { SITE_URL } from "@/lib/constants";
import type { ArticleMeta } from "@/types";
import type { Category } from "@/types";
import type { AnySchema } from "@/types/schema";

export function buildCategoryPageSchemas(
  category: Category,
  articles: ArticleMeta[]
): string {
  const schemas: AnySchema[] = [];

  /* BreadcrumbList */
  schemas.push(
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "カテゴリ一覧", href: "/categories" },
      { name: category.label, href: `/categories/${category.slug}` },
    ])
  );

  /* CollectionPage + ItemList */
  schemas.push(
    buildCollectionPageSchema({
      slug: category.slug,
      name: `${category.label} | CARVE THEORY`,
      description: category.description,
      articles,
    })
  );

  return JSON.stringify(
    buildSchemaGraph(schemas),
    null,
    process.env.NODE_ENV === "development" ? 2 : 0
  );
}

/* カテゴリ一覧ページ用 */
export function buildCategoriesIndexSchemas(
  categories: Category[]
): string {
  const schemas: AnySchema[] = [];

  schemas.push(
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "カテゴリ一覧", href: "/categories" },
    ])
  );

  schemas.push(
    buildItemListSchema(
      `${SITE_URL}/categories#itemlist`,
      "スキー・スノーボード技術カテゴリ一覧",
      categories.map((c) => ({
        name: c.label,
        url: `/categories/${c.slug}`,
        description: c.description,
      })),
      "カービング・エッジング・荷重・ポジションなど、技術カテゴリから記事を探す。"
    )
  );

  return JSON.stringify(
    buildSchemaGraph(schemas),
    null,
    process.env.NODE_ENV === "development" ? 2 : 0
  );
}
