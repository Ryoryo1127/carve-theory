import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { ArticleCard } from "@/components/article/ArticleCard";
import { CATEGORIES, SITE_NAME } from "@/lib/constants";
import { MOCK_ARTICLES } from "@/lib/articles";
import { ChevronRight } from "lucide-react";
import type { CategorySlug } from "@/types";
import { SITE_URL } from "@/lib/constants";
import { buildCategoryPageSchemas } from "./schema";

export async function generateStaticParams() {
  return CATEGORIES.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const cat = CATEGORIES.find((c) => c.slug === params.slug);
  if (!cat) return { title: "Not Found" };
  return {
    title: `${cat.label} | ${SITE_NAME}`,
    description: cat.description,
    alternates: {
      canonical: `${SITE_URL}/categories/${cat.slug}`,
    },
    openGraph: {
      title: `${cat.label} | ${SITE_NAME}`,
      description: cat.description,
      url: `${SITE_URL}/categories/${cat.slug}`,
      type: "website",
      locale: "ja_JP",
    },
  };
}

export default function CategoryPage({
  params,
}: {
  params: { slug: string };
}) {
  const cat = CATEGORIES.find((c) => c.slug === params.slug);
  if (!cat) notFound();

  const articles = MOCK_ARTICLES.filter(
    (a) => a.category === (params.slug as CategorySlug)
  );

  const schemaJson = buildCategoryPageSchemas(cat, articles);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: schemaJson }}
      />
      <Header />
      <main className="pt-16">
        {/* Header */}
        <div className="bg-[#060606] border-b border-white/5 py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 mb-8">
              <Link
                href="/"
                className="font-mono-custom text-[9px] text-white/25 hover:text-white/50 tracking-widest uppercase transition-colors"
              >
                Home
              </Link>
              <ChevronRight size={10} className="text-white/15" />
              <Link
                href="/categories"
                className="font-mono-custom text-[9px] text-white/25 hover:text-white/50 tracking-widest uppercase transition-colors"
              >
                Categories
              </Link>
              <ChevronRight size={10} className="text-white/15" />
              <span className="font-mono-custom text-[9px] text-white/50 tracking-widest uppercase">
                {cat.labelEn}
              </span>
            </nav>

            {/* Category accent */}
            <div
              className="w-8 h-px mb-6"
              style={{ background: cat.color }}
            />

            <p className="font-mono-custom text-[9px] text-white/25 tracking-[0.2em] uppercase mb-3">
              {cat.labelEn}
            </p>
            <h1 className="font-display font-black text-white text-4xl md:text-5xl mb-4">
              {cat.label}
            </h1>
            <p className="text-white/40 text-sm md:text-base max-w-xl leading-relaxed">
              {cat.description}
            </p>

            <div className="mt-6 font-mono-custom text-[9px] text-white/20 tracking-widest">
              {articles.length} 記事
            </div>
          </div>
        </div>

        {/* Articles */}
        <section className="bg-[#080808] py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            {articles.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-px bg-white/5">
                {articles.map((article, i) => (
                  <ArticleCard
                    key={article.slug}
                    article={article}
                    variant="default"
                    index={i}
                  />
                ))}
              </div>
            ) : (
              <div className="py-20 text-center">
                <p className="font-mono-custom text-[10px] text-white/20 tracking-widest mb-3">
                  NO ARTICLES YET
                </p>
                <p className="text-white/30 text-sm">
                  このカテゴリの記事は準備中です。
                </p>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
