import type { Metadata } from "next";
import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { SITE_NAME, SITE_URL } from "@/lib/constants";
import {
  buildAboutPageSchema,
  buildBreadcrumbSchema,
  buildSchemaGraph,
} from "@/lib/schema";
import type { AnySchema } from "@/types/schema";
import {
  Mountain,
  Award,
  BarChart3,
  BookOpenCheck,
  ArrowRight,
  ShieldCheck,
} from "lucide-react";

export const metadata: Metadata = {
  title: `このサイトについて | ${SITE_NAME}`,
  description:
    "CARVE THEORYは、競技スキー経験と指導歴をもとに、感覚論ではなく構造化されたデータでスキー・スノーボード技術を解説するメディアです。運営者「仙人」について。",
  alternates: { canonical: `${SITE_URL}/about` },
  openGraph: {
    title: `このサイトについて | ${SITE_NAME}`,
    description: "競技経験と指導歴に基づく、感覚論からの脱却を目指す技術解説メディア。",
    url: `${SITE_URL}/about`,
    type: "website",
  },
};

/* ─────────────────────────────────────────────────────────────
   経歴・実績データ
───────────────────────────────────────────────────────────── */

const CREDENTIALS = [
  {
    icon: Mountain,
    label: "競技経験",
    value: "競技スキー歴 4年",
    description: "学生時代、競技スキー部に所属。レース・基礎スキー双方の技術を実地で積み上げる。",
  },
  {
    icon: Award,
    label: "指導歴",
    value: "スキー指導員資格保有",
    description: "福島・群馬・山梨の複数リゾートにて指導員として活動。初心者から上級者まで幅広い層を指導。",
  },
  {
    icon: BarChart3,
    label: "アプローチ",
    value: "データに基づく技術解説",
    description: "感覚的な指導表現を、運動力学・選手映像分析・定量データに変換して伝えることを専門とする。",
  },
];

/* ─────────────────────────────────────────────────────────────
   サイトの編集方針
───────────────────────────────────────────────────────────── */

const PRINCIPLES = [
  {
    title: "感覚論からの脱却",
    description:
      "「腰を落とせ」「もっと踏め」という感覚的な指導表現を、身体の何が起きているかという構造に分解して説明する。",
  },
  {
    title: "旧技術を否定しない",
    description:
      "技術は時代によって最適解が更新される。旧来の指導法が誤りだったのではなく、用具・研究・競技分析の蓄積によって理解が進化したという立場で解説する。",
  },
  {
    title: "現場の経験を起点にする",
    description:
      "理論だけで終わらせない。実際の指導現場で「どこで生徒が詰まるか」「何が伝われば動きが変わるか」を起点にコンテンツを作る。",
  },
];

export default function AboutPage() {
  /* JSON-LD: ProfilePage(Person) + BreadcrumbList */
  const schemas: AnySchema[] = [
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "このサイトについて", href: "/about" },
    ]),
    buildAboutPageSchema(),
  ];
  const schemaJson = JSON.stringify(buildSchemaGraph(schemas), null, 0);

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: schemaJson }} />
      <Header />

      <main className="pt-[60px] bg-[#050505] min-h-screen">
        {/* ── ヘッダーセクション ── */}
        <section className="relative border-b border-white/5 overflow-hidden">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage:
                "linear-gradient(rgba(255,255,255,0.02) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.02) 1px,transparent 1px)",
              backgroundSize: "56px 56px",
            }}
          />
          <div
            className="absolute top-0 left-0 w-96 h-96 pointer-events-none"
            style={{
              background:
                "radial-gradient(ellipse at 0% 0%, rgba(255,255,255,0.04) 0%, transparent 70%)",
            }}
          />

          <div className="relative max-w-3xl mx-auto px-6 md:px-10 py-20 md:py-28">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-6 h-px bg-white/20" />
              <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
                About
              </span>
            </div>

            {/* 顔写真の代わりとなるシンボル */}
            <div className="w-16 h-16 border border-white/10 flex items-center justify-center mb-8">
              <svg viewBox="0 0 28 28" fill="none" className="w-7 h-7">
                <path d="M14 2 L26 24 L2 24 Z" stroke="white" strokeOpacity="0.6" strokeWidth="1.5" />
                <path d="M14 8 L21 20 L7 20 Z" fill="white" fillOpacity="0.12" />
              </svg>
            </div>

            <h1
              className="font-display font-black text-white leading-[1.15] mb-3"
              style={{ fontSize: "clamp(28px, 4.5vw, 44px)" }}
            >
              仙人
            </h1>
            <p className="font-mono text-[10px] text-white/30 tracking-widest uppercase mb-8">
              スキー技術解説者 / 元競技スキー選手 / スキー指導員
            </p>

            <p className="text-white/50 text-base md:text-lg leading-[1.9] mb-6">
              CARVE THEORYは、競技スキーと指導現場での経験を、感覚論ではなく
              <strong className="text-white/80 font-medium">構造化された技術論</strong>
              として解説するメディアです。
            </p>
            <p className="text-white/35 text-sm leading-relaxed">
              本サイトでは個人を特定する写真や経歴の公開は行わず、「仙人」という名称で運営しています。
              発信する内容そのものの精度と再現性によって専門性を判断していただきたいと考えています。
            </p>
          </div>
        </section>

        {/* ── 経歴・実績 ── */}
        <section className="border-b border-white/5 py-16 md:py-20">
          <div className="max-w-3xl mx-auto px-6 md:px-10">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-5 h-px bg-white/20" />
              <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
                Background
              </span>
            </div>
            <h2 className="font-display font-bold text-white text-2xl md:text-3xl mb-10">
              経歴・実績
            </h2>

            <div className="space-y-px">
              {CREDENTIALS.map((c) => {
                const Icon = c.icon;
                return (
                  <div
                    key={c.label}
                    className="border border-white/6 bg-[#0a0a0a] p-6 flex gap-5"
                  >
                    <div className="flex-shrink-0 w-10 h-10 border border-white/10 flex items-center justify-center">
                      <Icon size={16} className="text-white/40" />
                    </div>
                    <div>
                      <p className="font-mono text-[8px] text-white/20 tracking-widest uppercase mb-1.5">
                        {c.label}
                      </p>
                      <p className="font-display font-bold text-white/85 text-base mb-2">
                        {c.value}
                      </p>
                      <p className="text-white/40 text-sm leading-relaxed">{c.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* ── なぜ匿名で運営しているか ── */}
        <section className="border-b border-white/5 py-16 md:py-20 bg-[#060606]">
          <div className="max-w-3xl mx-auto px-6 md:px-10">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-5 h-px bg-white/20" />
              <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
                Why Pseudonymous
              </span>
            </div>
            <h2 className="font-display font-bold text-white text-2xl md:text-3xl mb-8">
              名前と顔を出さない理由
            </h2>

            <div className="border border-white/6 bg-[#0a0a0a] p-7 md:p-9">
              <div className="flex items-start gap-4">
                <ShieldCheck size={18} className="text-white/25 flex-shrink-0 mt-0.5" />
                <div className="space-y-4">
                  <p className="text-white/50 text-sm leading-[1.9]">
                    指導者・解説者としての発信は、見た目や知名度ではなく、
                    <strong className="text-white/75 font-medium">内容の正確性と再現性</strong>
                    で評価されるべきだと考えています。
                  </p>
                  <p className="text-white/40 text-sm leading-[1.9]">
                    CARVE THEORYのすべての記事は、構造化されたデータ・定量的な比較・現場での実践に基づいて作成しています。
                    記事の内容、技術解説の精度、提供する教材の質——それらを判断材料にしていただければと思います。
                  </p>
                  <p className="text-white/40 text-sm leading-[1.9]">
                    お問い合わせ・ご相談はテキスト・メール・音声通話で承っています。対面での打ち合わせを前提とはしていません。
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ── 編集方針 ── */}
        <section className="border-b border-white/5 py-16 md:py-20">
          <div className="max-w-3xl mx-auto px-6 md:px-10">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-5 h-px bg-white/20" />
              <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
                Editorial Principles
              </span>
            </div>
            <h2 className="font-display font-bold text-white text-2xl md:text-3xl mb-10">
              編集方針
            </h2>

            <div className="space-y-px">
              {PRINCIPLES.map((p, i) => (
                <div key={p.title} className="border border-white/6 bg-[#0a0a0a] p-6 flex gap-5">
                  <span className="font-mono text-[10px] text-white/15 flex-shrink-0 pt-0.5">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div>
                    <h3 className="font-display font-bold text-white/80 text-base mb-2">
                      {p.title}
                    </h3>
                    <p className="text-white/40 text-sm leading-relaxed">{p.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── CTA ── */}
        <section className="py-16 md:py-20">
          <div className="max-w-3xl mx-auto px-6 md:px-10">
            <div className="border border-white/8 bg-[#0a0a0a] p-8 md:p-10 flex flex-col sm:flex-row sm:items-center gap-6">
              <BookOpenCheck size={28} className="text-white/25 flex-shrink-0" />
              <div className="flex-1">
                <h3 className="font-display font-bold text-white/85 text-lg mb-2">
                  技術記事を読む
                </h3>
                <p className="text-white/40 text-sm leading-relaxed">
                  現代技術論に基づく解説記事を公開しています。まずは記事の内容で判断してください。
                </p>
              </div>
              <Link
                href="/articles"
                className="flex-shrink-0 inline-flex items-center justify-center gap-2 bg-white text-black px-6 py-3 text-sm font-bold tracking-wider hover:bg-white/90 transition-colors whitespace-nowrap"
              >
                記事一覧へ <ArrowRight size={14} />
              </Link>
            </div>

            <div className="mt-4 text-center">
              <Link
                href="/for-schools"
                className="text-xs text-cyan-400/50 hover:text-cyan-400/80 transition-colors"
              >
                スクール・指導者育成団体の方はこちら →
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}
