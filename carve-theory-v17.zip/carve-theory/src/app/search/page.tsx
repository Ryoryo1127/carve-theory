import type { Metadata } from "next";
import { Suspense } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { SearchResults } from "./SearchResults";
import { SITE_NAME } from "@/lib/constants";

export const metadata: Metadata = {
  title: `検索 | ${SITE_NAME}`,
  description: "スキー・スノーボード技術記事を検索する。",
};

export default function SearchPage() {
  return (
    <>
      <Header />
      <main className="pt-16">
        <div className="bg-[#060606] border-b border-white/5 py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-4">
              Search
            </p>
            <h1 className="font-display font-black text-white text-4xl md:text-5xl">
              記事を検索する
            </h1>
          </div>
        </div>
        <Suspense
          fallback={
            <div className="max-w-8xl mx-auto px-6 md:px-10 py-16 text-white/30 text-sm font-mono-custom tracking-widest">
              LOADING...
            </div>
          }
        >
          <SearchResults />
        </Suspense>
      </main>
      <Footer />
    </>
  );
}
