"use client";

import { useSearchParams } from "next/navigation";
import { ArticleCard } from "@/components/article/ArticleCard";
import { MOCK_ARTICLES } from "@/lib/articles";
import { fuzzySearch } from "@/lib/utils";

export function SearchResults() {
  const searchParams = useSearchParams();
  const query = searchParams.get("q") ?? "";

  const results = query ? fuzzySearch(MOCK_ARTICLES, query) : MOCK_ARTICLES;

  return (
    <section className="bg-[#080808] py-12 px-6 md:px-10">
      <div className="max-w-8xl mx-auto">
        {query && (
          <p className="font-mono-custom text-[10px] text-white/25 tracking-widest mb-8">
            「{query}」の検索結果：{results.length} 件
          </p>
        )}

        {results.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-px bg-white/5">
            {results.map((article, i) => (
              <ArticleCard
                key={article.slug}
                article={article}
                variant="default"
                index={i}
              />
            ))}
          </div>
        ) : (
          <div className="py-20 text-center">
            <p className="font-mono-custom text-[10px] text-white/20 tracking-widest mb-3">
              NO RESULTS
            </p>
            <p className="text-white/30 text-sm">
              「{query}」に合う記事が見つかりませんでした。
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
