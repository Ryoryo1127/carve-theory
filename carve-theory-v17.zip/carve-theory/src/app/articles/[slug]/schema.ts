/**
 * 記事詳細ページで使うスキーマデータを一元管理するファイル。
 * page.tsx から import して JsonLd に渡す。
 *
 * 実際の運用では MDX frontmatter や Supabase からデータを取得するが、
 * 現時点ではデモデータとして定義する。
 */

import { SITE_URL } from "@/lib/constants";
import {
  buildArticleSchema,
  buildBreadcrumbSchema,
  buildVideoSchema,
  buildFailureFAQSchema,
  buildDrillHowToSchema,
  buildSchemaGraph,
  levelToEducational,
  minutesToDuration,
} from "@/lib/schema";
import type { ArticleMeta } from "@/types";
import type { AnySchema } from "@/types/schema";
import type { FailurePatternInput, DrillInput } from "@/lib/schema";

/* ─────────────────────────────────────────────────────────────
   記事ごとの追加データ（失敗パターン・ドリル・動画）
   実運用では MDX frontmatter か CMS から取得する
───────────────────────────────────────────────────────────── */

interface ArticleExtraData {
  /** 動画が存在する場合 */
  videos?: {
    videoId: string;
    title: string;
    description: string;
    uploadDate: string;
    durationSeconds?: number;
    checkpoints?: { name: string; timeString: string }[];
    teaches?: string[];
  }[];
  /** 失敗パターン（FAQ自動生成用） */
  failurePatterns?: FailurePatternInput[];
  /** ドリル（HowTo自動生成用） */
  drills?: DrillInput[];
  /** 記事本文の概算文字数 */
  wordCount?: number;
}

const ARTICLE_EXTRA: Record<string, ArticleExtraData> = {
  "carving-turn-complete": {
    wordCount: 4800,
    videos: [
      {
        videoId: "dQw4w9WgXcQ", // 実際の動画IDに差し替える
        title: "カービングターン技術解説：フォールライン前後の荷重変化を見る",
        description:
          "技術選選手のスロー映像。ターン前半でのエッジングの始まりと、フォールライン付近での荷重ピークに注目する。",
        uploadDate: "2025-01-10",
        durationSeconds: 330, // 5分30秒
        checkpoints: [
          { name: "ターン開始前の重心の沈み込み（落とし込み）", timeString: "0:32" },
          { name: "フォールライン付近のエッジ角最大値を確認", timeString: "1:15" },
          { name: "山回り後半の荷重維持。テールが流れていないことを確認", timeString: "2:04" },
          { name: "切り替えのフラット時間。上位選手はここが極端に短い", timeString: "3:20" },
        ],
        teaches: ["カービングターン", "エッジング", "荷重移動", "切り替え"],
      },
    ],
    failurePatterns: [
      {
        name: "内倒",
        cause:
          "体を内側に傾けることをカービングだと誤解している。重心が内足上に乗ってしまい、外スキーへの荷重が抜ける。",
        fix: "外足の拇指球（親指の付け根）に体重を感じることに集中する。片足スキードリルで外足荷重の感覚を養う。",
      },
      {
        name: "テール流し",
        cause:
          "ターン後半に次のターンへ急ぐため荷重を抜くのが早すぎる。板を踏みきれていない。",
        fix: "「ターンを最後まで終わらせる」意識を持つ。超スローターンドリルで荷重を最後まで保つ感覚を身につける。",
      },
      {
        name: "ローテーション",
        cause:
          "肩や上半身をターン方向に向けることで板を回そうとする。体でターンを作ろうとする意識から来る。",
        fix: "上半身は谷方向を向いたまま維持する。ストックを水平に持って肩の回転を防ぐドリルが有効。",
      },
      {
        name: "後傾",
        cause:
          "スピードへの恐怖で無意識に体が後ろに引ける。またはブーツのフレックスが硬すぎる場合も原因になる。",
        fix: "斜度を落として練習する。まず恐怖を取り除くことが先。その後、骨盤を前に出す意識を持つ。",
      },
    ],
    drills: [
      {
        title: "片足スキー",
        goal: "外足荷重の感覚を体に叩き込む。内足に頼れない状況を作る。",
        steps: [
          "内スキーを雪面からわずかに浮かせた状態で立つ",
          "外スキー一本でまっすぐ滑り出す",
          "外足一本で大きなターンを描く",
          "左右交互に10本ずつ行う",
        ],
        duration: "5〜10分",
        terrain: "緩斜面",
      },
      {
        title: "ストックなし滑走",
        goal: "上半身の余計な動きを排除し、バランスを体幹と足裏に移す。",
        steps: [
          "ストックを持たずに手を体の前に軽く出す",
          "腕をバランス補助に使わずに滑る",
          "上半身が静かに保てているか意識しながらターンする",
        ],
        duration: "10〜15分",
        terrain: "緩〜中斜面",
      },
      {
        title: "超スローターン",
        goal: "スピードへの恐怖をゼロにして、荷重とエッジングの感覚を丁寧に確認する。",
        steps: [
          "止まるギリギリのスピードで滑り出す",
          "できる限り大きな弧を描いてターンする",
          "各フェーズでの荷重の変化を意識しながら滑る",
          "シュプールを振り返って確認する",
        ],
        duration: "15〜20分",
        terrain: "緩斜面（広いゲレンデ）",
      },
    ],
  },
  "posterior-lean-fix": {
    wordCount: 3200,
    failurePatterns: [
      {
        name: "後傾（ブーツ起因）",
        cause: "フレックスが硬すぎるブーツを使っているため、前傾姿勢が作れない。",
        fix: "フレックス値を下げる、またはインナーカスタムで対応する。",
      },
      {
        name: "後傾（恐怖起因）",
        cause: "スピードへの恐怖から無意識に体が後方に引ける。",
        fix: "緩斜面で練習量を積み、スピード慣れする。",
      },
    ],
    drills: [
      {
        title: "前傾姿勢確認ドリル",
        goal: "正しい前傾ポジションを体に覚えさせる。",
        steps: [
          "平地でブーツのタングに脛を軽く当てる",
          "その姿勢のまま膝・股関節を曲げる",
          "この姿勢で緩斜面を直滑降する",
        ],
        duration: "5分",
        terrain: "緩斜面",
      },
    ],
  },
  "tech-comp-scoring": {
    wordCount: 5200,
    failurePatterns: [
      {
        name: "ローテーション（採点上の減点）",
        cause: "上半身がターン方向に先行する。分離ができていない証拠。",
        fix: "上半身を谷方向に向けたまま固定する意識を持つ。",
      },
      {
        name: "山回りの荷重抜け",
        cause: "ターン後半で外スキーへの荷重が途切れる。弧の仕上がりが悪くなる。",
        fix: "テールが雪面を蹴り出す感覚まで外足を踏み続ける。",
      },
    ],
  },
};

/* ─────────────────────────────────────────────────────────────
   メイン：記事ページ用スキーマグラフを生成する
───────────────────────────────────────────────────────────── */

export function buildArticlePageSchemas(article: ArticleMeta): string {
  const pageUrl = `${SITE_URL}/articles/${article.slug}`;
  const extra = ARTICLE_EXTRA[article.slug] ?? {};
  const schemas: AnySchema[] = [];

  /* 1. BreadcrumbList */
  schemas.push(
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "記事一覧", href: "/articles" },
      {
        name: article.category
          .replace(/-/g, " ")
          .replace(/\b\w/g, (c) => c.toUpperCase()),
        href: `/categories/${article.category}`,
      },
      { name: article.title, href: `/articles/${article.slug}` },
    ])
  );

  /* 2. Article (TechArticle) */
  schemas.push(
    buildArticleSchema({
      article,
      wordCount: extra.wordCount,
      articleType: "TechArticle",
      mentions:
        article.category === "technical-race" ||
        article.category === "alpine-analysis"
          ? [
              { "@type": "Person", name: "皆川賢太郎" },
              { "@type": "Person", name: "吉岡大輔" },
            ]
          : undefined,
    })
  );

  /* 3. VideoObject（動画がある場合） */
  if (extra.videos && extra.videos.length > 0) {
    extra.videos.forEach((v) => {
      schemas.push(
        buildVideoSchema({
          videoId: v.videoId,
          title: v.title,
          description: v.description,
          uploadDate: v.uploadDate,
          duration: v.durationSeconds
            ? (() => {
                const sec = v.durationSeconds ?? 0;
                const m = Math.floor(sec / 60);
                const s = sec % 60;
                return `PT${m}M${s}S`;
              })()
            : undefined,
          checkpoints: v.checkpoints,
          teaches: v.teaches,
          educationalLevel: levelToEducational(article.level),
          category: article.category,
          articleId: `${pageUrl}#article`,
        })
      );
    });
  }

  /* 4. FAQPage（失敗パターンがある場合） */
  if (extra.failurePatterns && extra.failurePatterns.length > 0) {
    schemas.push(
      buildFailureFAQSchema(pageUrl, extra.failurePatterns, article.title)
    );
  }

  /* 5. HowTo（ドリルがある場合） */
  if (extra.drills && extra.drills.length > 0) {
    schemas.push(
      buildDrillHowToSchema(
        pageUrl,
        extra.drills,
        article.title,
        article.category,
        levelToEducational(article.level)
      )
    );
  }

  /* Graph にまとめてシリアライズ */
  return JSON.stringify(
    buildSchemaGraph(schemas),
    null,
    process.env.NODE_ENV === "development" ? 2 : 0
  );
}
