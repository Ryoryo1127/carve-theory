import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { ArticleBody } from "@/components/article/ArticleBody";
import { ArticleCard } from "@/components/article/ArticleCard";
import { ArticleSidebar } from "@/components/article/ArticleSidebar";
import { MobileTOC } from "@/components/article/MobileTOC";
import { ReadingProgress } from "@/components/article/ReadingProgress";
import { VideoEmbed } from "@/components/article/VideoEmbed";
import { PressureChart, EdgeAngleChart } from "@/components/article/PressureChart";
import { TechCompare } from "@/components/article/TechCompare";
import { FailurePatterns } from "@/components/article/FailurePatterns";
import { DrillCards } from "@/components/article/DrillCards";
import { TrackDiagram, BodyPositionTable } from "@/components/article/TrackDiagram";
import { KeyPointsCard } from "@/components/article/KeyPoints";
import { LevelBadge, RouteBadge, Badge } from "@/components/ui/Badge";
import { MOCK_ARTICLES, getRelatedArticles } from "@/lib/articles";
import { getCategoryBySlug, formatDate, extractHeadings } from "@/lib/utils";
import { SITE_NAME, SITE_URL } from "@/lib/constants";
import { Clock, Calendar, ChevronRight, ArrowLeft } from "lucide-react";
import type {
  CompareRow,
  FailurePattern,
  Drill,
} from "@/types/article-components";
import { JsonLd } from "@/components/seo/JsonLd";
import { buildArticlePageSchemas } from "./schema";
import { TechEraAnalysis, TechEraInline } from "@/components/article/TechEraAnalysis";
import { SchoolCTA } from "@/components/article/SchoolCTA";
import { ARTICLE_CONTENT } from "@/lib/article-content";
import type { ComparisonTopic } from "@/types";

/* ────────────────────────────────────────────────────────────
   DEMO DATA — カービングターン記事用コンテンツ
──────────────────────────────────────────────────────────── */

const DEMO_CONTENT = `
## 技術の概要

カービングターンを一言で説明しろと言われたら、こう答える。

「板のサイドカーブに、体重を乗せ続けること」だ。

ただし、この一言で理解できる人は最初からできている人だ。ほとんどの人は「サイドカーブに乗る」という感覚が、どんな身体状態なのかを知らない。だからいくら練習しても、ズレたまま速くなるだけで終わる。

現場で見ていると、カービングが「できている」と思っている人の8割は、正確にはできていない。ターンはしている。でも板のトップからテールまで均等に雪面を切れているかというと、そうじゃない。後半にテールが逃げている。前半にトップが引っかかって詰まっている。

では本物のカービングとは何か。雪面に刻まれたシュプールを見ればわかる。

---

## なぜその動きになるか

カービングターンの原理は、板のサイドカーブにある。スキー板の形状を上から見ると、中央部分（ウエスト）が細く、先端（トップ）とテールが広い。この形状のおかげで、板を傾けると自然に弧を描く性質がある。

重要なのは「傾けると弧を描く」という順番だ。意図的に曲がろうとしない。板を傾けることで、板が勝手に曲がる。これがカービングの本質だ。

この原理が理解できると、「曲げよう」「回そう」という意識を手放せる。それだけで、多くの余計な力みが消える。

---

## 身体動作の分解

### ターン導入（フォールライン手前）

ここが一番誤解されているフェーズだ。

「体を内側に倒してターンを始める」と思っている人が非常に多い。違う。体を倒すのは結果であって、原因じゃない。

正確にはこうだ。まず重心が谷側に「落ちる」。重力に引かれるように、わずかに沈み込む。その重心の移動を受けて、体が内側に傾く。板はその傾きに反応してエッジが噛み始める。この順番が逆になると、上半身だけ倒れて板が追いついてこない「内倒」になる。

### フォールライン通過（ターンのピーク）

ここが荷重のピークだ。外力（遠心力）と重力が最大化する。体感としては「板が地面に吸い込まれる感じ」「外スキーがずっしり重くなる感じ」になる。上手くはまったときは、板から突き上げてくるような反発が感じられる。これが「板が返ってくる」という感覚だ。

### ターン仕上げ（フォールライン通過後）

山回り、つまりターン後半だ。ここで荷重を抜く人が本当に多い。最後まで外足を踏み続けることが、ターン後半の安定につながる。

---

## 上半身と下半身の役割

上は静かに、下は動く。

これがカービングの分離動作の本質だ。上半身は谷方向を向いたまま維持し、下半身だけがターンについていく。この分離ができている選手は、高速でも「楽そうに見える」。

上半身が先行してターン方向を向く「ローテーション」が起きると、エッジが外れる。だから上半身は意図的に「遅らせる」くらいの意識でちょうどいい。
`;

const COMPARE_ROWS: CompareRow[] = [
  {
    aspect: "ターンの始め方",
    beginner: "体を内側に倒してターンを「作る」。意図的に曲がろうとする。",
    advanced: "重心を谷側に落とし、板が勝手に曲がるのを感じる。導くだけ。",
    impact: "high",
  },
  {
    aspect: "エッジング",
    beginner: "足首や膝でエッジを「立てよう」とする。力が入る。",
    advanced: "体の傾きの結果としてエッジが立つ。力を入れない。",
    impact: "high",
  },
  {
    aspect: "フォールライン付近",
    beginner: "怖くて板を止めようとする。荷重が抜ける。",
    advanced: "外スキーに乗り込み、板が返ってくるのを待つ。",
    impact: "high",
  },
  {
    aspect: "ターン後半の意識",
    beginner: "「ターンが終わった」と思い荷重を抜く。テールが流れる。",
    advanced: "最後まで外足を踏み続ける。弧を描ききる意識。",
    impact: "medium",
  },
  {
    aspect: "上半身の使い方",
    beginner: "肩でターン方向を向く（ローテーション）。板が追いつかない。",
    advanced: "上半身は静か。下半身だけがターンに追従する。",
    impact: "medium",
  },
  {
    aspect: "視線",
    beginner: "板の先や直前を見ている。反応が遅れる。",
    advanced: "2〜3ターン先の斜面を見ている。先読みができる。",
    impact: "low",
  },
];

const FAILURE_PATTERNS: FailurePattern[] = [
  {
    name: "内倒",
    nameEn: "INSIDE LEAN",
    severity: "critical",
    cause: "体を内側に傾けることをカービングだと誤解している。重心が内足上に乗ってしまう。",
    symptom: "外スキーへの荷重が抜け、弧が大きくなる。スピードが出ると止まれなくなる。",
    fix: "外足の拇指球（親指の付け根）に体重を感じることに集中する。内倒しているとここの感覚がない。",
    drill: "片足スキー（外足のみ）で緩斜面を滑る。外足に乗らないと進めないため、否応なく正しい荷重が身につく。",
  },
  {
    name: "テール流し",
    nameEn: "TAIL SKID",
    severity: "common",
    cause: "ターン後半に次のターンへ急ぐため荷重を抜くのが早すぎる。板を踏みきれていない。",
    symptom: "シュプールがターン後半だけ二本線になる。山回りが安定しない。",
    fix: "「ターンを最後まで終わらせる」意識を持つ。弧を途中で切り捨てない。",
    drill: "超スローターン。止まるギリギリのスピードで大きな弧を描く。荷重を最後まで保つ感覚を身につける。",
  },
  {
    name: "ローテーション",
    nameEn: "ROTATION",
    severity: "common",
    cause: "肩や上半身をターン方向に向けることで板を回そうとする。体でターンを作ろうとする意識から来る。",
    symptom: "上半身がターン方向に先行する。エッジが外れてズレが起きる。",
    fix: "ストックを水平に持って肩の回転を防ぐ。上半身が谷方向を向いたまま維持できているか確認する。",
  },
  {
    name: "後傾",
    nameEn: "BACK SEAT",
    severity: "critical",
    cause: "スピードへの恐怖で無意識に体が後ろに引ける。またはブーツのフレックスが硬すぎる場合も。",
    symptom: "板が先走り、体が置いていかれる感覚。コントロールが失われる。",
    fix: "斜度を落として練習する。まず恐怖を取り除くことが先。その後、骨盤を前に出す意識を持つ。",
    drill: "ストックなし滑走。手を体の前に出した姿勢をキープして滑ると、自然に重心が前に来る。",
  },
];

const DRILLS: Drill[] = [
  {
    number: 1,
    title: "片足スキー",
    duration: "5〜10分",
    terrain: "緩斜面",
    difficulty: 1,
    goal: "外足荷重の感覚を体に叩き込む。内足に頼れない状況を作る。",
    steps: [
      "内スキーを雪面からわずかに浮かせた状態で立つ",
      "外スキー一本でまっすぐ滑り出す",
      "外足一本で大きなターンを描く",
      "左右交互に10本ずつ行う",
    ],
    checkpoint: "外スキー一本で安定したターンができ、内足を浮かせたままシュプールが一本線になっている。",
    tip: "転ぶことを恐れない。転び方で何が間違いかわかる。転んで学ぶのがこのドリルの本質だ。",
  },
  {
    number: 2,
    title: "ストックなし滑走",
    duration: "10〜15分",
    terrain: "緩〜中斜面",
    difficulty: 1,
    goal: "上半身の余計な動きを排除し、バランスを体幹と足裏に移す。",
    steps: [
      "ストックを持たずに手を体の前に軽く出す",
      "腕をバランス補助に使わずに滑る",
      "上半身が静かに保てているか意識しながらターンする",
    ],
    checkpoint: "腕を使わなくても安定したターンができる。上半身がターン方向に流れていない。",
    tip: "最初は怖い。でも「ストックがないだけで滑れない」なら、今までストックに頼りすぎていた証拠だ。",
  },
  {
    number: 3,
    title: "超スローターン",
    duration: "15〜20分",
    terrain: "緩斜面（広いゲレンデ）",
    difficulty: 1,
    goal: "スピードへの恐怖をゼロにして、荷重とエッジングの感覚を丁寧に確認する。",
    steps: [
      "止まるギリギリのスピードで滑り出す",
      "できる限り大きな弧を描いてターンする",
      "各フェーズでの荷重の変化を意識しながら滑る",
      "シュプールを振り返って確認する",
    ],
    checkpoint: "シュプールが一本の細い線になっている。ターン後半まで荷重が途切れていない。",
    tip: "このドリルを10本やった後に普通のペースで滑ると、板の感覚が明らかに変わる。それが正解への道だ。",
  },
];

/* ────────────────────────────────────────────────────────────
   記事ごとの時代比較トピックマッピング
   各記事のテーマに最も合致する ComparisonTopic を割り当てる
──────────────────────────────────────────────────────────── */

const ARTICLE_ERA_TOPIC: Record<string, ComparisonTopic> = {
  "modern-technique-overview": "transition",
  "short-turn-modern": "short-turn",
  "mogul-terrain-processing": "mogul",
  "ski-biomechanics-intro": "angulation",
  "terrain-adaptation-guide": "position",
  "tech-comp-scoring": "upper-body",
  "gs-turn-analysis": "edging",
  "long-turn-modern": "com-path",
  "transition-deep-dive": "transition",
  "pressure-control-practice": "pressure",
  "edging-angle-strategy": "edging",
  "low-com-position-building": "position",
  "off-piste-intro": "ski-run",
  "snowboard-shared-principles": "angulation",
  "carving-basics-for-beginners": "edging",
  "short-turn-rhythm-drills": "short-turn",
  "pressure-sensing-fundamentals": "pressure",
  "position-common-mistakes": "position",
  "mogul-competition-format": "mogul",
  "freeride-terrain-reading": "ski-run",
  "snowboard-carving-technique": "angulation",
};

/* ────────────────────────────────────────────────────────────
   Page
──────────────────────────────────────────────────────────── */

export async function generateStaticParams() {
  return MOCK_ARTICLES.map((a) => ({ slug: a.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const article = MOCK_ARTICLES.find((a) => a.slug === params.slug);
  if (!article) return { title: "Not Found" };
  return {
    title: `${article.title} | ${SITE_NAME}`,
    description: article.excerpt,
    keywords: article.tags,
    authors: [{ name: "仙人", url: `${SITE_URL}/about` }],
    alternates: {
      canonical: `${SITE_URL}/articles/${article.slug}`,
    },
    openGraph: {
      title: article.title,
      description: article.excerpt,
      url: `${SITE_URL}/articles/${article.slug}`,
      type: "article",
      publishedTime: article.publishedAt,
      modifiedTime: article.updatedAt ?? article.publishedAt,
      tags: article.tags,
      locale: "ja_JP",
      siteName: SITE_NAME,
    },
    twitter: {
      card: "summary_large_image",
      title: article.title,
      description: article.excerpt,
    },
  };
}

export default function ArticlePage({ params }: { params: { slug: string } }) {
  const article = MOCK_ARTICLES.find((a) => a.slug === params.slug);
  if (!article) notFound();

  const category = getCategoryBySlug(article.category);
  const isCarving = article.slug === "carving-turn-complete";

  /* 実コンテンツがあれば使用、なければカービング記事のデモコンテンツにフォールバック */
  const bodyContent = isCarving
    ? DEMO_CONTENT
    : ARTICLE_CONTENT[article.slug] ?? DEMO_CONTENT;

  const headings = extractHeadings(bodyContent);
  const related = getRelatedArticles(article.slug, [], 3).filter(
    (a) => a.slug !== article.slug
  );
  const eraTopic = ARTICLE_ERA_TOPIC[article.slug];

  /* JSON-LD: Article + BreadcrumbList + VideoObject + FAQPage + HowTo */
  const schemaJson = buildArticlePageSchemas(article);

  return (
    <>
      {/* ── JSON-LD structured data ── */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: schemaJson }}
      />
      <Header />
      <ReadingProgress />
      <MobileTOC headings={headings} />

      <main className="pt-16">
        {/* ── Article header ── */}
        <header className="bg-[#060606] border-b border-white/5 py-12 md:py-16">
          <div className="max-w-8xl mx-auto px-6 md:px-10">
            {/* Breadcrumb */}
            <nav aria-label="パンくず" className="flex items-center gap-2 mb-8 flex-wrap">
              <Link href="/" className="font-mono-custom text-[9px] text-white/25 hover:text-white/50 tracking-widest uppercase transition-colors">
                Home
              </Link>
              <ChevronRight size={10} className="text-white/15" />
              <Link href="/articles" className="font-mono-custom text-[9px] text-white/25 hover:text-white/50 tracking-widest uppercase transition-colors">
                Articles
              </Link>
              {category && (
                <>
                  <ChevronRight size={10} className="text-white/15" />
                  <Link href={`/categories/${category.slug}`} className="font-mono-custom text-[9px] text-white/25 hover:text-white/50 tracking-widest uppercase transition-colors">
                    {category.labelEn}
                  </Link>
                </>
              )}
            </nav>

            <div className="max-w-4xl">
              <div className="flex flex-wrap items-center gap-2 mb-6">
                <LevelBadge level={article.level} />
                <RouteBadge route={article.route} />
                {category && <Badge variant="outline">{category.labelEn}</Badge>}
              </div>

              <h1
                className="font-display font-black text-white leading-tight mb-4"
                style={{ fontSize: "clamp(28px, 5vw, 60px)" }}
              >
                {article.title}
              </h1>
              <p className="text-white/40 text-lg md:text-xl mb-5">{article.subtitle}</p>
              <p className="text-white/35 text-sm md:text-base leading-relaxed max-w-2xl mb-8">
                {article.excerpt}
              </p>

              <div className="flex flex-wrap items-center gap-5 text-white/25">
                <div className="flex items-center gap-1.5">
                  <Clock size={12} />
                  <span className="font-mono-custom text-[10px] tracking-wider">読了 {article.readTime}分</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar size={12} />
                  <span className="font-mono-custom text-[10px] tracking-wider">{formatDate(article.publishedAt)}</span>
                </div>
                {article.updatedAt && (
                  <span className="font-mono-custom text-[10px] tracking-wider">更新: {formatDate(article.updatedAt)}</span>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* ── Body + Sidebar ── */}
        <div className="max-w-8xl mx-auto px-6 md:px-10 py-12 md:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_260px] gap-12 xl:gap-20">

            {/* ── Main content ── */}
            <article>
              {/* Key points summary at top */}
              <KeyPointsCard
                title="この記事を読む前に知っておくこと"
                variant="principle"
                points={
                  isCarving
                    ? [
                        { text: "カービングとは「板を曲げる」のではなく「板が曲がるのに乗る」技術だ。", emphasis: true },
                        { text: "シュプールで自分の滑りを判断できるようになることが最初のゴール。" },
                        { text: "重心の移動と荷重のタイミングを理解すると、力みが消える。" },
                        { text: "初心者の失敗の多くは「早く次のターンへ行こうとすること」から起きる。" },
                      ]
                    : [
                        { text: article.excerpt, emphasis: true },
                        { text: "旧技術と現代技術、どちらが正しいかではなく、なぜ変化したかを理解する。" },
                        { text: `カテゴリ：${category?.label ?? article.category} / レベル：${article.level}` },
                      ]
                }
              />

              {/* Article body text — slugごとの実コンテンツ */}
              <ArticleBody content={bodyContent} />

              {isCarving ? (
                <>
                  {/* Schprur comparison diagram */}
                  <TrackDiagram />

                  {/* Pressure chart */}
                  <PressureChart />

                  {/* Edge angle chart */}
                  <EdgeAngleChart />

                  {/* Tech compare table */}
                  <TechCompare rows={COMPARE_ROWS} />

                  {/* Body position check */}
                  <BodyPositionTable />

                  {/* Failure patterns */}
                  <FailurePatterns patterns={FAILURE_PATTERNS} />

                  {/* B2B CTA — 技術解説が一区切りついた中盤に配置 */}
                  <SchoolCTA />

                  {/* Drills */}
                  <DrillCards drills={DRILLS} />

                  {/* Era comparison */}
                  <TechEraInline topic="pressure" />
                </>
              ) : (
                <>
                  {/* B2B CTA — 本文の後、時代比較の前 */}
                  <SchoolCTA />

                  {/* この記事のテーマに対応した時代比較を埋め込む */}
                  {eraTopic && <TechEraInline topic={eraTopic} />}
                </>
              )}

              {/* Video embed (carving article only for demo) */}
              {isCarving && (
                <VideoEmbed
                  videoId="dQw4w9WgXcQ"
                  title="カービングターン技術解説：フォールライン前後の荷重変化を見る"
                  description="技術選選手のスロー映像。ターン前半でのエッジングの始まりと、フォールライン付近での荷重ピークに注目する。"
                  durationSeconds={240}
                  checkpoints={[
                    {
                      time: "0:32",
                      label: "落とし込み：重心が谷側に沈む",
                      analysis: "ターン開始前に重心がわずかに沈み込む「落とし込み」の瞬間。体を倒すのではなく、重心が先に落ちている。一般スキーヤーと最も差が出るフェーズ。",
                      category: "position",
                      focus: "腰・重心の縦方向移動",
                    },
                    {
                      time: "1:15",
                      label: "エッジ角ピーク：フォールライン通過",
                      analysis: "フォールライン付近でエッジ角が最大になる局面。上級者はここで外スキーから突き上げてくる反力を受けている。板が「返ってくる」感覚がある瞬間。",
                      category: "edge",
                      focus: "エッジ角・外スキー反力",
                    },
                    {
                      time: "2:04",
                      label: "山回り荷重維持：テールを踏み続ける",
                      analysis: "ターン後半でも外スキーへの荷重が途切れない。一般スキーヤーが荷重を抜くこの局面で、上位選手は板のテールが雪面を蹴り出すまで踏み続けている。",
                      category: "pressure",
                      focus: "外足荷重の持続",
                    },
                    {
                      time: "3:20",
                      label: "切り替え：フラット時間が極端に短い",
                      analysis: "エッジがフラットになる切り替えの瞬間。上位選手はこの時間が一般スキーヤーの半分以下。次のエッジングへの移行が異常に速い。ここが連続ターンのリズムを決める。",
                      category: "transition",
                      focus: "切り替えのフラット時間",
                    },
                  ]}
                />
              )}

              {/* Final summary */}
              <KeyPointsCard
                title="まとめ：今日から意識すること"
                variant="summary"
                points={
                  isCarving
                    ? [
                        { text: "外足の拇指球に体重を感じているか、常に確認する。", emphasis: true },
                        { text: "シュプールを滑走後に振り返って確認する習慣をつける。" },
                        { text: "テールが流れたら「急ぎすぎ」が原因。最後まで踏み続ける。" },
                        { text: "まずドリル①（片足スキー）を10本。感覚が変わるまでやる。", emphasis: true },
                      ]
                    : [
                        { text: "技術は時代によって最適解が更新される。旧技術が誤っていたわけではない。", emphasis: true },
                        { text: "感覚的な指導表現を、身体の構造に分解して理解する習慣をつける。" },
                        { text: "なぜ変化したのかを理解すると、練習の意味が変わる。" },
                      ]
                }
              />

              {/* Tags */}
              <div className="mt-14 pt-8 border-t border-white/5">
                <SchoolCTA variant="compact" className="mb-10" />

                <p className="font-mono-custom text-[9px] text-white/20 tracking-widest uppercase mb-4">Tags</p>
                <div className="flex flex-wrap gap-2">
                  {article.tags.map((tag) => (
                    <Link
                      key={tag}
                      href={`/tags/${encodeURIComponent(tag)}`}
                      className="font-mono-custom text-[9px] text-white/30 border border-white/8 px-3 py-1 hover:border-white/20 hover:text-white/60 tracking-widest transition-all"
                    >
                      #{tag}
                    </Link>
                  ))}
                </div>
              </div>

              <div className="mt-8">
                <Link href="/articles" className="inline-flex items-center gap-2 text-white/30 hover:text-white/60 text-xs transition-colors group">
                  <ArrowLeft size={12} className="group-hover:-translate-x-0.5 transition-transform" />
                  記事一覧に戻る
                </Link>
              </div>
            </article>

            {/* ── Sidebar ── */}
            <div className="hidden lg:block">
              <ArticleSidebar
                headings={headings}
                article={article}
                relatedDrills={[
                  { title: "外足荷重ドリル集", href: "/drills/outer-foot" },
                  { title: "シュプール診断の方法", href: "/drills/schprur-check" },
                  { title: "エッジングドリル基礎", href: "/drills/edging-basics" },
                ]}
              />
            </div>
          </div>
        </div>

        {/* ── Related articles ── */}
        {related.length > 0 && (
          <section className="border-t border-white/5 bg-[#060606] py-16">
            <div className="max-w-8xl mx-auto px-6 md:px-10">
              <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-3">
                Related Articles
              </p>
              <h2 className="font-display font-bold text-white text-2xl md:text-3xl mb-8">
                関連記事
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5">
                {related.map((a, i) => (
                  <ArticleCard key={a.slug} article={a} variant="default" index={i} />
                ))}
              </div>
            </div>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
