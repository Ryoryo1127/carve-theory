import type { Metadata } from "next";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { ArticlesGrid } from "@/components/home/ArticlesGrid";
import { MOCK_ARTICLES } from "@/lib/articles";
import { SITE_NAME } from "@/lib/constants";

export const metadata: Metadata = {
  title: `記事一覧 | ${SITE_NAME}`,
  description:
    "カービング・エッジング・荷重・切り替えなど、スキー・スノーボードの技術を体系的に解説する記事データベース。",
};

export default function ArticlesPage() {
  const articles = MOCK_ARTICLES;

  return (
    <>
      <Header />
      <main className="pt-16">
        {/* Page header */}
        <div className="bg-[#060606] border-b border-white/5 py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <p className="font-mono-custom text-[10px] text-white/25 tracking-[0.2em] uppercase mb-4">
              All Articles
            </p>
            <h1 className="font-display font-black text-white text-4xl md:text-5xl mb-4">
              技術記事データベース
            </h1>
            <p className="text-white/35 text-sm max-w-xl leading-relaxed">
              カービング・エッジング・荷重・切り替えなど、あらゆる技術要素を体系的に解説。
              キーワードやカテゴリで、今日の課題に合った記事を見つける。
            </p>
          </div>
        </div>

        <ArticlesGrid articles={articles} showFilters title="" />
      </main>
      <Footer />
    </>
  );
}
