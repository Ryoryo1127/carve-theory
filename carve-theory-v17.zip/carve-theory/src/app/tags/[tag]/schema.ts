/**
 * /tags/[tag] ページ用スキーマビルダー
 * CollectionPage + BreadcrumbList
 */

import {
  buildBreadcrumbSchema,
  buildCollectionPageSchema,
  buildSchemaGraph,
} from "@/lib/schema";
import type { ArticleMeta } from "@/types";
import type { AnySchema } from "@/types/schema";

export function buildTagPageSchemas(tag: string, articles: ArticleMeta[]): string {
  const schemas: AnySchema[] = [];

  schemas.push(
    buildBreadcrumbSchema([
      { name: "ホーム", href: "/" },
      { name: "記事一覧", href: "/articles" },
      { name: `#${tag}`, href: `/tags/${encodeURIComponent(tag)}` },
    ])
  );

  schemas.push(
    buildCollectionPageSchema({
      slug: encodeURIComponent(tag),
      name: `#${tag} の記事一覧 | CARVE THEORY`,
      description: `「${tag}」に関連する技術記事一覧。`,
      articles,
      basePath: "tags",
    })
  );

  return JSON.stringify(
    buildSchemaGraph(schemas),
    null,
    process.env.NODE_ENV === "development" ? 2 : 0
  );
}
