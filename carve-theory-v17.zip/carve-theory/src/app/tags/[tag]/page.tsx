import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { ArticleCard } from "@/components/article/ArticleCard";
import { getArticlesByTag, getAllTags } from "@/lib/articles";
import { SITE_NAME, SITE_URL } from "@/lib/constants";
import { ChevronRight } from "lucide-react";
import { buildTagPageSchemas } from "./schema";

export async function generateStaticParams() {
  const tags = getAllTags();
  return tags.map((t) => ({ tag: t.tag }));
}

export async function generateMetadata({
  params,
}: {
  params: { tag: string };
}): Promise<Metadata> {
  const tag = decodeURIComponent(params.tag);
  const articles = getArticlesByTag(tag);
  if (articles.length === 0) return { title: "Not Found" };

  return {
    title: `#${tag} の記事一覧 | ${SITE_NAME}`,
    description: `「${tag}」に関連する技術記事一覧。${SITE_NAME}の現代技術論に基づく解説をまとめて読む。`,
    alternates: {
      canonical: `${SITE_URL}/tags/${encodeURIComponent(tag)}`,
    },
  };
}

export default function TagPage({ params }: { params: { tag: string } }) {
  const tag = decodeURIComponent(params.tag);
  const articles = getArticlesByTag(tag);

  if (articles.length === 0) notFound();

  const allTags = getAllTags();

  const schemaJson = buildTagPageSchemas(tag, articles);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: schemaJson }}
      />
      <Header />
      <main className="pt-16 bg-[#080808] min-h-screen">
        {/* Header */}
        <div className="bg-[#060606] border-b border-white/5 py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 mb-8">
              <Link
                href="/"
                className="font-mono-custom text-[9px] text-white/25 hover:text-white/50 tracking-widest uppercase transition-colors"
              >
                Home
              </Link>
              <ChevronRight size={10} className="text-white/15" />
              <Link
                href="/articles"
                className="font-mono-custom text-[9px] text-white/25 hover:text-white/50 tracking-widest uppercase transition-colors"
              >
                Articles
              </Link>
              <ChevronRight size={10} className="text-white/15" />
              <span className="font-mono-custom text-[9px] text-white/50 tracking-widest uppercase">
                #{tag}
              </span>
            </nav>

            <p className="font-mono-custom text-[9px] text-white/25 tracking-[0.2em] uppercase mb-3">
              Tag
            </p>
            <h1 className="font-display font-black text-white text-4xl md:text-5xl mb-4">
              #{tag}
            </h1>
            <p className="text-white/40 text-sm md:text-base max-w-xl leading-relaxed">
              「{tag}」に関連する技術記事一覧。
            </p>
            <div className="mt-6 font-mono-custom text-[9px] text-white/20 tracking-widest">
              {articles.length} 記事
            </div>
          </div>
        </div>

        {/* Articles */}
        <section className="py-16 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-px bg-white/5">
              {articles.map((article, i) => (
                <ArticleCard
                  key={article.slug}
                  article={article}
                  variant="default"
                  index={i}
                />
              ))}
            </div>
          </div>
        </section>

        {/* 他のタグへの導線 */}
        <section className="border-t border-white/5 py-12 px-6 md:px-10">
          <div className="max-w-8xl mx-auto">
            <p className="font-mono-custom text-[9px] text-white/20 tracking-[0.2em] uppercase mb-5">
              Other Tags
            </p>
            <div className="flex flex-wrap gap-2">
              {allTags
                .filter((t) => t.tag !== tag)
                .map((t) => (
                  <Link
                    key={t.tag}
                    href={`/tags/${encodeURIComponent(t.tag)}`}
                    className="font-mono-custom text-[9px] text-white/30 border border-white/8 px-3 py-1.5 hover:border-white/20 hover:text-white/60 tracking-widest transition-all"
                  >
                    #{t.tag} <span className="text-white/15">({t.count})</span>
                  </Link>
                ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
