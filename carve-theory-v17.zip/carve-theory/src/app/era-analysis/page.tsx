import type { Metadata } from "next";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { TechEraAnalysis } from "@/components/article/TechEraAnalysis";
import { SITE_NAME, SITE_URL } from "@/lib/constants";

export const metadata: Metadata = {
  title: `旧技術 vs 現代技術 比較分析 | ${SITE_NAME}`,
  description:
    "2010年代の技術論と2022年以降の現代技術を10項目で比較。外向傾・荷重・切り替え・ポジション・上半身・エッジング・重心移動・板の走り・ショートターン・コブ処理。なぜ技術が変化したかを理解する。",
  alternates: { canonical: `${SITE_URL}/era-analysis` },
  openGraph: {
    title: `旧技術 vs 現代技術 | ${SITE_NAME}`,
    description: "2010年代 vs 2022年以降。10項目の技術比較分析。",
    url: `${SITE_URL}/era-analysis`,
    type: "website",
  },
};

export default function EraAnalysisPage() {
  return (
    <>
      <Header />
      <main className="pt-[60px] bg-[#050505] min-h-screen">
        {/* ページヘッダー */}
        <div className="border-b border-white/5 bg-[#060606] py-14 px-6 md:px-10">
          <div className="max-w-5xl mx-auto">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-6 h-px bg-white/20" />
              <span className="font-mono text-[9px] text-white/25 tracking-[0.22em] uppercase">
                Era Analysis
              </span>
              <span className="font-mono text-[8px] text-cyan-400/50 border border-cyan-500/20 px-1.5 py-0.5">
                2026
              </span>
            </div>
            <h1
              className="font-display font-black text-white mb-4 leading-tight"
              style={{ fontSize: "clamp(28px, 5vw, 56px)" }}
            >
              旧技術 vs 現代技術
              <br />
              <span
                style={{
                  background: "linear-gradient(135deg,#22d3ee 0%,#3b82f6 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                比較分析
              </span>
            </h1>
            <p className="text-white/40 text-sm md:text-base leading-relaxed max-w-2xl mb-6">
              2010年代の技術論と、2022年以降に浸透した現代技術の違いを10項目で比較する。
              「どちらが正しい」ではなく、<strong className="text-white/65 font-medium">なぜ技術が変化したのか</strong>を理解する。
            </p>
            <div className="flex flex-wrap items-center gap-4">
              {[
                ["10", "比較項目"],
                ["SVG", "動的ビジュアル"],
                ["メトリクス", "定量比較"],
                ["変化の背景", "要因解説"],
              ].map(([num, label]) => (
                <div key={label} className="flex items-center gap-2">
                  <span className="font-mono text-[9px] text-cyan-400/60 border border-cyan-500/20 px-2 py-0.5">
                    {num}
                  </span>
                  <span className="text-xs text-white/30">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 比較UI本体 */}
        <div className="px-6 md:px-10 py-10">
          <TechEraAnalysis variant="standalone" />
        </div>
      </main>
      <Footer />
    </>
  );
}
