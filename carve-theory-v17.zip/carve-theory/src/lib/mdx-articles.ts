/**
 * CARVE THEORY — Legacy MDX Article Reader
 *
 * 注意：これらの関数はNode.jsの fs/path に依存するサーバー専用コード。
 * content/articles/*.mdx を直接読むための仕組みだが、現在のサイトは
 * MOCK_ARTICLES_V2（lib/constants.ts）を正データとして使っており、
 * この仕組み自体は使われていない（content/articles/には1ファイルのみ残存）。
 *
 * 重要：fs/path/gray-matter を含むこのファイルを"use client"コンポーネントから
 * importすると、クライアントバンドルにNode専用モジュールが混入してビルドが
 * 失敗する。lib/articles.ts はクライアントからも参照されるため、
 * fs依存のコードは意図的にこのファイルへ分離している。
 * 将来MDXベースの運用に戻す場合のみ、サーバーコンポーネントから直接importすること。
 */

import fs from "fs";
import path from "path";
import matter from "gray-matter";
import type { ArticleMeta, Article } from "@/types";
import { estimateReadTime, extractHeadings } from "./utils";

const CONTENT_DIR = path.join(process.cwd(), "content/articles");

/** content/articles/*.mdx のファイル名一覧からslugを取得 */
export function getArticleSlugs(): string[] {
  if (!fs.existsSync(CONTENT_DIR)) return [];
  return fs
    .readdirSync(CONTENT_DIR)
    .filter((f) => f.endsWith(".mdx") || f.endsWith(".md"))
    .map((f) => f.replace(/\.(mdx|md)$/, ""));
}

/** slugを指定してMDXファイルを直接読み込む */
export function getArticleBySlug(slug: string): Article | null {
  const extensions = [".mdx", ".md"];
  let filePath: string | null = null;

  for (const ext of extensions) {
    const candidate = path.join(CONTENT_DIR, `${slug}${ext}`);
    if (fs.existsSync(candidate)) {
      filePath = candidate;
      break;
    }
  }

  if (!filePath) return null;

  const raw = fs.readFileSync(filePath, "utf-8");
  const { data, content } = matter(raw);

  const meta = data as Omit<ArticleMeta, "slug" | "readTime">;
  const readTime = data.readTime ?? estimateReadTime(content);
  const headings = extractHeadings(content);

  return {
    slug,
    ...meta,
    readTime,
    content,
    headings,
    relatedSlugs: data.relatedSlugs ?? [],
    featured: data.featured ?? false,
  } as Article;
}
