import type { ArticleMeta } from "@/types";
import { MOCK_ARTICLES_V2 } from "./constants";

/* ── Get all articles metadata ──
   注：以前はcontent/articles/*.mdxをfsで直接読む実装だったが、
   実際のサイト全体はMOCK_ARTICLES_V2を正データとして使うため、
   getArticlesByCategory/Tag/Route・getRelatedArticles・getAllTags などの
   派生関数が正しく全15記事を参照できるよう、ここでMOCK_ARTICLES_V2を返す。
   fs依存のレガシーMDX読み込み関数（getArticleSlugs/getArticleBySlug）は
   lib/mdx-articles.ts に分離している（"use client"コンポーネントから
   このファイルがimportされるため、fsをここに置くとビルドが壊れる）。 */
export function getAllArticles(): ArticleMeta[] {
  return [...MOCK_ARTICLES_V2].sort(
    (a, b) =>
      new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );
}

/* ── Get featured articles ── */
export function getFeaturedArticles(limit = 4): ArticleMeta[] {
  return getAllArticles()
    .filter((a) => a.featured)
    .slice(0, limit);
}

/* ── Get articles by category ── */
export function getArticlesByCategory(slug: string): ArticleMeta[] {
  return getAllArticles().filter((a) => a.category === slug);
}

/* ── Get articles by tag ── */
export function getArticlesByTag(tag: string): ArticleMeta[] {
  return getAllArticles().filter((a) => a.tags.includes(tag));
}

/* ── Get articles by route ── */
export function getArticlesByRoute(route: string): ArticleMeta[] {
  return getAllArticles().filter((a) => a.route === route);
}

/* ── Get related articles ── */
export function getRelatedArticles(
  slug: string,
  relatedSlugs: string[],
  limit = 3
): ArticleMeta[] {
  const all = getAllArticles();
  const explicit = relatedSlugs
    .map((s) => all.find((a) => a.slug === s))
    .filter((a): a is ArticleMeta => !!a);

  if (explicit.length >= limit) return explicit.slice(0, limit);

  const current = all.find((a) => a.slug === slug);
  if (!current) return explicit;

  const additional = all
    .filter(
      (a) =>
        a.slug !== slug &&
        !relatedSlugs.includes(a.slug) &&
        (a.category === current.category || a.route === current.route)
    )
    .slice(0, limit - explicit.length);

  return [...explicit, ...additional];
}

/* ── Get all tags ── */
export function getAllTags(): { tag: string; count: number }[] {
  const all = getAllArticles();
  const tagMap = new Map<string, number>();
  all.forEach((a) => {
    a.tags.forEach((t) => {
      tagMap.set(t, (tagMap.get(t) ?? 0) + 1);
    });
  });
  return Array.from(tagMap.entries())
    .map(([tag, count]) => ({ tag, count }))
    .sort((a, b) => b.count - a.count);
}

/* ── Static mock data — uses v2 from constants ── */
export const MOCK_ARTICLES: ArticleMeta[] = MOCK_ARTICLES_V2;
