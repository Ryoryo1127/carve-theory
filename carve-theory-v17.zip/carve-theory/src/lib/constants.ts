/* ============================================================
   CARVE THEORY v2 — Constants
   2026年版。現代スキー技術・4新カテゴリ対応。
   ============================================================ */

import type {
  Category, SnowCondition, TechPrinciple, Player,
  TechEraComparison, MogulLineAnalysis, NavGroup,
} from "@/types";

export const SITE_NAME = "CARVE THEORY";
export const SITE_DESCRIPTION =
  "2026年基準のスキー・スノーボード技術分析メディア。現代的な滑走理解——圧のコントロール、早期切り替え、運動連鎖——を軸に技術を解体する。";
export const SITE_URL = "https://carve-theory.vercel.app";
export const SITE_TWITTER = "@carve_theory";

/* ─────────────────────────────────────────────────────────────
   カテゴリ（16種）
───────────────────────────────────────────────────────────── */

export const CATEGORIES: Category[] = [
  /* ── コア技術 ── */
  {
    slug: "carving",
    label: "カービング",
    labelEn: "CARVING",
    description: "たわみと圧の流れ。現代的なカービングは「踏む」ではなく「流す」。",
    color: "#e2e8f0",
    priority: "core",
    group: "technique",
  },
  {
    slug: "short-turn",
    label: "ショートターン",
    labelEn: "SHORT TURN",
    description: "2022年以降の現代ショートターン。エッジ主導から圧の解放と早期切り替えへ。",
    color: "#fbbf24",
    priority: "core",
    group: "technique",
  },
  {
    slug: "long-turn",
    label: "ロングターン",
    labelEn: "LONG TURN",
    description: "弧の入口を早くする。横方向ではなく斜め前への運動を基本とする。",
    color: "#34d399",
    priority: "core",
    group: "technique",
  },
  {
    slug: "transition",
    label: "切り替え",
    labelEn: "TRANSITION",
    description: "早期切り替えが現代技術の核心。フラットの瞬間ではなく圧の解放から始まる。",
    color: "#e879f9",
    priority: "core",
    group: "technique",
  },
  {
    slug: "pressure",
    label: "圧コントロール",
    labelEn: "PRESSURE",
    description: "「踏む」から「流す」へ。雪面圧の質・タイミング・方向の現代的理解。",
    color: "#60a5fa",
    priority: "core",
    group: "technique",
  },
  {
    slug: "edging",
    label: "エッジング",
    labelEn: "EDGING",
    description: "エッジ角の使い分け。目的によって最適角は変わる。",
    color: "#fb923c",
    priority: "core",
    group: "technique",
  },
  {
    slug: "position",
    label: "ポジション",
    labelEn: "POSITION",
    description: "低重心化と自然な運動連鎖。過度な外向傾は現代では否定される。",
    color: "#2dd4bf",
    priority: "core",
    group: "technique",
  },
  /* ── 地形・雪面 ── */
  {
    slug: "mogul-analysis",
    label: "コブ・モーグル",
    labelEn: "MOGUL",
    description: "特殊競技ではなく雪面処理の技術。吸収・ライン・圧コントロール・下半身独立。",
    color: "#f87171",
    priority: "core",
    group: "terrain",
  },
  {
    slug: "terrain-adaptation",
    label: "地形適応",
    labelEn: "TERRAIN",
    description: "急斜面・不整地・コブ・パウダー。地形ごとの運動プログラムを理解する。",
    color: "#a78bfa",
    priority: "emerging",
    group: "terrain",
  },
  {
    slug: "off-piste",
    label: "オフピステ",
    labelEn: "OFF-PISTE",
    description: "パウダー・深雪・圧雪外。整地と何が変わり、何が変わらないか。",
    color: "#818cf8",
    priority: "specialist",
    group: "terrain",
  },
  /* ── 競技分析 ── */
  {
    slug: "technical-race",
    label: "技術選分析",
    labelEn: "TECH RACE",
    description: "2022年以降の採点傾向変化。「頑張って見えない」自然な運動が評価される現代。",
    color: "#fbbf24",
    priority: "specialist",
    group: "competition",
  },
  {
    slug: "alpine-analysis",
    label: "アルペン分析",
    labelEn: "ALPINE",
    description: "W杯の滑りから一般スキーヤーへの技術移植。アルペン由来の現代技術を解析。",
    color: "#3b82f6",
    priority: "specialist",
    group: "competition",
  },
  /* ── 現代技術・科学 ── */
  {
    slug: "modern-technique",
    label: "現代技術",
    labelEn: "MODERN TECH",
    description: "2022年以降の技術変化。低重心・早期切り替え・たわみ利用・圧の流れ。",
    color: "#22d3ee",
    priority: "emerging",
    group: "science",
  },
  {
    slug: "ski-biomechanics",
    label: "バイオメカニクス",
    labelEn: "BIOMECHANICS",
    description: "運動科学からスキーを読む。関節モーメント・筋活動・地面反力の実測データ。",
    color: "#a3e635",
    priority: "emerging",
    group: "science",
  },
  /* ── スノーボード ── */
  {
    slug: "snowboard",
    label: "スノーボード",
    labelEn: "SNOWBOARD",
    description: "スキーとの共通原理と固有技術。カービング・フリーライド・グラトリまで。",
    color: "#a78bfa",
    priority: "core",
    group: "board",
  },
];

/* ─────────────────────────────────────────────────────────────
   ナビゲーション（グループ構造）
───────────────────────────────────────────────────────────── */

export const NAV_ITEMS = [
  { label: "技術解説", href: "/categories" },
  { label: "時代比較", href: "/era-analysis" },
  { label: "選手分析", href: "/players" },
  { label: "コブ・地形", href: "/categories/mogul-analysis" },
  { label: "理論", href: "/categories/ski-biomechanics" },
] as const;

export const NAV_GROUPS: NavGroup[] = [
  {
    label: "技術",
    labelEn: "TECHNIQUE",
    items: [
      { label: "カービング", href: "/categories/carving", description: "圧の流れと板のたわみ" },
      { label: "ショートターン", href: "/categories/short-turn", description: "早期切り替えの現代解釈", badge: "2026" },
      { label: "ロングターン", href: "/categories/long-turn", description: "斜め前への運動" },
      { label: "切り替え", href: "/categories/transition", description: "現代技術の核心", badge: "HOT" },
      { label: "圧コントロール", href: "/categories/pressure", description: "踏むではなく流す" },
      { label: "エッジング", href: "/categories/edging", description: "角度の使い分け" },
      { label: "ポジション", href: "/categories/position", description: "低重心・自然な連鎖" },
    ],
  },
  {
    label: "地形・雪面",
    labelEn: "TERRAIN",
    items: [
      { label: "コブ・モーグル", href: "/categories/mogul-analysis", description: "雪面処理として統合", badge: "NEW" },
      { label: "地形適応", href: "/categories/terrain-adaptation", description: "急斜面・不整地・パウダー", badge: "NEW" },
      { label: "オフピステ", href: "/categories/off-piste", description: "圧雪外の滑り" },
    ],
  },
  {
    label: "競技分析",
    labelEn: "COMPETITION",
    items: [
      { label: "技術選分析", href: "/categories/technical-race", description: "採点変化と現代の滑り" },
      { label: "アルペン分析", href: "/categories/alpine-analysis", description: "W杯からの技術移植" },
    ],
  },
  {
    label: "科学・理論",
    labelEn: "SCIENCE",
    items: [
      { label: "現代技術", href: "/categories/modern-technique", description: "2022年以降の変化", badge: "2026" },
      { label: "時代比較分析", href: "/era-analysis", description: "旧技術 vs 現代技術 10項目", badge: "NEW" },
      { label: "バイオメカニクス", href: "/categories/ski-biomechanics", description: "運動科学で読むスキー", badge: "NEW" },
    ],
  },
  {
    label: "スノーボード",
    labelEn: "SNOWBOARD",
    items: [
      { label: "スノーボード技術", href: "/categories/snowboard", description: "共通原理と固有技術" },
    ],
  },
  {
    label: "スクール・団体",
    labelEn: "FOR ORGANIZATIONS",
    items: [
      { label: "スクール・団体の方へ", href: "/for-schools", description: "教材ライセンス・指導者研修", badge: "NEW" },
    ],
  },
];

/* ─────────────────────────────────────────────────────────────
   技術原則（2026年版）
───────────────────────────────────────────────────────────── */

export const TECH_PRINCIPLES: TechPrinciple[] = [
  {
    id: "pressure-flow",
    title: "圧の流れ",
    titleEn: "PRESSURE FLOW",
    description:
      "踏み込むのではなく、圧を流す。フォールライン方向への重力加速を活かし、板が自然に仕事をする状態を作る。過剰な踏み込みは板の動きを殺す。",
    articleSlugs: ["pressure-control-practice", "carving-turn-complete"],
    modernNote: "2022年以降の技術論の中心。「乗る」から「流す」へのパラダイム転換。",
  },
  {
    id: "early-transition",
    title: "早期切り替え",
    titleEn: "EARLY TRANSITION",
    description:
      "ターンが終わってから切り替えるのではない。圧が最大点を過ぎた瞬間から次のターンが始まる。この認識の違いが現代技術と旧技術の最大の差だ。",
    articleSlugs: ["transition-deep-dive", "short-turn-modern"],
    modernNote: "現代ショートターンと高速大回りの両方に適用される核心概念。",
  },
  {
    id: "low-com",
    title: "低重心",
    titleEn: "LOW CENTER OF MASS",
    description:
      "重心を低く保つことで、外力への対応が速くなる。過度な伸び上がりは重心の上昇を招き、不安定を生む。股関節を常に適度に曲げた状態を維持する。",
    articleSlugs: ["low-com-position-building", "terrain-adaptation-guide"],
    modernNote: "アルペン由来の知見が一般スキーヤーにも適用されつつある。",
  },
  {
    id: "flex-use",
    title: "たわみの利用",
    titleEn: "FLEX UTILIZATION",
    description:
      "板のたわみはエネルギーの蓄積だ。たわんだ板が戻る力を次のターンに活かす。踏んで潰すのではなく、たわみを作り、解放する。",
    articleSlugs: ["carving-turn-complete", "pressure-control-practice"],
    modernNote: "現代のカービングスキー・レーシングスキーの設計と一体の技術論。",
  },
  {
    id: "kinetic-chain-natural",
    title: "自然な運動連鎖",
    titleEn: "NATURAL KINETIC CHAIN",
    description:
      "上半身を固定するのではなく、体幹から足先まで自然に連動させる。過度な外向傾の強制は運動連鎖を断ち切る。モーグルの吸収動作も同じ原理で動く。",
    articleSlugs: ["tech-comp-scoring", "mogul-terrain-processing"],
    modernNote: "旧教程の「上半身固定・分離」から「自然な連鎖」への理解の転換。",
  },
  {
    id: "diagonal-motion",
    title: "斜め前への運動",
    titleEn: "DIAGONAL FORWARD MOTION",
    description:
      "横方向へのポジション移動ではなく、フォールライン方向（斜め前）への重心移動が現代技術の核心。板は横に動かすものではなく、前に走らせるものだ。",
    articleSlugs: ["long-turn-modern", "modern-technique-overview"],
    modernNote: "最も根本的な認識の転換。圧雪でもパウダーでもコブでも共通する原理。",
  },
];

/* ─────────────────────────────────────────────────────────────
   2010年代 vs 2022年以降 技術比較
───────────────────────────────────────────────────────────── */

export const ERA_COMPARISONS: TechEraComparison[] = [
  {
    aspect: "切り替えのタイミング",
    classic: "ターンが完全に終わってから切り替える。山回りを仕上げてから次へ。",
    modern: "圧が最大点を過ぎた瞬間から切り替えを始める。ターンは終わる前から次が始まる。",
    why: "アルペン競技の分析から、早期切り替えが板の走りを最大化することが明らかになった。",
    impact: "high",
  },
  {
    aspect: "上半身の役割",
    classic: "上半身を静止・固定する。上下分離が高評価の指標。",
    modern: "上半身は自然に動く。体幹から末端への運動連鎖を妨げない。",
    why: "モーグルやフリースキーの知見が一般スキーに統合された。固定は筋緊張を高め、反応を遅らせる。",
    impact: "high",
  },
  {
    aspect: "荷重の質",
    classic: "外足を踏み込む。強い荷重が良い滑りの証拠。",
    modern: "圧を流す。板が自然に仕事をする状態を作る。過剰な踏み込みは板を殺す。",
    why: "板の性能向上（ロッカー・たわみ特性）により、プレッシャーの質が量より重要になった。",
    impact: "high",
  },
  {
    aspect: "外向傾の程度",
    classic: "強い外向傾が安定の証拠。腰を回し込む動作が評価された。",
    modern: "自然な外向傾。過度な外向傾はターン前半のエッジングを阻害する。",
    why: "生体力学的分析から、過剰な外向傾が膝・腰への負担を高めることが判明した。",
    impact: "medium",
  },
  {
    aspect: "重心の高さ",
    classic: "切り替えで伸び上がる。フォールラインで沈み込む。",
    modern: "常に低重心を維持。伸び上がりは最小限。股関節の角度変化で吸収する。",
    why: "重心を高くすると外力への対応時間が短くなり、不安定を招く。",
    impact: "medium",
  },
  {
    aspect: "コブの位置づけ",
    classic: "モーグルは特殊競技。一般スキーヤーには関係ない。",
    modern: "コブは雪面処理の最高難度版。ここで学ぶ吸収・ライン・圧制御は全地形に応用できる。",
    why: "コブで鍛えた下半身独立・吸収動作・ライン読みは、急斜面やパウダーでも同じ原理で動く。",
    impact: "medium",
  },
];

/* ─────────────────────────────────────────────────────────────
   モーグル雪面処理フェーズ
───────────────────────────────────────────────────────────── */

export const MOGUL_PHASES: MogulLineAnalysis[] = [
  {
    phase: "approach",
    label: "アプローチ",
    description: "次のコブの形状を読む。コブの頂上・谷・吸収ポイントを事前に判断する。",
    bodyFocus: "視線・重心の準備・膝の予荷重",
    pressureState: "neutral",
  },
  {
    phase: "absorption",
    label: "吸収",
    description: "コブの頂上に向かって膝・股関節を屈曲させ、雪面からの突き上げを吸収する。下半身が独立して動く。",
    bodyFocus: "膝・股関節の屈曲、上半身の安定",
    pressureState: "loading",
  },
  {
    phase: "contact",
    label: "コンタクト",
    description: "コブの頂上付近で圧が最大になる。この圧を利用してターンを仕上げる。",
    bodyFocus: "外足への集中荷重、骨盤の向き",
    pressureState: "loading",
  },
  {
    phase: "extension",
    label: "伸展・抜重",
    description: "コブの谷に向けて脚を伸ばす。圧を解放し、次のコブへの準備を始める。",
    bodyFocus: "脚の伸展、重心の前方移動",
    pressureState: "releasing",
  },
  {
    phase: "exit",
    label: "脱出・次への接続",
    description: "コブの谷から次のアプローチへ。ここでのポジションが次のコブの質を決める。",
    bodyFocus: "ラインの確認、次のコブへの準備",
    pressureState: "neutral",
  },
];

/* ─────────────────────────────────────────────────────────────
   選手データ（2026年版）
───────────────────────────────────────────────────────────── */

export const PLAYERS: Player[] = [
  {
    id: "minagawa",
    name: "皆川賢太郎",
    nameEn: "MINAGAWA Kentaro",
    nationality: "日本",
    discipline: "アルペン GS/SL",
    route: "アルペン",
    color: "#60a5fa",
    era: "reference",
    signature:
      "ターン前半からエッジが機能している。それだけで他の選手と別次元に見える。この「早期エッジング」こそ現代技術の起点になった。",
    modernTraits: [
      "早期切り替えの体現者",
      "ターン前半の圧コントロールが突出",
      "現代アルペン技術の日本への架け橋",
    ],
    traits: [
      { label: "早期エッジング", value: 96, description: "フォールライン手前からエッジが機能する。現代技術への橋渡し。" },
      { label: "切り替え速度", value: 93, description: "フラット時間が一般スキーヤーの半分以下。" },
      { label: "外スキー荷重", value: 90, description: "高速域での外スキーへの荷重が安定。内倒がほぼない。" },
      { label: "ターン前半制御", value: 97, description: "弧がフォールライン手前から始まる。現代技術の核心。" },
    ],
    articles: ["gs-turn-analysis", "edging-angle-strategy"],
  },
  {
    id: "yoshioka",
    name: "吉岡大輔",
    nameEn: "YOSHIOKA Daisuke",
    nationality: "日本",
    discipline: "スキー技術選",
    route: "技術選",
    color: "#fbbf24",
    era: "reference",
    signature:
      "2022年以降の技術選で評価される「自然な連鎖」の先駆者。上半身の静粛性と下半身の自由が両立している稀有な例。",
    modernTraits: [
      "自然な運動連鎖の体現",
      "過剰な外向傾なしの安定",
      "現代技術選評価の先取り",
    ],
    traits: [
      { label: "上半身の自然な静粛性", value: 98, description: "固定ではなく自然に静か。連鎖が途切れていない。" },
      { label: "山回り荷重維持", value: 97, description: "ターン後半まで外スキーへの荷重が途切れない。" },
      { label: "圧の流れ", value: 96, description: "踏み込みではなく、圧を流す感覚が際立っている。" },
      { label: "弧の丸さ", value: 95, description: "最後まで弧を描ききるため仕上がりが美しい。" },
    ],
    articles: ["tech-comp-scoring", "modern-technique-overview"],
  },
  {
    id: "hoshino",
    name: "堀島行真",
    nameEn: "HOSHINO Ikuma",
    nationality: "日本",
    discipline: "モーグル",
    route: "モーグル",
    color: "#f87171",
    era: "active",
    signature:
      "コブの吸収と伸展が完全に自動化されている。視線が常に2コブ先を見ており、体は今のコブを処理しながら次の準備をしている。",
    modernTraits: [
      "下半身独立動作の極限",
      "視線と身体処理の分離",
      "吸収→圧→解放の完璧なリズム",
    ],
    traits: [
      { label: "吸収タイミング", value: 99, description: "コブの形状を読んだ吸収開始が世界最速レベル。" },
      { label: "ライン精度", value: 97, description: "ベストラインを一度も外さない一貫性。" },
      { label: "下半身独立", value: 98, description: "上半身が完全に静止したまま、下半身だけが激しく動く。" },
      { label: "圧制御", value: 96, description: "各コブで圧を均一にコントロール。バウンドしない安定感。" },
    ],
    articles: ["mogul-terrain-processing", "terrain-adaptation-guide"],
  },
];

/* ─────────────────────────────────────────────────────────────
   雪質（現代的アプローチを追加）
───────────────────────────────────────────────────────────── */

export const SNOW_CONDITIONS: SnowCondition[] = [
  {
    slug: "groomed",
    label: "圧雪",
    description: "グルーミングされた締まった雪面",
    icon: "■",
    tips: ["たわみと圧の流れを最も感じやすい雪面", "早期切り替えの練習に最適", "シュプールで現代技術の精度が確認できる"],
    difficulty: 2,
    modernApproach: "圧を踏むのではなく板に乗る。たわみが戻る力を次のターンに利用する。",
  },
  {
    slug: "powder",
    label: "パウダー",
    description: "新雪・深雪",
    icon: "❄",
    tips: ["両足均等荷重を基本にする", "ターンリズムを遅くして板を浮かせる", "フォールラインへの落下を使う"],
    difficulty: 4,
    modernApproach: "重心を後ろに引くのではなく、常にフォールライン方向に落ちる。横ではなく前に動く。",
  },
  {
    slug: "ice",
    label: "アイスバーン",
    description: "凍結した硬い雪面",
    icon: "◆",
    tips: ["エッジの精度が全て", "筋肉で板を押さえない", "体の傾きで自然に噛み込ませる"],
    difficulty: 5,
    modernApproach: "圧を急激にかけない。エッジが徐々に食い込む時間を与える。早急な切り替えは逆効果。",
  },
  {
    slug: "spring",
    label: "春雪",
    description: "ザクザクした重い雪",
    icon: "◎",
    tips: ["テールが刺さりやすい", "荷重タイミングを意識的に遅らせる", "たわみが使いにくいので体重移動で補う"],
    difficulty: 3,
    modernApproach: "板が走らない分、重心移動でリズムを作る。圧の量より方向を意識する。",
  },
  {
    slug: "wind-crust",
    label: "風成雪",
    description: "硬い表面に柔らかい層が重なる",
    icon: "◈",
    tips: ["表面が割れることを想定する", "荷重を分散させる", "急激な動作変化を避ける"],
    difficulty: 4,
    modernApproach: "下半身の独立動作（モーグル技術）が最も有効。突然の変化に対応できる体勢を維持する。",
  },
];

/* ─────────────────────────────────────────────────────────────
   現代技術タグ
───────────────────────────────────────────────────────────── */

export const MODERN_TAGS = [
  { slug: "early-transition", label: "早期切り替え", isModern: true },
  { slug: "pressure-flow", label: "圧の流れ", isModern: true },
  { slug: "low-com", label: "低重心", isModern: true },
  { slug: "flex-use", label: "たわみ利用", isModern: true },
  { slug: "diagonal-motion", label: "斜め前運動", isModern: true },
  { slug: "kinetic-chain", label: "運動連鎖", isModern: true },
  { slug: "absorption", label: "吸収動作", isModern: true },
  { slug: "line-reading", label: "ライン読み", isModern: true },
  { slug: "lower-body-independence", label: "下半身独立", isModern: true },
  { slug: "natural-angulation", label: "自然な外向傾", isModern: true },
] as const;

/* ─────────────────────────────────────────────────────────────
   記事モックデータ（v2）
───────────────────────────────────────────────────────────── */

import type { ArticleMeta } from "@/types";

export const MOCK_ARTICLES_V2: ArticleMeta[] = [
  {
    slug: "carving-turn-complete",
    title: "カービングターン完全解説",
    subtitle: "圧の流れと板のたわみ——2026年版の理解",
    excerpt: "「踏む」から「流す」へ。現代のカービング技術は、過剰な踏み込みではなく板が自然に仕事をする状態を作ることにある。",
    category: "carving",
    tags: ["圧の流れ", "たわみ利用", "エッジング", "早期切り替え"],
    route: "スキー",
    level: "中級",
    readTime: 18,
    publishedAt: "2026-01-10",
    featured: true,
    era: "both",
    modernUpdated: true,
  },
  {
    slug: "modern-technique-overview",
    title: "2022年以降のスキー技術変化",
    subtitle: "何が変わり、何が変わっていないか",
    excerpt: "低重心・早期切り替え・圧の流れ・自然な運動連鎖。2022年以降に浸透した技術的転換を整理する。従来の教程との違いを明確にする。",
    category: "modern-technique",
    tags: ["早期切り替え", "低重心", "圧の流れ", "運動連鎖"],
    route: "スキー",
    level: "中級",
    readTime: 22,
    publishedAt: "2026-01-15",
    featured: true,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "short-turn-modern",
    title: "現代ショートターンの構造",
    subtitle: "エッジ主導から圧の解放と早期切り替えへ",
    excerpt: "旧来のショートターンは「エッジを立てて切る」だった。現代は違う。圧が解放された瞬間から次のターンが始まる。この認識の転換がすべてだ。",
    category: "short-turn",
    tags: ["早期切り替え", "圧の流れ", "エッジング", "リズム"],
    route: "スキー",
    level: "上級",
    readTime: 16,
    publishedAt: "2026-01-08",
    featured: true,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "mogul-terrain-processing",
    title: "コブを「雪面処理」として理解する",
    subtitle: "吸収・ライン・圧コントロール・下半身独立",
    excerpt: "コブは特殊競技ではない。雪面処理の最高難度版だ。ここで身につく技術——吸収動作・ライン読み・下半身独立——は急斜面でもパウダーでも使える。",
    category: "mogul-analysis",
    tags: ["吸収動作", "ライン読み", "下半身独立", "圧コントロール"],
    route: "スキー",
    level: "中級",
    readTime: 20,
    publishedAt: "2026-01-12",
    featured: true,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "ski-biomechanics-intro",
    title: "スキーのバイオメカニクス入門",
    subtitle: "関節モーメント・筋活動・地面反力から滑りを読む",
    excerpt: "感覚と理論の橋渡しをするのがバイオメカニクスだ。「なぜその動きが有効か」を運動科学の言語で説明する。数値で見えると、練習の方向が変わる。",
    category: "ski-biomechanics",
    tags: ["関節モーメント", "筋活動", "地面反力", "運動連鎖"],
    route: "スキー",
    level: "上級",
    readTime: 24,
    publishedAt: "2026-01-05",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "terrain-adaptation-guide",
    title: "地形適応ガイド",
    subtitle: "急斜面・コブ・パウダー——地形ごとの運動プログラム",
    excerpt: "地形が変われば運動プログラムが変わる。しかし基本原理は同じだ。低重心・圧の流れ・自然な連鎖。この3つがどの地形でも共通する軸になる。",
    category: "terrain-adaptation",
    tags: ["地形適応", "低重心", "圧の流れ", "急斜面"],
    route: "スキー",
    level: "上級",
    readTime: 19,
    publishedAt: "2026-01-03",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "tech-comp-scoring",
    title: "2026年・技術選採点の現実",
    subtitle: "変化した評価基準と現代の滑り",
    excerpt: "技術選の採点は変わった。「頑張って見える」滑りではなく、自然な運動連鎖と圧の流れが評価される。古い「外向傾・分離」の理解では通用しない。",
    category: "technical-race",
    tags: ["採点", "現代技術", "自然な連鎖", "技術選"],
    route: "技術選",
    level: "上級",
    readTime: 20,
    publishedAt: "2026-01-04",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "gs-turn-analysis",
    title: "GSターンの現代解析",
    subtitle: "W杯から一般スキーヤーへの技術移植",
    excerpt: "W杯GSの滑りは、現代スキー技術の最前線だ。早期エッジング・低重心・圧の流れ——これらは競技者だけの話ではなく、一般スキーヤーにも直接応用できる。",
    category: "alpine-analysis",
    tags: ["GS", "早期エッジング", "低重心", "圧の流れ"],
    route: "アルペン",
    level: "上級",
    readTime: 22,
    publishedAt: "2026-01-02",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "long-turn-modern",
    title: "ロングターンの再定義",
    subtitle: "横ではなく、前へ——大回りの現代解釈",
    excerpt: "大きな弧を描くロングターンも、横方向への体重移動という旧来の理解から、フォールライン方向への重心移動という現代の理解へ更新されている。",
    category: "long-turn",
    tags: ["斜め前運動", "重心移動", "板の走り", "ロングターン"],
    route: "スキー",
    level: "中級",
    readTime: 17,
    publishedAt: "2026-01-18",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "transition-deep-dive",
    title: "切り替えの研究",
    subtitle: "フラットという瞬間についての誤解を解く",
    excerpt: "切り替えは「ターンの合間の無の時間」ではない。圧が解放される瞬間から、もう次のターンが始まっている。切り替えという局面を構造から理解する。",
    category: "transition",
    tags: ["早期切り替え", "圧の流れ", "たわみ利用"],
    route: "スキー",
    level: "上級",
    readTime: 18,
    publishedAt: "2026-01-19",
    featured: true,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "pressure-control-practice",
    title: "圧コントロール実践編",
    subtitle: "踏むのではなく、流すという技術",
    excerpt: "「圧を流す」という言葉は理解しても、実際に体で再現するのは難しい。荷重・抜重の具体的な感覚と、それを身につけるための練習法を扱う。",
    category: "pressure",
    tags: ["圧の流れ", "荷重", "抜重", "たわみ利用"],
    route: "スキー",
    level: "中級",
    readTime: 16,
    publishedAt: "2026-01-20",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "edging-angle-strategy",
    title: "エッジングの再設計",
    subtitle: "角度は目的によって使い分ける",
    excerpt: "「エッジ角は大きいほど良い」という理解は単純化しすぎている。雪質・速度・ターンの目的によって、最適なエッジ角は変わる。角度の使い分けを学ぶ。",
    category: "edging",
    tags: ["エッジング", "エッジ角", "雪質対応"],
    route: "スキー",
    level: "中級",
    readTime: 15,
    publishedAt: "2026-01-21",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "low-com-position-building",
    title: "低重心ポジションの作り方",
    subtitle: "現代スキーの基本姿勢を体に入れる",
    excerpt: "低重心という概念を理解するだけでは滑りは変わらない。股関節の角度、骨盤の位置、それを保つための具体的な体の作り方を一つずつ確認する。",
    category: "position",
    tags: ["低重心", "ポジション", "股関節"],
    route: "スキー",
    level: "初級",
    readTime: 14,
    publishedAt: "2026-01-22",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "off-piste-intro",
    title: "オフピステ入門",
    subtitle: "圧雪外の雪面にどう適応するか",
    excerpt: "オフピステは特別な技術が必要な世界ではない。整地で培った圧コントロールとポジションの応用だ。何を変え、何を変えないかを整理する。",
    category: "off-piste",
    tags: ["オフピステ", "パウダー", "地形適応"],
    route: "スキー",
    level: "上級",
    readTime: 17,
    publishedAt: "2026-01-23",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "snowboard-shared-principles",
    title: "スノーボードとスキーの共通原理",
    subtitle: "種目を超えて通用する技術の軸",
    excerpt: "スキーとスノーボードは別の道具に見えて、雪面から力を受け取る原理は共通している。種目の壁を越えて使える技術の軸を整理する。",
    category: "snowboard",
    tags: ["共通原理", "エッジング", "圧の流れ"],
    route: "スノーボード",
    level: "中級",
    readTime: 16,
    publishedAt: "2026-01-24",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "carving-basics-for-beginners",
    title: "カービングの第一歩",
    subtitle: "エッジを「立てよう」とせず、まず傾くことから始める",
    excerpt: "カービングは上級者だけの技術ではない。最初から「エッジを立てる」意識を間違えると、長く苦労する。入門者が最初に身につけるべき感覚を整理する。",
    category: "carving",
    tags: ["入門", "エッジング", "低重心", "基本姿勢"],
    route: "スキー",
    level: "入門",
    readTime: 13,
    publishedAt: "2026-01-25",
    featured: true,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "short-turn-rhythm-drills",
    title: "ショートターンのリズムを作るドリル集",
    subtitle: "理論を体に落とし込むための実践練習",
    excerpt: "圧の解放が次のターンを作るという理論を理解しても、体が動かなければ意味がない。リズムを作るための具体的な練習法を順番に紹介する。",
    category: "short-turn",
    tags: ["リズム", "ドリル", "早期切り替え"],
    route: "スキー",
    level: "中級",
    readTime: 15,
    publishedAt: "2026-01-26",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "pressure-sensing-fundamentals",
    title: "圧を感じるということ",
    subtitle: "荷重感覚の基礎を足裏から作る",
    excerpt: "「圧を流す」という上級者の言葉の前に、まず圧を感じる感覚そのものが必要だ。足裏のどこに体重を感じているか。基礎から丁寧に確認する。",
    category: "pressure",
    tags: ["足裏感覚", "荷重", "基礎"],
    route: "スキー",
    level: "初級",
    readTime: 12,
    publishedAt: "2026-01-27",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "position-common-mistakes",
    title: "ポジションのよくある間違い5つ",
    subtitle: "なぜそのポジションになるのか、原因から理解する",
    excerpt: "「もっと低く」「もっと前に」と言われても、なぜそうなっていないのかがわからなければ直らない。よくある5つの間違いを原因から整理する。",
    category: "position",
    tags: ["ポジション", "後傾", "よくある間違い"],
    route: "スキー",
    level: "中級",
    readTime: 14,
    publishedAt: "2026-01-28",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "mogul-competition-format",
    title: "モーグル競技の採点構造",
    subtitle: "ターン・エア・スピードという3要素の現代的バランス",
    excerpt: "モーグル競技の採点は、ターン技術・エア・スピードの3要素で構成される。それぞれの比重と、現代競技で評価される滑りの傾向を整理する。",
    category: "mogul-analysis",
    tags: ["採点", "モーグル競技", "エア"],
    route: "モーグル",
    level: "競技",
    readTime: 16,
    publishedAt: "2026-01-29",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "freeride-terrain-reading",
    title: "フリーライドのライン読み",
    subtitle: "整備されていない斜面で、どこを通るかを判断する",
    excerpt: "フリーライドでは、コースが用意されていない。雪質・地形・斜度を読み、安全かつ滑らかなラインを選ぶ判断力が技術そのものより先に問われる。",
    category: "terrain-adaptation",
    tags: ["フリーライド", "ライン読み", "地形適応"],
    route: "フリースキー",
    level: "上級",
    readTime: 17,
    publishedAt: "2026-01-30",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
  {
    slug: "snowboard-carving-technique",
    title: "スノーボードカービングの技術構造",
    subtitle: "ヒールサイド・トウサイドの圧配分を理解する",
    excerpt: "スノーボードのカービングは、スキーとは荷重の作り方が異なる。ヒールサイドとトウサイド、それぞれの圧配分と板のたわみの使い方を解説する。",
    category: "snowboard",
    tags: ["カービング", "ヒールサイド", "トウサイド"],
    route: "スノーボード",
    level: "中級",
    readTime: 15,
    publishedAt: "2026-01-31",
    featured: false,
    era: "modern",
    modernUpdated: true,
  },
];
