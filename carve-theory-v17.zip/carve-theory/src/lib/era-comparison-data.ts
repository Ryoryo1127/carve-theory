/**
 * CARVE THEORY — Era Comparison Detail Data
 * 旧技術 vs 現代技術の10項目詳細比較データ
 */

import type { TechEraDetail } from "@/types";

export const ERA_DETAIL_DATA: TechEraDetail[] = [
  /* ─── 1. 外向傾 ─── */
  {
    id: "angulation",
    label: "外向傾",
    labelEn: "ANGULATION",
    aspect: "外向傾・アンギュレーション",
    classic: "強い外向傾が安定・技術力の証明とされた。腰をターン外側へ意識的に回し込み、上半身を谷方向へ向ける動作を「コアンギュレーション」として高く評価した。",
    modern: "自然な外向傾を維持する。過度な外向傾の強制はターン前半のエッジング開始を遅らせ、膝・腰への負担を高める。必要な分だけ、自然に発生させる。",
    why: "生体力学研究（2018〜）から、過度な外向傾が骨盤の捻転を引き起こし、膝関節への内反モーメントを高めることが数値で明らかになった。W杯選手の映像解析でも、優勝ラインの選手ほど外向傾が自然かつ最小であることが確認された。",
    drivers: [
      "スポーツ医学・バイオメカニクス研究の蓄積",
      "W杯映像の高精度スロー分析が普及",
      "関節負荷の長期追跡データ",
    ],
    classicBodyEffect: "腰椎・膝関節への慢性的な負担。長期的に腰痛・膝痛のリスクを高める。上半身の過剰回転が運動連鎖を断ち切る。",
    modernBodyEffect: "股関節・膝関節への負荷が均等化。自然な外向傾は体幹の安定を保ちながら、足先への運動連鎖を維持する。",
    commonMisconception: "「外向傾を減らすと安定しない」という誤解。実際は自然な外向傾の方が、股関節の自由度を保ち、外力への対応が速くなる。",
    impact: "medium",
    metrics: [
      { label: "膝関節内反モーメント", classic: 78, modern: 42, unit: "N·m", higherIsBetter: false },
      { label: "ターン前半エッジング開始", classic: 38, modern: 72, unit: "%", higherIsBetter: true },
      { label: "腰椎回旋角", classic: 82, modern: 35, unit: "°", higherIsBetter: false },
      { label: "運動連鎖の連続性", classic: 44, modern: 81, unit: "%", higherIsBetter: true },
    ],
  },

  /* ─── 2. 荷重 ─── */
  {
    id: "pressure",
    label: "荷重",
    labelEn: "PRESSURE",
    aspect: "荷重の質・プレッシャーコントロール",
    classic: "外足を力強く「踏み込む」ことが正しい荷重とされた。体重の乗った外足からのプッシュが推進力を生むという理解。強く踏むほど良い滑りとみなされた。",
    modern: "圧を「流す」。フォールライン方向への重力加速を活かし、板が自然に仕事をする状態を作る。過剰な踏み込みは板のたわみを殺し、走りを損なう。",
    why: "カービングスキーのたわみ特性の理解が深まった。板は「踏む」ことでたわみ、その復元力を利用する。しかし踏み続けると板が仕事をする前に圧を逃がしてしまう。「圧を乗せて、解放する」サイクルの方が板の性能を引き出せることが判明した。",
    drivers: [
      "カービングスキーのたわみ特性研究",
      "圧力センサー内蔵インソールによる実測データ",
      "フリースキー・モーグル技術の統合",
    ],
    classicBodyEffect: "大腿四頭筋への過剰な筋負荷。午前中に脚が終わる疲労パターン。板が仕事をしないため余計な筋出力が必要。",
    modernBodyEffect: "筋肉の爆発的収縮より持続的な緊張制御。重力と遠心力を利用するため疲労が軽減。体重移動の効率が上がる。",
    commonMisconception: "「圧を流す＝踏まない」という誤解。圧を流すには正確なタイミングで荷重を作り、そして解放する能動的な動作が必要。",
    impact: "high",
    metrics: [
      { label: "ターン中の最大圧力", classic: 85, modern: 72, unit: "%BW", higherIsBetter: false },
      { label: "圧力の持続時間", classic: 62, modern: 48, unit: "%ターン", higherIsBetter: false },
      { label: "板のたわみ利用率", classic: 35, modern: 78, unit: "%", higherIsBetter: true },
      { label: "脚の疲労指標（1時間後）", classic: 74, modern: 48, unit: "%max", higherIsBetter: false },
    ],
  },

  /* ─── 3. 切り替え ─── */
  {
    id: "transition",
    label: "切り替え",
    labelEn: "TRANSITION",
    aspect: "切り替えのタイミングと質",
    classic: "ターンが完全に終わってから切り替える。山回りをしっかり仕上げ、板が止まりかけてから次へ。切り替えは「ターンとターンの間」の明確な区切りとして存在した。",
    modern: "圧が最大点を過ぎた瞬間から次のターンが始まる。ターンは終わる前から次が始まっている。早期切り替えが板の走りを最大化し、リズムを生む。",
    why: "アルペン競技のタイム分析（2015〜）から、切り替えのタイミングが速い選手ほどタイムが良いことが定量的に示された。物理的には、圧が最大点を過ぎた後に早期切り替えをすると、板のたわみエネルギーを次のターンに持ち越せることが理論化された。",
    drivers: [
      "アルペン競技のタイム細分析",
      "板のたわみエネルギー移転の物理理論",
      "モーション・キャプチャーによる身体動作解析",
    ],
    classicBodyEffect: "ターン後半に重心が遅れ、次のターンへの移行が遅くなる。特にショートターンでリズムが詰まりやすい。",
    modernBodyEffect: "重心が常に前方へ移動し続ける。板の走りのエネルギーを次のターンに転換できる。ターン間のフラット時間が短縮される。",
    commonMisconception: "「早く切り替える＝ターンが浅くなる」という誤解。早期切り替えは弧を途中で切るのではなく、圧の解放を起点として次のエッジングを始めること。",
    impact: "high",
    metrics: [
      { label: "フラット時間の長さ", classic: 72, modern: 31, unit: "ms", higherIsBetter: false },
      { label: "切り替え開始タイミング", classic: 28, modern: 67, unit: "%ターン前", higherIsBetter: true },
      { label: "板の走り持続率", classic: 44, modern: 79, unit: "%", higherIsBetter: true },
      { label: "次ターン準備完了速度", classic: 38, modern: 76, unit: "スコア", higherIsBetter: true },
    ],
  },

  /* ─── 4. ポジション ─── */
  {
    id: "position",
    label: "ポジション",
    labelEn: "POSITION",
    aspect: "基本ポジションと重心管理",
    classic: "フォールライン方向への「前傾」を強調。ブーツのタングに脛を押し当てる前傾姿勢が正しいポジションとされた。伸び上がりと沈み込みの上下運動が荷重変化を作るとされた。",
    modern: "低重心を常に維持する。股関節・膝関節を適度に曲げ、重心を低く安定させる。前傾はブーツを押すのではなく、骨盤と重心が前方にある状態で実現する。",
    why: "重心が高い状態では外力への対応時間（慣性モーメント）が大きくなり、予期しない力に対応しにくくなることが力学的に明らかになった。低重心は素早い荷重移動を可能にし、不整地でのバランス回復も速くなる。",
    drivers: [
      "運動力学における重心高さと安定性の研究",
      "アルペン競技映像の重心軌跡分析",
      "スポーツ科学における慣性モーメント研究",
    ],
    classicBodyEffect: "切り替えごとに重心が上下し、エネルギーロスが大きい。高い重心はバランス崩壊時の回復を遅らせる。",
    modernBodyEffect: "重心の上下移動が最小化されエネルギーが保存される。低重心は外乱への反応速度を高め、不整地でも安定を保ちやすい。",
    commonMisconception: "「低重心＝前傾を強める」という誤解。低重心は股関節を曲げることで実現し、ブーツを前に押す前傾とは根本的に異なる。",
    impact: "medium",
    metrics: [
      { label: "重心高さの変動幅", classic: 68, modern: 28, unit: "cm", higherIsBetter: false },
      { label: "股関節屈曲角（平均）", classic: 34, modern: 58, unit: "°", higherIsBetter: true },
      { label: "バランス回復速度", classic: 42, modern: 76, unit: "スコア", higherIsBetter: true },
      { label: "エネルギー損失率", classic: 61, modern: 32, unit: "%", higherIsBetter: false },
    ],
  },

  /* ─── 5. 上半身 ─── */
  {
    id: "upper-body",
    label: "上半身",
    labelEn: "UPPER BODY",
    aspect: "上半身の役割と動作",
    classic: "上半身は固定・静止させる。「上下分離」が技術的成熟の証拠とされ、上半身が動かないことが高い評価の条件だった。強制的な分離を作ることが指導の中心だった。",
    modern: "上半身は自然に動く。体幹から足先への運動連鎖を妨げない。固定するのではなく、必要な分だけ連動させる。「自然な静粛性」と「強制的な固定」は別物。",
    why: "神経筋研究から、意識的な筋緊張（固定）は反応速度を落とすことが明らかになった。モーグル選手の動作分析では、一見静かな上半身は「固定」ではなく「適応的な連動」であることが判明した。",
    drivers: [
      "神経科学における筋緊張と反応速度の研究",
      "モーグル・フリースキー選手の動作解析",
      "スポーツバイオメカニクスにおける運動連鎖理論",
    ],
    classicBodyEffect: "腹圧の上昇による呼吸制限。意識的な固定が体幹の自然な安定機能を阻害。反応速度の低下。",
    modernBodyEffect: "体幹の自然な安定機能が維持される。呼吸が自然。下半身の動作への適応的な反応が速くなる。",
    commonMisconception: "「上半身を動かして良い＝ローテーションしていい」という誤解。自然な連動とローテーション（回し込み）は全く異なる。",
    impact: "high",
    metrics: [
      { label: "腹圧（固定時）", classic: 81, modern: 45, unit: "%max", higherIsBetter: false },
      { label: "下半身への反応速度", classic: 38, modern: 74, unit: "スコア", higherIsBetter: true },
      { label: "体幹の自然安定率", classic: 43, modern: 77, unit: "%", higherIsBetter: true },
      { label: "呼吸制限度", classic: 65, modern: 24, unit: "スコア", higherIsBetter: false },
    ],
  },

  /* ─── 6. エッジング ─── */
  {
    id: "edging",
    label: "エッジング",
    labelEn: "EDGING",
    aspect: "エッジングの方法と角度管理",
    classic: "エッジを「立てる」意識が強調された。足首や膝を内側に倒してエッジ角を作ることが指導された。強いエッジングが安定したカービングの証拠とされた。",
    modern: "体の傾きの結果としてエッジが立つ。目的と地形によってエッジ角を使い分ける。エッジングの強度より「開始タイミング」と「角度の滑らかな変化」が重要。",
    why: "エッジングの原理研究から、足首・膝によるエッジ操作は関節負荷が高く、再現性が低いことが判明した。体全体の傾きに連動したエッジングの方が、より大きな角度を安定して作れることが測定された。",
    drivers: [
      "エッジング原理の力学的分析",
      "足関節・膝関節への負荷測定",
      "アルペン選手のエッジング開始タイミング研究",
    ],
    classicBodyEffect: "足首・膝関節への慢性的な側方ストレス。膝の靭帯への負担が高まる。エッジ操作が力みを生む。",
    modernBodyEffect: "エッジングが体の傾きに連動するため、関節への側方ストレスが分散される。自然なエッジングは持続可能で疲れにくい。",
    commonMisconception: "「エッジを立てないカービング＝甘いエッジング」という誤解。体の傾きから作るエッジングの方が、より高いエッジ角を安定して実現できる。",
    impact: "medium",
    metrics: [
      { label: "エッジ開始タイミング", classic: 31, modern: 72, unit: "早さ%", higherIsBetter: true },
      { label: "最大エッジ角", classic: 52, modern: 67, unit: "°", higherIsBetter: true },
      { label: "足首関節負荷", classic: 76, modern: 41, unit: "N·m", higherIsBetter: false },
      { label: "エッジングの再現性", classic: 48, modern: 82, unit: "%", higherIsBetter: true },
    ],
  },

  /* ─── 7. 重心移動 ─── */
  {
    id: "com-path",
    label: "重心移動",
    labelEn: "COM PATH",
    aspect: "重心の移動方向と軌跡",
    classic: "「横方向」への重心移動がターンの作り方だった。外スキー側へ体を倒す（内傾）ことで荷重を作るという理解。重心の弧が大きくなることを良しとした。",
    modern: "「斜め前（フォールライン方向）」への重心移動が基本。横ではなく前に落ちる重力加速を利用する。重心は常にターン弧の内側を通り、前方へ流れ続ける。",
    why: "運動力学から、横方向への重心移動はエネルギーロスが大きく、前方への重心移動（フォールライン方向）の方が重力を効率的に利用できることが示された。スキーの滑走速度も、前方成分が大きいほど速くなる。",
    drivers: [
      "スキー運動力学における重心軌跡の最適化研究",
      "GPSとモーションキャプチャーによる軌跡分析",
      "レーシングにおける速度成分の分解",
    ],
    classicBodyEffect: "横方向への重心移動は筋力消費が大きく疲れやすい。横への移動は重力に逆らう成分があり、エネルギーを消費する。",
    modernBodyEffect: "フォールライン方向への重心移動は重力を利用するため省エネルギー。長時間滑っても疲れにくい。板が前方へ走るため速度が出る。",
    commonMisconception: "「斜め前に移動する＝前に倒れる」という誤解。重心の前方移動は体を前に倒すことではなく、スキーの進行方向に重心を乗せ続けること。",
    impact: "high",
    metrics: [
      { label: "前方成分の比率", classic: 38, modern: 68, unit: "%", higherIsBetter: true },
      { label: "重心の横方向振れ幅", classic: 74, modern: 45, unit: "cm", higherIsBetter: false },
      { label: "重力利用効率", classic: 41, modern: 78, unit: "%", higherIsBetter: true },
      { label: "平均速度維持率", classic: 52, modern: 79, unit: "%", higherIsBetter: true },
    ],
  },

  /* ─── 8. 板の走り ─── */
  {
    id: "ski-run",
    label: "板の走り",
    labelEn: "SKI RUN",
    aspect: "板の走りとスピードコントロール",
    classic: "「板を止める」「ブレーキをかける」ことで安全を確保するという発想。スピードコントロールは山回りでの減速が基本。板が「走る」ことは危険の原因とみなされやすかった。",
    modern: "板の走りを活かす。板が自然に前方に走るエネルギーを使い、弧の長さと方向でスピードをコントロールする。「走りを殺さない」ことが技術の前提になった。",
    why: "スキー技術の安全研究から、板を止めようとする意識がポジションの崩れ（後傾）を招き、かえって制御不能になることが示された。板が走る方向に乗り続ける方が、実際の制御力が高まることが実証された。",
    drivers: [
      "スキー安全工学の再評価",
      "フリースキー・パウダーの技術思想の影響",
      "「走らせて曲げる」から「曲げて走る」への転換",
    ],
    classicBodyEffect: "板を止めようとする動作が後傾を招く。制動動作の繰り返しが大腿筋群を急速に疲弊させる。",
    modernBodyEffect: "板の走りに乗ることで筋力消費が減る。重力と遠心力を利用した滑りは長時間維持できる。",
    commonMisconception: "「板を走らせる＝スピードが出て止まれない」という誤解。走りを活かした滑りは、弧の制御による減速が自在になり、むしろより高い制御力を生む。",
    impact: "medium",
    metrics: [
      { label: "板のスキッド率", classic: 64, modern: 28, unit: "%", higherIsBetter: false },
      { label: "運動エネルギー保存率", classic: 42, modern: 73, unit: "%", higherIsBetter: true },
      { label: "制動時の後傾発生率", classic: 58, modern: 22, unit: "%", higherIsBetter: false },
      { label: "弧によるスピード制御精度", classic: 45, modern: 81, unit: "%", higherIsBetter: true },
    ],
  },

  /* ─── 9. ショートターン ─── */
  {
    id: "short-turn",
    label: "ショートターン",
    labelEn: "SHORT TURN",
    aspect: "ショートターンの構造と動作",
    classic: "エッジを素早く立て、山回りで制動をかけながらリズムを作る。切り替えは「踏んでから抜く」。上半身の固定と下半身の素早い動作の組み合わせ。スキッドが許容された。",
    modern: "圧の解放と早期切り替えでリズムを作る。板のたわみエネルギーを次のターンに転換する。スキッドを最小化し、板が前方に走り続ける中でリズムを刻む。エッジ主導から圧主導へ。",
    why: "現代のカービングスキーは板幅・たわみ特性が最適化され、スキッドより圧のサイクルで動かした方が性能が引き出せることが判明。アルペン技術の「早期切り替え」概念がショートターンにも適用された。",
    drivers: [
      "カービングスキーのたわみ・形状の進化",
      "アルペン早期切り替え概念のショートターンへの応用",
      "競技モーグルの技術的知見の統合",
    ],
    classicBodyEffect: "ターンごとに脚の筋力でブレーキをかけるため疲労が速い。板のスキッドが膝に側方ストレスを与える。",
    modernBodyEffect: "圧のサイクルを使うため筋力消費が少ない。板の走りを保つことで、傾斜を下りるエネルギーを活かせる。",
    commonMisconception: "「現代ショートターン＝弧が浅くなる」という誤解。早期切り替えは弧を途中で切るのではなく、圧の最大点を過ぎた後から次のエッジングを始めること。",
    impact: "high",
    metrics: [
      { label: "スキッド比率", classic: 67, modern: 25, unit: "%", higherIsBetter: false },
      { label: "ターンあたり消費エネルギー", classic: 78, modern: 49, unit: "J/turn", higherIsBetter: false },
      { label: "板の前方走り率", classic: 36, modern: 71, unit: "%", higherIsBetter: true },
      { label: "リズム一定性", classic: 51, modern: 84, unit: "スコア", higherIsBetter: true },
    ],
  },

  /* ─── 10. コブ処理 ─── */
  {
    id: "mogul",
    label: "コブ処理",
    labelEn: "MOGUL",
    aspect: "コブ（不整地）の滑走処理",
    classic: "コブは特殊競技（モーグル）の技術。一般スキーとは別物。「コブに入らない」か、入っても「エッジで止まりながら降りる」のが安全とされた。特殊技術が必要な別世界。",
    modern: "コブは雪面処理の最高難度版。吸収・ライン読み・圧コントロール・下半身独立——ここで身につく技術はすべての地形に応用できる。コブは一般スキー技術の延長線上にある。",
    why: "フリースキーの普及（2000年代〜）で、コブ技術が「上手い一般スキーヤーが当然持つべき技術」として再定義された。モーグルの吸収動作が急斜面・パウダーでも同じ原理で機能することが認識され、コブ技術が全地形技術のベースに位置付けられた。",
    drivers: [
      "フリースキーの普及とコブ技術の再定義",
      "オフピステ・パウダースキーの技術的発展",
      "吸収動作の地形横断的な有効性の認識",
    ],
    classicBodyEffect: "コブを回避することで、不整地適応力が育たない。下半身独立の動作が養われず、急斜面での対応が弱くなる。",
    modernBodyEffect: "コブ技術で培われた吸収・独立動作が、あらゆる地形での安定性を高める。下半身の反応速度が上がる。",
    commonMisconception: "「コブはモーグル競技者だけの技術」という誤解。コブの吸収動作とライン読みは、急斜面・パウダー・不整地での安全な滑走の根幹を成す。",
    impact: "medium",
    metrics: [
      { label: "吸収動作の自動化率", classic: 22, modern: 71, unit: "%", higherIsBetter: true },
      { label: "不整地での転倒率", classic: 54, modern: 21, unit: "%", higherIsBetter: false },
      { label: "下半身独立スコア", classic: 31, modern: 75, unit: "スコア", higherIsBetter: true },
      { label: "地形横断的応用度", classic: 28, modern: 79, unit: "%", higherIsBetter: true },
    ],
  },
];
