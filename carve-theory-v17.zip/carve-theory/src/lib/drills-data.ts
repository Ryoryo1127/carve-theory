/**
 * CARVE THEORY — Drills Library Data
 * /drills/[slug] の詳細ページ用データ。
 * 記事サイドバー（ArticleSidebar）の relatedDrills から参照される。
 */

import type { Drill } from "@/components/article/DrillCards";

export interface DrillDetail extends Drill {
  slug: string;
  /** ドリルの短い紹介文（一覧・OGP用） */
  summary: string;
  /** 関連する記事slug */
  relatedArticleSlugs: string[];
}

export const DRILLS_LIBRARY: DrillDetail[] = [
  {
    slug: "outer-foot",
    number: 1,
    title: "外足荷重ドリル集",
    summary: "外足に乗る感覚を体に叩き込むための、片足スキーを中心としたドリル集。",
    duration: "5〜10分",
    terrain: "緩斜面",
    difficulty: 1,
    goal: "外足荷重の感覚を体に叩き込む。内足に頼れない状況を作る。",
    steps: [
      "内スキーを雪面からわずかに浮かせた状態で立つ",
      "外スキー一本でまっすぐ滑り出す",
      "外足一本で大きなターンを描く",
      "左右交互に10本ずつ行う",
    ],
    checkpoint: "外スキー一本で安定したターンができ、内足を浮かせたままシュプールが一本線になっている。",
    tip: "転ぶことを恐れない。転び方で何が間違いかわかる。転んで学ぶのがこのドリルの本質だ。",
    relatedArticleSlugs: ["carving-turn-complete", "pressure-control-practice"],
  },
  {
    slug: "schprur-check",
    number: 2,
    title: "シュプール診断の方法",
    summary: "自分のシュプール（滑走痕）を見て、何が起きていたかを逆算するためのセルフチェック法。",
    duration: "滑走後5分",
    terrain: "任意（圧雪バーン推奨）",
    difficulty: 1,
    goal: "感覚だけに頼らず、跡という客観的な証拠から自分の滑りを診断できるようになる。",
    steps: [
      "1本のターンを滑った後、すぐに振り返ってシュプールを確認する",
      "線が一本の細い弧になっているか、二本に分かれていないかを見る",
      "ターン後半でシュプールが太くなっていないか確認する（テール流しのサイン）",
      "写真に撮って数本分を比較する",
    ],
    checkpoint: "ターンの最初から最後まで、一本の細い線として弧が描けている。",
    tip: "感覚は誤魔化せるが、シュプールは誤魔化せない。練習の最後に必ず振り返る習慣をつける。",
    relatedArticleSlugs: ["carving-turn-complete", "edging-angle-strategy"],
  },
  {
    slug: "edging-basics",
    number: 3,
    title: "エッジングドリル基礎",
    summary: "エッジ角の作り方を、足首・膝ではなく体の傾きから理解するための基礎ドリル。",
    duration: "10〜15分",
    terrain: "緩斜面",
    difficulty: 1,
    goal: "エッジを「立てよう」とする意識を手放し、体の傾きの結果としてエッジが立つ感覚を作る。",
    steps: [
      "まっすぐ滑りながら、足首・膝を固定したまま体全体を傾ける",
      "傾きの大きさを変えて、エッジ角がどう変化するか感じる",
      "浅い角度・深い角度を交互に作り分ける",
      "雪質を変えて同じ練習を繰り返す",
    ],
    checkpoint: "足首・膝に力を入れずに、体の傾きだけでエッジ角を調整できている。",
    tip: "最初は「立てよう」とする癖が抜けない。傾けることだけに集中すると、エッジは勝手に立つ。",
    relatedArticleSlugs: ["edging-angle-strategy", "gs-turn-analysis"],
  },
];

export function getDrillBySlug(slug: string): DrillDetail | undefined {
  return DRILLS_LIBRARY.find((d) => d.slug === slug);
}
