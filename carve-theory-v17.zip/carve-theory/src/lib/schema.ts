/* =============================================================
   CARVE THEORY — JSON-LD Schema Builder Functions
   型安全・再利用可能なビルダー関数群。
   各ページの generateMetadata 付近で呼び出す。
   ============================================================= */

import { SITE_NAME, SITE_DESCRIPTION, SITE_URL } from "@/lib/constants";
import type { ArticleMeta } from "@/types";
import type {
  SchemaOrganization,
  SchemaPerson,
  SchemaWebSite,
  SchemaBreadcrumbList,
  BreadcrumbItem,
  SchemaArticle,
  ArticleType,
  SchemaVideoObject,
  SchemaClip,
  SchemaFAQPage,
  SchemaQAEntry,
  SchemaHowTo,
  SchemaHowToStep,
  SchemaItemList,
  SchemaCollectionPage,
  SchemaProfilePage,
  SchemaAbout,
  SchemaMention,
  SchemaGraph,
  AnySchema,
} from "@/types/schema";

/* ─────────────────────────────────────────────────────────────
   定数 — サイト共通
───────────────────────────────────────────────────────────── */

/** サイト発行者 Organization */
export const PUBLISHER: SchemaOrganization = {
  "@type": "Organization",
  "@id": `${SITE_URL}/#organization`,
  name: SITE_NAME,
  url: SITE_URL,
  logo: {
    "@type": "ImageObject",
    url: `${SITE_URL}/logo.png`,
    width: 512,
    height: 512,
  },
  description: SITE_DESCRIPTION,
  sameAs: [
    "https://twitter.com/carve_theory",
    // 追加SNSアカウントはここへ
  ],
};

/** デフォルト著者（仙人ペルソナ） */
export const DEFAULT_AUTHOR: SchemaPerson = {
  "@type": "Person",
  name: "仙人",
  url: `${SITE_URL}/about`,
  jobTitle: "スキー技術解説者・元競技スキーインストラクター",
  description:
    "全日本スキー技術選分析、アルペン競技経験者。スポーツバイオメカニクスの観点からスキー・スノーボード技術を体系的に解説。",
  sameAs: [],
};

/* ─────────────────────────────────────────────────────────────
   カテゴリ → about マッピング
   Googleに「このサイトが扱う専門領域」を伝えるための追加コンテキスト
───────────────────────────────────────────────────────────── */

const CATEGORY_ABOUT_MAP: Record<string, SchemaAbout[]> = {
  carving: [
    { "@type": "DefinedTerm", name: "カービングターン", description: "スキー板のサイドカーブを利用してエッジで雪面を切るターン技術" },
    { "@type": "DefinedTerm", name: "エッジング", description: "スキー板のエッジを雪面に対して角度をつけて接触させる技術" },
    { "@type": "SportsActivity", name: "アルペンスキー", sameAs: "https://en.wikipedia.org/wiki/Alpine_skiing" },
  ],
  "short-turn": [
    { "@type": "DefinedTerm", name: "ショートターン", description: "切り替えを速くしたリズミカルな連続小回りターン" },
    { "@type": "DefinedTerm", name: "切り替え", description: "ターンとターンの間のエッジ移行局面" },
  ],
  "long-turn": [
    { "@type": "DefinedTerm", name: "ロングターン", description: "大きな弧を描く大回りターン技術" },
  ],
  mogul: [
    { "@type": "DefinedTerm", name: "モーグル", description: "コブ（凹凸雪面）を滑走する技術" },
    { "@type": "SportsActivity", name: "フリースタイルスキー", sameAs: "https://en.wikipedia.org/wiki/Freestyle_skiing" },
  ],
  "off-piste": [
    { "@type": "DefinedTerm", name: "パウダースノー滑走", description: "不整地・深雪での滑走技術" },
  ],
  pressure: [
    { "@type": "DefinedTerm", name: "荷重", description: "スキー板への体重のかけ方とタイミング" },
    { "@type": "DefinedTerm", name: "プレッシャーコントロール", description: "ターン局面ごとの荷重・抜重の制御技術" },
  ],
  edging: [
    { "@type": "DefinedTerm", name: "エッジング", description: "スキー板のエッジ角制御技術" },
    { "@type": "DefinedTerm", name: "インクリネーション", description: "スキーヤーが雪面に対して体を傾ける動作" },
    { "@type": "DefinedTerm", name: "アンギュレーション", description: "腰や膝を横に折り曲げてエッジを立てる技術" },
  ],
  transition: [
    { "@type": "DefinedTerm", name: "切り替え", description: "ターンとターンの接続局面。エッジがフラットになる瞬間" },
  ],
  position: [
    { "@type": "DefinedTerm", name: "スキーポジション", description: "重心・骨盤・肩・膝の正しい位置関係" },
    { "@type": "DefinedTerm", name: "後傾", description: "重心が後方にずれるスキーヤーの失敗ポジション" },
  ],
  "technical-race": [
    { "@type": "DefinedTerm", name: "全日本スキー技術選手権", description: "スキーの技術を競う国内最高峰の競技" },
    { "@type": "SportsActivity", name: "スキー技術選", sameAs: "https://en.wikipedia.org/wiki/Alpine_skiing" },
  ],
  "alpine-analysis": [
    { "@type": "SportsActivity", name: "アルペンスキー競技", sameAs: "https://en.wikipedia.org/wiki/Alpine_skiing" },
    { "@type": "DefinedTerm", name: "大回転（GS）", description: "ジャイアントスラローム。旗門間隔が広い競技種目" },
    { "@type": "DefinedTerm", name: "回転（SL）", description: "スラローム。旗門間隔が狭い競技種目" },
  ],
  snowboard: [
    { "@type": "SportsActivity", name: "スノーボード", sameAs: "https://en.wikipedia.org/wiki/Snowboarding" },
    { "@type": "DefinedTerm", name: "ヒールサイドターン", description: "スノーボードのかかと側エッジを使うターン" },
    { "@type": "DefinedTerm", name: "トウサイドターン", description: "スノーボードのつま先側エッジを使うターン" },
  ],
};

/** カテゴリスラッグ → About配列を返す */
export function getCategoryAbout(category: string): SchemaAbout[] {
  return CATEGORY_ABOUT_MAP[category] ?? [];
}

/* ─────────────────────────────────────────────────────────────
   ISO 8601 ユーティリティ
───────────────────────────────────────────────────────────── */

/** 分数 → ISO 8601 Duration（例: 18 → "PT18M"） */
export function minutesToDuration(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h > 0 && m > 0) return `PT${h}H${m}M`;
  if (h > 0) return `PT${h}H`;
  return `PT${m}M`;
}

/** 秒数 → ISO 8601 Duration（例: 330 → "PT5M30S"） */
export function secondsToDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  const parts = [];
  if (h) parts.push(`${h}H`);
  if (m) parts.push(`${m}M`);
  if (s || !parts.length) parts.push(`${s}S`);
  return `PT${parts.join("")}`;
}

/** LevelType → educationalLevel文字列 */
const LEVEL_TO_EDUCATIONAL: Record<string, string> = {
  初級: "Beginner",
  中級: "Intermediate",
  上級: "Advanced",
  競技: "Expert",
};

export function levelToEducational(level: string): string {
  return LEVEL_TO_EDUCATIONAL[level] ?? "Intermediate";
}

/* ─────────────────────────────────────────────────────────────
   1. WebSite + SearchAction（サイトグローバル）
───────────────────────────────────────────────────────────── */

export function buildWebSiteSchema(): SchemaWebSite {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${SITE_URL}/#website`,
    name: SITE_NAME,
    url: SITE_URL,
    description: SITE_DESCRIPTION,
    publisher: PUBLISHER,
    inLanguage: "ja",
    potentialAction: {
      "@type": "SearchAction",
      target: {
        "@type": "EntryPoint",
        urlTemplate: `${SITE_URL}/search?q={search_term_string}`,
      },
      "query-input": "required name=search_term_string",
    },
  };
}

/* ─────────────────────────────────────────────────────────────
   2. BreadcrumbList
───────────────────────────────────────────────────────────── */

export interface BreadcrumbInput {
  name: string;
  href: string;
}

export function buildBreadcrumbSchema(
  crumbs: BreadcrumbInput[]
): SchemaBreadcrumbList {
  const items: BreadcrumbItem[] = crumbs.map((c, i) => ({
    "@type": "ListItem",
    position: i + 1,
    name: c.name,
    item: c.href.startsWith("http") ? c.href : `${SITE_URL}${c.href}`,
  }));

  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items,
  };
}

/* ─────────────────────────────────────────────────────────────
   3. Article / TechArticle（記事ページ）
───────────────────────────────────────────────────────────── */

export interface ArticleSchemaOptions {
  article: ArticleMeta;
  /** 追加のmention（選手名など） */
  mentions?: SchemaMention[];
  /** 記事本文の文字数 */
  wordCount?: number;
  /** 記事タイプ（デフォルト: TechArticle） */
  articleType?: ArticleType;
}

export function buildArticleSchema(opts: ArticleSchemaOptions): SchemaArticle {
  const { article, mentions, wordCount, articleType = "TechArticle" } = opts;
  const url = `${SITE_URL}/articles/${article.slug}`;
  const dateModified = article.updatedAt ?? article.publishedAt;

  /* カテゴリに対応するセクション名（英語） */
  const sectionMap: Record<string, string> = {
    carving: "Carving Technique",
    "short-turn": "Short Turn",
    "long-turn": "Long Turn",
    mogul: "Mogul / Bumps",
    "off-piste": "Off-Piste",
    pressure: "Pressure Control",
    edging: "Edging",
    transition: "Transition",
    position: "Body Position",
    "technical-race": "Technical Race Analysis",
    "alpine-analysis": "Alpine Racing Analysis",
    snowboard: "Snowboard Technique",
  };

  return {
    "@context": "https://schema.org",
    "@type": articleType,
    "@id": `${url}#article`,
    headline: article.title,
    description: article.excerpt,
    url,
    datePublished: article.publishedAt,
    dateModified,
    author: DEFAULT_AUTHOR,
    publisher: PUBLISHER,
    image: article.coverImage
      ? {
          "@type": "ImageObject",
          url: article.coverImage,
          width: 1200,
          height: 630,
        }
      : {
          "@type": "ImageObject",
          url: `${SITE_URL}/og-image.png`,
          width: 1200,
          height: 630,
        },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": url,
    },
    articleSection: sectionMap[article.category] ?? article.category,
    keywords: article.tags,
    wordCount,
    timeRequired: minutesToDuration(article.readTime),
    educationalLevel: levelToEducational(article.level),
    learningResourceType: "Article",
    teaches: article.tags,
    about: getCategoryAbout(article.category),
    mentions,
    isPartOf: {
      "@type": "WebSite",
      "@id": `${SITE_URL}/#website`,
    },
    inLanguage: "ja",
    speakable: {
      "@type": "SpeakableSpecification",
      cssSelector: ["h1.article-title", "p.article-excerpt", ".prose h2"],
    },
  };
}

/* ─────────────────────────────────────────────────────────────
   4. VideoObject（動画埋め込みコンポーネントと1:1対応）
───────────────────────────────────────────────────────────── */

export interface VideoSchemaInput {
  videoId: string;
  title: string;
  description: string;
  uploadDate: string;
  /** ISO 8601 duration。例: "PT5M30S" */
  duration?: string;
  /** 動画の注目ポイント（SchemaClip） */
  checkpoints?: {
    name: string;
    /** "0:32" or "1:15" 形式 → 秒数に変換 */
    timeString: string;
  }[];
  /** この動画が教える技術 */
  teaches?: string[];
  educationalLevel?: string;
  /** 関連するカテゴリ */
  category?: string;
  /** 記事URLの断片（isPartOf用） */
  articleId?: string;
}

/** "M:SS" or "MM:SS" → seconds */
function timeStringToSeconds(time: string): number {
  const parts = time.split(":").map(Number);
  if (parts.length === 2) return (parts[0] ?? 0) * 60 + (parts[1] ?? 0);
  if (parts.length === 3)
    return (parts[0] ?? 0) * 3600 + (parts[1] ?? 0) * 60 + (parts[2] ?? 0);
  return 0;
}

export function buildVideoSchema(input: VideoSchemaInput): SchemaVideoObject {
  const embedUrl = `https://www.youtube.com/embed/${input.videoId}`;
  const thumbnailUrl = [
    `https://img.youtube.com/vi/${input.videoId}/maxresdefault.jpg`,
    `https://img.youtube.com/vi/${input.videoId}/hqdefault.jpg`,
  ];

  const hasPart: SchemaClip[] | undefined =
    input.checkpoints && input.checkpoints.length > 0
      ? input.checkpoints.map((cp) => ({
          "@type": "Clip" as const,
          name: cp.name,
          startOffset: timeStringToSeconds(cp.timeString),
          url: `${embedUrl}?start=${timeStringToSeconds(cp.timeString)}`,
        }))
      : undefined;

  return {
    "@context": "https://schema.org",
    "@type": "VideoObject",
    "@id": `${SITE_URL}/#video-${input.videoId}`,
    name: input.title,
    description: input.description,
    thumbnailUrl,
    uploadDate: input.uploadDate,
    duration: input.duration,
    embedUrl,
    publisher: PUBLISHER,
    teaches: input.teaches,
    educationalLevel: input.educationalLevel,
    learningResourceType: "Video",
    about: input.category ? getCategoryAbout(input.category) : undefined,
    hasPart,
    inLanguage: "ja",
    isPartOf: input.articleId ? { "@id": input.articleId } : undefined,
  };
}

/* ─────────────────────────────────────────────────────────────
   5. FAQPage（Q&A / よくある失敗・よくある質問）
───────────────────────────────────────────────────────────── */

export interface FAQInput {
  question: string;
  answer: string;
}

export function buildFAQSchema(
  pageId: string,
  faqs: FAQInput[],
  name: string,
  description?: string
): SchemaFAQPage {
  const mainEntity: SchemaQAEntry[] = faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  }));

  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "@id": `${pageId}#faq`,
    name,
    description,
    mainEntity,
    isPartOf: { "@id": `${SITE_URL}/#website` },
  };
}

/* ─────────────────────────────────────────────────────────────
   6. HowTo（ドリルカード群）
───────────────────────────────────────────────────────────── */

export interface HowToInput {
  pageId: string;
  name: string;
  description: string;
  totalMinutes?: number;
  tools?: string[];
  steps: { name: string; text: string }[];
  teaches?: string[];
  educationalLevel?: string;
  category?: string;
}

export function buildHowToSchema(input: HowToInput): SchemaHowTo {
  const steps: SchemaHowToStep[] = input.steps.map((s, i) => ({
    "@type": "HowToStep",
    name: s.name,
    text: s.text,
    position: i + 1,
  }));

  return {
    "@context": "https://schema.org",
    "@type": "HowTo",
    "@id": `${input.pageId}#howto`,
    name: input.name,
    description: input.description,
    totalTime: input.totalMinutes
      ? minutesToDuration(input.totalMinutes)
      : undefined,
    tool: input.tools?.map((t) => ({
      "@type": "HowToTool" as const,
      name: t,
    })),
    step: steps,
    teaches: input.teaches,
    educationalLevel: input.educationalLevel,
    about: input.category ? getCategoryAbout(input.category) : undefined,
    isPartOf: { "@id": `${SITE_URL}/#website` },
  };
}

/* ─────────────────────────────────────────────────────────────
   7. ItemList（記事一覧・カテゴリ内記事一覧）
───────────────────────────────────────────────────────────── */

export function buildItemListSchema(
  id: string,
  name: string,
  items: { name: string; url: string; description?: string }[],
  description?: string
): SchemaItemList {
  return {
    "@context": "https://schema.org",
    "@type": "ItemList",
    "@id": id,
    name,
    description,
    numberOfItems: items.length,
    itemListElement: items.map((item, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: item.name,
      url: item.url.startsWith("http") ? item.url : `${SITE_URL}${item.url}`,
      description: item.description,
    })),
  };
}

/* ─────────────────────────────────────────────────────────────
   8. CollectionPage（カテゴリページ）
───────────────────────────────────────────────────────────── */

export function buildCollectionPageSchema(opts: {
  slug: string;
  name: string;
  description: string;
  articles: ArticleMeta[];
  /** URLのベースパス。省略時は "categories"（後方互換） */
  basePath?: string;
}): SchemaCollectionPage {
  const basePath = opts.basePath ?? "categories";
  const url = `${SITE_URL}/${basePath}/${opts.slug}`;
  return {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "@id": `${url}#collection`,
    name: opts.name,
    description: opts.description,
    url,
    publisher: PUBLISHER,
    mainEntity: buildItemListSchema(
      `${url}#itemlist`,
      `${opts.name}の技術記事`,
      opts.articles.map((a) => ({
        name: a.title,
        url: `/articles/${a.slug}`,
        description: a.excerpt,
      }))
    ),
    inLanguage: "ja",
    about: basePath === "categories" ? getCategoryAbout(opts.slug) : undefined,
  };
}

/* ─────────────────────────────────────────────────────────────
   9. ProfilePage（選手分析ページ）
───────────────────────────────────────────────────────────── */

export function buildProfilePageSchema(opts: {
  players: { name: string; discipline: string }[];
}): SchemaProfilePage {
  const url = `${SITE_URL}/players`;
  return {
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    "@id": `${url}#profilepage`,
    name: "選手分析 | CARVE THEORY",
    description:
      "技術選・アルペン・スノーボードのトップ選手を技術的に分析。どこが違うのか、なぜ安定して見えるのかを身体動作レベルで解説。",
    url,
    publisher: PUBLISHER,
    mainEntity: buildItemListSchema(
      `${url}#itemlist`,
      "選手分析一覧",
      opts.players.map((p) => ({
        name: p.name,
        url: `/players`,
        description: p.discipline,
      }))
    ),
    inLanguage: "ja",
  };
}

/* ─────────────────────────────────────────────────────────────
   9.5. Service（B2B提案ページ用）
───────────────────────────────────────────────────────────── */

import type { SchemaService } from "@/types/schema";

export function buildServiceSchema(opts: {
  name: string;
  description: string;
  serviceType: string;
  offerings: { name: string; description: string }[];
}): SchemaService {
  const url = `${SITE_URL}/for-schools`;
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    "@id": `${url}#service`,
    name: opts.name,
    description: opts.description,
    url,
    provider: PUBLISHER,
    serviceType: opts.serviceType,
    areaServed: "JP",
    audience: {
      "@type": "BusinessAudience",
      name: "スキー・スノーボードスクール、指導者育成団体",
    },
    hasOfferCatalog: {
      "@type": "OfferCatalog",
      name: "提供メニュー",
      itemListElement: opts.offerings.map((o) => ({
        "@type": "Offer" as const,
        itemOffered: {
          "@type": "Service" as const,
          name: o.name,
          description: o.description,
        },
      })),
    },
    inLanguage: "ja",
  };
}

/* ─────────────────────────────────────────────────────────────
   9.6. AboutPage（Aboutページ用 — ProfilePage + Person）
───────────────────────────────────────────────────────────── */

export function buildAboutPageSchema(): SchemaProfilePage {
  const url = `${SITE_URL}/about`;
  return {
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    "@id": `${url}#profilepage`,
    name: `このサイトについて | ${SITE_NAME}`,
    description: DEFAULT_AUTHOR.description ?? SITE_DESCRIPTION,
    url,
    publisher: PUBLISHER,
    mainEntity: DEFAULT_AUTHOR,
    inLanguage: "ja",
  };
}

/* ─────────────────────────────────────────────────────────────
   10. Graph builder（複数スキーマをまとめて1つの<script>に）
───────────────────────────────────────────────────────────── */

/**
 * 複数のスキーマをJSON-LD @graph 形式にまとめる。
 * @context は外側に1つだけ置かれる。
 */
export function buildSchemaGraph(schemas: AnySchema[]): SchemaGraph {
  const graphItems = schemas.map((s) => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const obj = s as any;
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { "@context": _ctx, ...rest } = obj as Record<string, unknown>;
    return rest as Omit<AnySchema, "@context">;
  });

  return {
    "@context": "https://schema.org",
    "@graph": graphItems,
  };
}

/* ─────────────────────────────────────────────────────────────
   11. 記事ページ用FAQ（失敗パターン → FAQ自動生成）
───────────────────────────────────────────────────────────── */

export interface FailurePatternInput {
  name: string;
  cause: string;
  fix: string;
}

/**
 * 失敗パターンデータからFAQ schemaを自動生成する。
 * "なぜ〜になるのか" / "どうすれば〜を直せるか" の形式で出力。
 */
export function buildFailureFAQSchema(
  pageId: string,
  patterns: FailurePatternInput[],
  articleTitle: string
): SchemaFAQPage {
  const faqs = patterns.flatMap((p) => [
    {
      question: `スキーで${p.name}になる原因は何ですか？`,
      answer: p.cause,
    },
    {
      question: `${p.name}を直すにはどうすればいいですか？`,
      answer: p.fix,
    },
  ]);

  return buildFAQSchema(
    pageId,
    faqs,
    `${articleTitle}に関するよくある失敗と修正法`,
    `${articleTitle}でよく起きる失敗パターンの原因と修正法をQ&A形式で解説します。`
  );
}

/* ─────────────────────────────────────────────────────────────
   12. 記事ページ用ドリル → HowTo自動生成
───────────────────────────────────────────────────────────── */

export interface DrillInput {
  title: string;
  goal: string;
  steps: string[];
  duration?: string;
  terrain?: string;
}

/**
 * ドリルデータからHowTo schemaを自動生成する。
 * 複数ドリルがある場合は最初のドリルをメインにする。
 */
export function buildDrillHowToSchema(
  pageId: string,
  drills: DrillInput[],
  articleTitle: string,
  category?: string,
  educationalLevel?: string
): SchemaHowTo {
  const firstDrill = drills[0];
  if (!firstDrill) {
    return buildHowToSchema({
      pageId,
      name: `${articleTitle} — 練習ドリル`,
      description: `${articleTitle}を習得するための練習ドリル。`,
      steps: [],
      category,
      educationalLevel,
    });
  }

  // 複数ドリルをまとめて1つのHowToにする
  const allSteps = drills.flatMap((d, di) =>
    d.steps.map((s) => ({
      name: `[ドリル${di + 1}: ${d.title}] ${s.slice(0, 30)}`,
      text: s,
    }))
  );

  return buildHowToSchema({
    pageId,
    name: `${articleTitle} — 修正ドリル集`,
    description: drills.map((d) => d.goal).join("。"),
    tools: ["スキー板", "スキーブーツ", "ストック"],
    steps: allSteps,
    teaches: drills.map((d) => d.title),
    educationalLevel,
    category,
  });
}
