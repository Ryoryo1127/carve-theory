import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, parseISO } from "date-fns";
import { ja } from "date-fns/locale";
import type { LevelType, RouteType, CategorySlug } from "@/types";
import { CATEGORIES } from "./constants";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateString: string): string {
  return format(parseISO(dateString), "yyyy年M月d日", { locale: ja });
}

export const LEVEL_COLORS: Record<LevelType, string> = {
  入門: "bg-sky-500/20 text-sky-400 border-sky-500/30",
  初級: "bg-green-500/20 text-green-400 border-green-500/30",
  中級: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  上級: "bg-red-500/20 text-red-400 border-red-500/30",
  競技: "bg-purple-500/20 text-purple-400 border-purple-500/30",
};

export const LEVEL_DOT: Record<LevelType, string> = {
  入門: "bg-sky-400",
  初級: "bg-green-400",
  中級: "bg-yellow-400",
  上級: "bg-red-400",
  競技: "bg-purple-400",
};

export const ROUTE_COLORS: Record<RouteType, string> = {
  スキー: "bg-white/10 text-white/80 border-white/20",
  技術選: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  アルペン: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  スノーボード: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  モーグル: "bg-red-500/20 text-red-400 border-red-500/30",
  フリースキー: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30",
};

export function getCategoryBySlug(slug: CategorySlug) {
  return CATEGORIES.find((c) => c.slug === slug);
}

export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength).trimEnd() + "…";
}

export function estimateReadTime(content: string): number {
  const wordsPerMinute = 500;
  const charCount = content.replace(/\s/g, "").length;
  return Math.max(1, Math.ceil(charCount / wordsPerMinute));
}

export function extractHeadings(content: string) {
  const headingRegex = /^(#{2,3})\s+(.+)$/gm;
  const headings: { id: string; text: string; depth: number }[] = [];
  let match;
  while ((match = headingRegex.exec(content)) !== null) {
    const depth = match[1].length;
    const text = match[2].trim();
    const id = text
      .toLowerCase()
      .replace(/[^a-z0-9\u3040-\u9fff\u30a0-\u30ff\u4e00-\u9fff]/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "");
    headings.push({ id, text, depth });
  }
  return headings;
}

export function fuzzySearch<T extends { title: string; excerpt: string; tags: string[] }>(
  items: T[],
  query: string
): T[] {
  if (!query.trim()) return items;
  const q = query.toLowerCase();
  return items
    .filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.excerpt.toLowerCase().includes(q) ||
        item.tags.some((t) => t.toLowerCase().includes(q))
    )
    .sort((a, b) => {
      const aTitle = a.title.toLowerCase().includes(q) ? 1 : 0;
      const bTitle = b.title.toLowerCase().includes(q) ? 1 : 0;
      return bTitle - aTitle;
    });
}
