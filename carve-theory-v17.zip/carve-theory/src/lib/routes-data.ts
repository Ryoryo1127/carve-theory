/**
 * CARVE THEORY — Routes Data
 * レベル・種目ごとの「学習ルート」定義。
 * トップページのLevelSelectorとFooterから参照される。
 */

import type { LevelType, RouteType } from "@/types";

export interface RouteDefinition {
  slug: string;
  title: string;
  subtitle: string;
  description: string;
  color: string;
  /** このルートに合致するレベル（参考表示用） */
  targetLevels?: LevelType[];
  /** このルートに合致する種目（参考表示用） */
  targetRoutes?: RouteType[];
  /** 推奨する記事slugを順番に並べたもの */
  recommendedSlugs: string[];
}

export const ROUTES_DATA: RouteDefinition[] = [
  {
    slug: "beginner",
    title: "初心者ルート",
    subtitle: "入門・初級",
    description:
      "まずは基本姿勢と荷重の感覚を作る。複雑な技術より先に、低重心という土台を体に入れることが最初の課題になる。",
    color: "#4ade80",
    targetLevels: ["入門", "初級"],
    recommendedSlugs: [
      "carving-basics-for-beginners",
      "pressure-sensing-fundamentals",
      "low-com-position-building",
      "carving-turn-complete",
    ],
  },
  {
    slug: "intermediate",
    title: "中級者ルート",
    subtitle: "壁を超える",
    description:
      "「なんとなく滑れる」から一段上に行くための技術更新。エッジ主導から圧主導へ、横移動から斜め前への重心移動へ。理解の転換が必要な局面。",
    color: "#facc15",
    targetLevels: ["中級"],
    recommendedSlugs: [
      "short-turn-modern",
      "short-turn-rhythm-drills",
      "edging-angle-strategy",
      "position-common-mistakes",
      "transition-deep-dive",
      "long-turn-modern",
    ],
  },
  {
    slug: "technical",
    title: "技術選ルート",
    subtitle: "2026年採点対応",
    description:
      "技術選で評価される滑りは変わった。「頑張って見える」滑りではなく、自然な運動連鎖と圧の流れが評価基準の中心になっている。",
    color: "#f87171",
    targetRoutes: ["技術選"],
    recommendedSlugs: [
      "tech-comp-scoring",
      "modern-technique-overview",
      "short-turn-modern",
    ],
  },
  {
    slug: "alpine",
    title: "アルペンルート",
    subtitle: "競技技術",
    description:
      "W杯選手の滑りは、一般スキーヤーとは別世界の話ではない。早期エッジング・低重心・圧の流れ——速度を抜きにすれば、原理はそのまま応用できる。",
    color: "#60a5fa",
    targetRoutes: ["アルペン"],
    recommendedSlugs: [
      "gs-turn-analysis",
      "edging-angle-strategy",
      "ski-biomechanics-intro",
    ],
  },
  {
    slug: "mogul",
    title: "コブ・地形ルート",
    subtitle: "雪面処理",
    description:
      "コブは特殊競技ではない。雪面処理の最高難度版だ。吸収・ライン読み・下半身独立——ここで身につく技術は全地形に応用できる。",
    color: "#f87171",
    targetRoutes: ["モーグル"],
    recommendedSlugs: [
      "mogul-terrain-processing",
      "mogul-competition-format",
      "terrain-adaptation-guide",
      "off-piste-intro",
    ],
  },
  {
    slug: "snowboard",
    title: "スノボルート",
    subtitle: "種目共通原理",
    description:
      "スキーとスノーボードは道具こそ違うが、雪面から力を受け取る原理は共通している。種目を超えて使える技術の軸を理解する。",
    color: "#a78bfa",
    targetRoutes: ["スノーボード"],
    recommendedSlugs: [
      "snowboard-shared-principles",
      "snowboard-carving-technique",
      "edging-angle-strategy",
      "pressure-control-practice",
    ],
  },
];

export function getRouteBySlug(slug: string): RouteDefinition | undefined {
  return ROUTES_DATA.find((r) => r.slug === slug);
}
