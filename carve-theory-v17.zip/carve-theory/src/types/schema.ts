/* =============================================================
   CARVE THEORY — JSON-LD Schema Type Definitions
   Schema.org準拠の完全型定義。型安全なビルダー関数と組み合わせて使う。
   ============================================================= */

/* ─── 共通プリミティブ ─── */

export interface SchemaImage {
  "@type": "ImageObject";
  url: string;
  width?: number;
  height?: number;
  caption?: string;
}

export interface SchemaPerson {
  "@type": "Person";
  name: string;
  url?: string;
  image?: SchemaImage;
  jobTitle?: string;
  description?: string;
  sameAs?: string[];
}

export interface SchemaOrganization {
  "@type": "Organization";
  "@id": string;
  name: string;
  url: string;
  logo?: SchemaImage;
  sameAs?: string[];
  description?: string;
}

export interface SchemaWebSite {
  "@context": "https://schema.org";
  "@type": "WebSite";
  "@id": string;
  name: string;
  url: string;
  description: string;
  publisher: SchemaOrganization;
  potentialAction?: SchemaSearchAction;
  inLanguage: string;
}

export interface SchemaSearchAction {
  "@type": "SearchAction";
  target: {
    "@type": "EntryPoint";
    urlTemplate: string;
  };
  "query-input": string;
}

/* ─── BreadcrumbList ─── */

export interface BreadcrumbItem {
  "@type": "ListItem";
  position: number;
  name: string;
  item: string;
}

export interface SchemaBreadcrumbList {
  "@context": "https://schema.org";
  "@type": "BreadcrumbList";
  itemListElement: BreadcrumbItem[];
}

/* ─── Article ─── */

export type ArticleType =
  | "Article"
  | "TechArticle"
  | "HowTo"
  | "NewsArticle";

export interface SchemaArticle {
  "@context": "https://schema.org";
  "@type": ArticleType;
  "@id": string;
  headline: string;
  description: string;
  url: string;
  datePublished: string;
  dateModified: string;
  author: SchemaPerson;
  publisher: SchemaOrganization;
  image?: SchemaImage;
  mainEntityOfPage: {
    "@type": "WebPage";
    "@id": string;
  };
  articleSection: string;
  keywords: string[];
  wordCount?: number;
  timeRequired?: string; // ISO 8601 duration e.g. "PT18M"
  educationalLevel?: string;
  learningResourceType?: string;
  teaches?: string[];
  /** スキー技術固有の追加フィールド */
  about?: SchemaAbout[];
  mentions?: SchemaMention[];
  isPartOf?: {
    "@type": "WebSite";
    "@id": string;
  };
  inLanguage: string;
  speakable?: {
    "@type": "SpeakableSpecification";
    cssSelector: string[];
  };
}

export interface SchemaAbout {
  "@type": "Thing" | "SportsActivity" | "DefinedTerm";
  name: string;
  description?: string;
  sameAs?: string;
}

export interface SchemaMention {
  "@type": "Person" | "Thing" | "SportsTeam";
  name: string;
  sameAs?: string;
}

/* ─── VideoObject ─── */

export interface SchemaVideoObject {
  "@context": "https://schema.org";
  "@type": "VideoObject";
  "@id": string;
  name: string;
  description: string;
  thumbnailUrl: string[];
  uploadDate: string;
  duration?: string; // ISO 8601 e.g. "PT5M30S"
  contentUrl?: string;
  embedUrl: string;
  publisher: SchemaOrganization;
  /** 技術解説動画向け */
  teaches?: string[];
  educationalLevel?: string;
  learningResourceType?: string;
  about?: SchemaAbout[];
  /** 注目ポイントをClipとして */
  hasPart?: SchemaClip[];
  inLanguage: string;
  isPartOf?: { "@id": string };
}

export interface SchemaClip {
  "@type": "Clip";
  name: string;
  startOffset: number; // seconds
  endOffset?: number;
  url?: string;
}

/* ─── FAQPage ─── */

export interface SchemaQAEntry {
  "@type": "Question";
  name: string;
  acceptedAnswer: {
    "@type": "Answer";
    text: string;
  };
}

export interface SchemaFAQPage {
  "@context": "https://schema.org";
  "@type": "FAQPage";
  "@id": string;
  name: string;
  description?: string;
  mainEntity: SchemaQAEntry[];
  isPartOf?: { "@id": string };
}

/* ─── HowTo（ドリル用） ─── */

export interface SchemaHowToStep {
  "@type": "HowToStep";
  name: string;
  text: string;
  position: number;
  url?: string;
}

export interface SchemaHowToTool {
  "@type": "HowToTool";
  name: string;
}

export interface SchemaHowTo {
  "@context": "https://schema.org";
  "@type": "HowTo";
  "@id": string;
  name: string;
  description: string;
  totalTime?: string;
  tool?: SchemaHowToTool[];
  step: SchemaHowToStep[];
  educationalLevel?: string;
  teaches?: string[];
  about?: SchemaAbout[];
  isPartOf?: { "@id": string };
}

/* ─── ItemList（カテゴリ/一覧ページ用） ─── */

export interface SchemaListItem {
  "@type": "ListItem";
  position: number;
  name: string;
  url: string;
  description?: string;
}

export interface SchemaItemList {
  "@context": "https://schema.org";
  "@type": "ItemList";
  "@id": string;
  name: string;
  description?: string;
  numberOfItems: number;
  itemListElement: SchemaListItem[];
}

/* ─── CollectionPage（カテゴリページ用） ─── */

export interface SchemaCollectionPage {
  "@context": "https://schema.org";
  "@type": "CollectionPage";
  "@id": string;
  name: string;
  description: string;
  url: string;
  breadcrumb?: SchemaBreadcrumbList;
  mainEntity?: SchemaItemList;
  publisher: SchemaOrganization;
  inLanguage: string;
  about?: SchemaAbout[];
}

/* ─── Service（B2B提案ページ用） ─── */

export interface SchemaOfferCatalog {
  "@type": "OfferCatalog";
  name: string;
  itemListElement: {
    "@type": "Offer";
    itemOffered: {
      "@type": "Service";
      name: string;
      description: string;
    };
  }[];
}

export interface SchemaService {
  "@context": "https://schema.org";
  "@type": "Service";
  "@id": string;
  name: string;
  description: string;
  url: string;
  provider: SchemaOrganization;
  serviceType: string;
  areaServed?: string;
  audience?: {
    "@type": "BusinessAudience" | "EducationalAudience";
    name: string;
  };
  hasOfferCatalog?: SchemaOfferCatalog;
  inLanguage: string;
}

/* ─── ProfilePage（選手分析ページ用） ─── */

export interface SchemaProfilePage {
  "@context": "https://schema.org";
  "@type": "ProfilePage";
  "@id": string;
  name: string;
  description: string;
  url: string;
  publisher: SchemaOrganization;
  mainEntity?: SchemaItemList | SchemaPerson;
  inLanguage: string;
}

/* ─── Graph（複数スキーマをまとめてinject用） ─── */

export type AnySchema =
  | SchemaWebSite
  | SchemaArticle
  | SchemaBreadcrumbList
  | SchemaVideoObject
  | SchemaFAQPage
  | SchemaHowTo
  | SchemaItemList
  | SchemaCollectionPage
  | SchemaProfilePage
  | SchemaService;

export interface SchemaGraph {
  "@context": "https://schema.org";
  "@graph": Omit<AnySchema, "@context">[];
}
