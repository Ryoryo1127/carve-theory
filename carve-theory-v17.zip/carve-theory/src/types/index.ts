/* ============================================================
   CARVE THEORY v2 — Type Definitions
   2026年版。現代スキー技術を前提とした型体系。
   ============================================================ */

export type RouteType =
  | "スキー"
  | "技術選"
  | "アルペン"
  | "スノーボード"
  | "モーグル"
  | "フリースキー";

export type LevelType = "入門" | "初級" | "中級" | "上級" | "競技";

/** 技術的な時代区分 */
export type TechEra = "classic" | "modern"; // 〜2018年 vs 2019年〜

export type CategorySlug =
  /* ── コア技術 ── */
  | "carving"
  | "short-turn"
  | "long-turn"
  | "transition"
  | "pressure"
  | "edging"
  | "position"
  /* ── 地形・雪面 ── */
  | "mogul-analysis"      // コブ・モーグル（雪面処理として統合）
  | "terrain-adaptation"  // 地形適応（不整地・急斜面・パウダー）
  | "off-piste"
  /* ── 競技分析 ── */
  | "technical-race"
  | "alpine-analysis"
  /* ── 現代技術 ── */
  | "modern-technique"    // 2022年以降の技術変化
  | "ski-biomechanics"    // バイオメカニクス・運動科学
  /* ── 種目 ── */
  | "snowboard";

export interface Category {
  slug: CategorySlug;
  label: string;
  labelEn: string;
  description: string;
  color: string;
  /** 2026年時点の重要度 */
  priority?: "core" | "emerging" | "specialist";
  /** カテゴリグループ */
  group?: "technique" | "terrain" | "competition" | "science" | "board";
}

export interface Tag {
  slug: string;
  label: string;
  /** 現代技術タグかどうか */
  isModern?: boolean;
}

export interface ArticleMeta {
  slug: string;
  title: string;
  subtitle: string;
  excerpt: string;
  category: CategorySlug;
  tags: string[];
  route: RouteType;
  level: LevelType;
  readTime: number;
  publishedAt: string;
  updatedAt?: string;
  featured: boolean;
  coverImage?: string;
  author?: string;
  /** この記事が扱う時代 */
  era?: TechEra | "both";
  /** 現代技術更新済みか */
  modernUpdated?: boolean;
}

export interface Article extends ArticleMeta {
  content: string;
  headings: Heading[];
  relatedSlugs: string[];
}

export interface Heading {
  id: string;
  text: string;
  depth: number;
}

/** 2010年代 vs 2022年以降 の技術比較エントリ */
export interface TechEraComparison {
  aspect: string;
  classic: string;   // 〜2018年の理解・指導
  modern: string;    // 2022年以降の理解・実際
  why: string;       // なぜ変化したか
  impact: "high" | "medium" | "low";
}

/** モーグル雪面処理の分析フレーム */
export interface MogulLineAnalysis {
  phase: "approach" | "absorption" | "contact" | "extension" | "exit";
  label: string;
  description: string;
  bodyFocus: string;
  pressureState: "loading" | "neutral" | "releasing";
}

export interface Player {
  id: string;
  name: string;
  nameEn: string;
  nationality: string;
  discipline: string;
  route: RouteType;
  color: string;
  signature: string;
  traits: PlayerTrait[];
  articles: string[];
  /** 現代技術の特徴的な点 */
  modernTraits?: string[];
  era?: "active" | "reference";
}

export interface PlayerTrait {
  label: string;
  value: number;
  description: string;
}

export interface SnowCondition {
  slug: string;
  label: string;
  description: string;
  icon: string;
  tips: string[];
  difficulty: 1 | 2 | 3 | 4 | 5;
  /** 現代的な対処アプローチ */
  modernApproach?: string;
}

export interface TechPrinciple {
  id: string;
  title: string;
  titleEn: string;
  description: string;
  articleSlugs: string[];
  /** 2026年版の更新ポイント */
  modernNote?: string;
}

export interface SearchResult {
  slug: string;
  title: string;
  excerpt: string;
  category: CategorySlug;
  level: LevelType;
  score: number;
}

/** ナビゲーション構造 */
export interface NavGroup {
  label: string;
  labelEn: string;
  items: { label: string; href: string; description?: string; badge?: string }[];
}

/* ─── 比較分析UI専用拡張型 ─── */

export type ComparisonTopic =
  | "angulation"    // 外向傾
  | "pressure"      // 荷重
  | "transition"    // 切り替え
  | "position"      // ポジション
  | "upper-body"    // 上半身
  | "edging"        // エッジング
  | "com-path"      // 重心移動
  | "ski-run"       // 板の走り
  | "short-turn"    // ショートターン
  | "mogul";        // コブ処理

export interface TechEraDetail extends TechEraComparison {
  /** URL-safeなID */
  id: ComparisonTopic;
  /** 短いラベル（タブ表示用） */
  label: string;
  /** サブラベル（英語） */
  labelEn: string;
  /** 変化を引き起こした外部要因 */
  drivers: string[];
  /** 身体への影響（旧技術） */
  classicBodyEffect: string;
  /** 身体への影響（現代技術） */
  modernBodyEffect: string;
  /** キーメトリクス比較 */
  metrics: {
    label: string;
    classic: number;   // 0–100 スケール
    modern: number;
    unit?: string;
    higherIsBetter?: boolean; // trueなら高い方が良い
  }[];
  /** 実践での誤解されやすい点 */
  commonMisconception: string;
}
