// Re-export types used in article component props
// so page.tsx can import them from a single path

export type { CompareRow } from "@/components/article/TechCompare";
export type { FailurePattern } from "@/components/article/FailurePatterns";
export type { Drill } from "@/components/article/DrillCards";
